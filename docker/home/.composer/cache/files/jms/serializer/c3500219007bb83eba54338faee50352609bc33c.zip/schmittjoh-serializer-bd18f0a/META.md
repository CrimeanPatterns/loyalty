# Generating changelog

Use: https://github.com/skywinder/Github-Changelog-Generator

```bash
github_changelog_generator --user=schmittjoh --project=serializer --pull-requests --no-compare-link -t GITHUB-TOKEN
```
