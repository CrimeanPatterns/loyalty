<?php

declare(strict_types=1);

namespace JMS\Serializer\Exception;

/**
 * @author Asmir Mustafic <goetas@gmail.com>
 */
class CircularReferenceDetectedException extends NotAcceptableException
{
}
