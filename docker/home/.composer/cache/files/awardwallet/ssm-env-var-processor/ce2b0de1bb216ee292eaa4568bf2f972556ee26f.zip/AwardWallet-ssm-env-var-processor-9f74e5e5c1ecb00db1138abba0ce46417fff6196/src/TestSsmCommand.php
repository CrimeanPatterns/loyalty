<?php

namespace AwardWallet\SsmEnvVarProcessor;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

class TestSsmCommand extends Command
{
    protected static $defaultName = 'aw:test:ssm';
    /**
     * @var ContainerInterface
     */
    private $container;

    public function __construct(ContainerInterface $container)
    {
        parent::__construct();

        $this->container = $container;
    }

    public function configure()
    {
        $this
            ->addArgument('parameter', InputArgument::REQUIRED, 'ssm parameter name')
        ;
    }

    public function execute(InputInterface $input, OutputInterface $output)
    {
        $output->writeln($this->container->getParameter($input->getArgument("parameter")));

        return 0;
    }
}
