<?php

namespace AwardWallet\ExtensionWorker;

class PregException extends \Exception
{

}