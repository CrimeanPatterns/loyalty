<?php

namespace AwardWallet\ExtensionWorker;

class ElementNotFoundException extends ExtensionError
{

}