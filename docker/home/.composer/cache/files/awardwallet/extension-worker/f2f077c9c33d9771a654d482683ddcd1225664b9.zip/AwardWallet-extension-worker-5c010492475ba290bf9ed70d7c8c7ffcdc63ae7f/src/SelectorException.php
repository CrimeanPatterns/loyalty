<?php

namespace AwardWallet\ExtensionWorker;

class SelectorException extends \Exception
{

}