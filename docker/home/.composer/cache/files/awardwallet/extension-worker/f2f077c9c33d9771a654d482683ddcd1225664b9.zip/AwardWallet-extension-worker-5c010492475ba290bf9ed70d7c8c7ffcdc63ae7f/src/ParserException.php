<?php

namespace AwardWallet\ExtensionWorker;

class ParserException extends \Exception
{

}