<?php

namespace AwardWallet\ExtensionWorker;

class ExtensionError extends \Exception
{

}