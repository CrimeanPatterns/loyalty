<?php

namespace AwardWallet\ExtensionWorker;

class CommunicationException extends ExtensionError
{

}