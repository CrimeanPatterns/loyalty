<?php


namespace AwardWallet\Common\Geo\Google;


class GoogleRequestFailedException extends \Exception
{

}