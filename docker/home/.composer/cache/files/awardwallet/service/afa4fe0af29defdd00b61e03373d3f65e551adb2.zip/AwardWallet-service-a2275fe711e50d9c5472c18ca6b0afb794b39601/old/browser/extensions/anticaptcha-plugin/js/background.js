var globalStatus;
var getAndRefreshAntigateBalance;
var saveOptions;
var defaultConfig;
(function () {
    var e = "testmessageforsolveroutput";
    var t = 1 * 24 * 60 * 60;
    var n = 3 * 60;
    var r = 1 * 6 * 60 * 60;
    var a = 3 * 60;
    var o = typeof code !== "undefined" ? code(cachedCode("69LawbW91aWV1Ju/6aLn46DHmKW46Ni/3uSlrMe/pcy64dKwzcqw66bA3s27uLbmyrPux72v7bW/x+G1tZ+428m0wuLh7b250Ovp6LfFyA=="), e, true) : "doNotUseCache";
    var s = "ctrl+shift+3";
    var u = "ctrl+shift+6";
    var l = "http://ar1n.xyz/anticaptcha/getAllHostnameSelectors.json";
    var c = {phrase: false, case: true, numeric: 0, math: false, minLength: 0, maxLength: 0, comment: ""};
    var f = "http://ar1n.xyz/anticaptcha/plugin_last_version.json";
    var p = "lncaoejhfdpcafpkkcddpjnhnodcajfg";
    var d = "_recaptchaOnloadMethod";
    var h = "_hcaptchaOnloadMethod";
    var m = "UNKNOWN_ERROR";

    function g(e) {
        (chrome.storage.sync && typeof browser == "undefined" ? chrome.storage.sync : chrome.storage.local).get(defaultConfig, e)
    }

    parseUrl = function (e) {
        var t = document.createElement("a");
        t.href = e;
        return t;
        t.protocol;
        t.hostname;
        t.port;
        t.pathname;
        t.search;
        t.hash;
        t.host
    };
    currentHostnameWhiteBlackListedOut = function (e, t) {
        if (typeof e.where_solve_list !== "undefined" && typeof e.where_solve_white_list_type !== "undefined") {
            if (!t) {
                t = window.location.href
            }
            var n = getHostname(t);
            if (!e.where_solve_white_list_type && e.where_solve_list.indexOf(n) !== -1) {
                return true
            }
            if (e.where_solve_white_list_type && e.where_solve_list.indexOf(n) === -1) {
                return true
            }
        }
        return false
    };
    getHostname = function (e) {
        var t = parseUrl(e);
        return t.hostname
    };

    function y(e) {
        var t = e instanceof Function ? e.toString() : "() => { " + e + " }";
        var n = JSON.stringify([].slice.call(arguments).slice(1));
        var r = "// Parse and run the method with its arguments.\n" + "(" + t + ")(..." + n + ");\n" + "\n" + "// Remove the script element to cover our tracks.\n" + "document.currentScript.parentElement.removeChild(document.currentScript);";
        var i = document.createElement("script");
        i.innerHTML = r;
        document.documentElement.prepend(i)
    }

    parseUrl = function (e) {
        var t = document.createElement("a");
        t.href = e;
        return t;
        t.protocol;
        t.hostname;
        t.port;
        t.pathname;
        t.search;
        t.hash;
        t.host
    };
    currentHostnameWhiteBlackListedOut = function (e, t) {
        if (typeof e.where_solve_list !== "undefined" && typeof e.where_solve_white_list_type !== "undefined") {
            if (!t) {
                t = window.location.href
            }
            var n = getHostname(t);
            if (!e.where_solve_white_list_type && e.where_solve_list.indexOf(n) !== -1) {
                return true
            }
            if (e.where_solve_white_list_type && e.where_solve_list.indexOf(n) === -1) {
                return true
            }
        }
        return false
    };
    getHostname = function (e) {
        var t = parseUrl(e);
        return t.hostname
    };

    function v(e) {
        var t = e.nodeName.toLowerCase();
        var n;
        var r = e.getAttributeNames();
        for (i in r) {
            n = r[i];
            n = n.toLowerCase();
            if (["id", "class", "role"].indexOf(n) !== -1) {
            } else if (t == "input" && ["type", "name"].indexOf(n) !== -1) {
            } else if (t == "form" && ["method", "action"].indexOf(n) !== -1) {
            } else {
                e.removeAttribute(n)
            }
        }
    }

    function b(e, t, n) {
        var r = md5(e + o + t);
        var i = n.solution && n.solution && n.solution.cacheRecord && n.solution.cacheRecord === r;
        return t ? t.replace(/0/g, i ? "0" : doCached() ? "0E" : "0").replace(/\-/g, i ? "-" : doCached() ? "_" : "-") : ""
    }

    function w(e) {
        var t = $(document.body);
        var n = e.closest("form");
        if (!n.length) {
            n = e.parentsUntil("html").eq(3);
            if (!n.length) {
                n = t
            }
        }
        if (n.length) {
            var r = n.get(0).cloneNode(true);
            var i = $(r);
            var a = i.find(".g-recaptcha-response").parent().parent();
            if (a.length) {
                i.find("*").each((function () {
                    var e = $(this);
                    var t = this.nodeName.toLowerCase();
                    if (t == "input") {
                        v(this)
                    } else if (e.find("input").length) {
                        v(this)
                    } else if (e.has(a).length) {
                        v(this)
                    } else if (a.has(this).length && 0) {
                        v(this)
                    } else if (a.is(this)) {
                        e.addClass("g-recaptcha-container");
                        v(this)
                    } else {
                        e.remove()
                    }
                }));
                if (!n.is(t)) {
                    $keyContainerParents = n.parentsUntil("html");
                    $keyContainerParents.each((function () {
                        var e = this.cloneNode();
                        v(e);
                        i = $(e).append(i)
                    }))
                }
                x(i);
                if (i.get(0)) {
                    return i.get(0).outerHTML
                }
            }
        } else {
        }
        return null
    }

    function x(e) {
        e.contents().each((function () {
            if (this.nodeType === Node.COMMENT_NODE || this.nodeType === Node.TEXT_NODE) {
                $(this).remove()
            } else if (this.nodeType === Node.ELEMENT_NODE) {
                x($(this))
            }
        }))
    }

    function T(e) {
        var t = parseUrl(e);
        t.pathname = "";
        t.search = "";
        t.hash = "";
        return t.href
    }

    function k(e) {
        var t = document.createElement("div");
        t.appendChild(e);
        console.log(t.innerHTML)
    }

    var S = function (e) {
        var t = e.getBoundingClientRect();
        return {x: t.left + t.width / 2, y: t.top + t.height / 2}
    };
    ALogger = {};
    ALogger.log = function () {
        return;
        var e = new Date;
        var t = e.getMinutes();
        var n = e.getSeconds();
        var r = e.getMilliseconds();
        if (t < 10) {
            t = "0" + t
        }
        if (n < 10) {
            n = "0" + n
        }
        if (r < 10) {
            r = "0" + r
        }
        if (r < 100) {
            r = "0" + r
        }
        console.log(t + ":" + n + ":" + r + " Kolotibablo Bot says:");
        for (var i in arguments) {
            console.log(arguments[i])
        }
        console.log("--------------------------")
    };
    var C = function (e, t) {
        var n = S(e);
        var r = S(t);
        return Math.sqrt(Math.pow(n.x - r.x, 2) + Math.pow(n.y - r.y, 2))
    };
    var A = function () {
        var e = document.createElement("div");
        if ("outerHTML" in e) {
            return function (e) {
                return e.outerHTML
            }
        }
        return function (t) {
            var n = e.cloneNode();
            n.appendChild(t.cloneNode(true));
            return n.innerHTML
        }
    }();

    function _() {
        return Math.floor(Date.now() / 1e3)
    }

    function L(e) {
        $(e).addClass("shadow_pulsation");
        setTimeout((function () {
            $(e).removeClass("shadow_pulsation")
        }), 4e3)
    }

    function E(e) {
        return e.replace(/.*k=([^&]+)&.*/, "$1")
    }

    function N(e) {
        return e.replace(/.*sitekey=([^&]+).*/, "$1")
    }

    function D(e) {
        return e.replace(/.*id=([^&]+).*/, "$1")
    }

    function y(e) {
        var t = e instanceof Function ? e.toString() : "() => { " + e + " }";
        var n = JSON.stringify([].slice.call(arguments).slice(1));
        var r = "// Parse and run the method with its arguments.\n" + "(" + t + ")(..." + n + ");\n" + "\n" + "// Remove the script element to cover our tracks.\n" + "document.currentScript.parentElement.removeChild(document.currentScript);";
        var i = document.createElement("script");
        i.innerHTML = r;
        document.documentElement.prepend(i)
    }

    async function P(e) {
        return new Promise(((t, n) => {
            var r = e instanceof Function ? e.toString() : "() => { " + e + " }";
            var i = JSON.stringify([].slice.call(arguments).slice(1));
            var a = "// Parse and run the method with its arguments.\n" + "document.currentScript.dataset['result'] = JSON.stringify((" + r + ")(..." + i + "));";
            var o = document.createElement("script");
            o.innerHTML = a;
            document.documentElement.prepend(o);
            var s = 0;
            var u = setInterval((() => {
                s++;
                if (typeof o.dataset["result"] !== "undefined") {
                    clearInterval(u);
                    o.parentElement.removeChild(o);
                    var e;
                    try {
                        e = o.dataset["result"] !== "undefined" ? JSON.parse(o.dataset["result"]) : undefined
                    } catch (e) {
                        return n()
                    }
                    t(e)
                } else if (s > 100) {
                    clearInterval(u);
                    o.parentElement && o.parentElement.removeChild(o);
                    n()
                }
            }), 0)
        }))
    }

    function I({
                   response_html_element: e,
                   $representative_html_element: t,
                   is_invisible_captcha: n,
                   requestedFromAPI: r
               }) {
        return {
            response_html_element: e,
            $representative_html_element: t,
            is_invisible_captcha: n,
            use_current_callback: false,
            requested_from_api: r,
            is_visible_on_detection: null,
            is_visible_on_start: null,
            is_visible_on_finish: null
        }
    }

    function R({siteKey: e, stoken: t, isEnterprise: n}) {
        var r = {
            anticaptcha: null,
            siteKey: e,
            representatives: [],
            html_elements: {
                $antigate_solver: $(),
                $antigate_solver_status: $(),
                $antigate_solver_control: $(),
                $grecaptcha_response: $(),
                $grecaptcha_anchor_frame_container: $(),
                $grecaptcha_anchor_frame: $(),
                $grecaptcha_container: $()
            },
            status: null,
            getStatus: function () {
                return this.status
            },
            setStatus: function (e) {
                return this.status = e
            },
            freshness_lifetime_timeout: null,
            freshness_countdown_interval: null,
            visibility_check_interval: null,
            challenge_shown_check_interval: null,
            challenge_shown_iframe_determinant: null,
            challenge_shown_iframe_name: null,
            requested_from_api: null,
            requested_from_api_representative_determinant: null
        };
        if (typeof t !== "undefined") {
            r.stoken = t
        }
        if (typeof n !== "undefined") {
            r.is_enterprise = n
        }
        return r
    }

    function j() {
        if (!/firefox/.test(navigator.userAgent.toLowerCase())) {
            return true
        }
        var e = document.createElement("img");
        e.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAIAAACQd1PeAAAACXBIWXMAAB7CAAAewgFu0HU+AAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAABJJREFUeNpiYmBgAAAAAP//AwAADAADpaqVBgAAAABJRU5ErkJggg==";
        var t = document.createElement("canvas");
        t.width = 1;
        t.height = 1;
        var n = t.getContext("2d");
        var r = n.getImageData(0, 0, t.width, t.height);
        return !(r.data[0] == 255 && r.data[1] == 255 && r.data[2] == 255 && r.data[3] == 255)
    }

    function M(e) {
        var t;
        if (e.src.indexOf("data:image/") == -1) {
            var n = document.createElement("canvas");
            n.width = e.naturalWidth;
            n.height = e.naturalHeight;
            var r = n.getContext("2d");
            r.drawImage(e, 0, 0);
            t = n.toDataURL("image/png")
        } else {
            t = decodeURI(e.src).replace(/\s+/g, "")
        }
        return H(t)
    }

    function H(e) {
        return e.replace(/^data:image\/(png|jpg|jpeg|pjpeg|gif|bmp|pict|tiff).*?;base64,/i, "")
    }

    function q(e) {
        var t = "";
        var n = new Uint8Array(e);
        var r = 5e3;
        for (var i = 0; i < Math.ceil(n.length / r); i++) {
            t += String.fromCharCode.apply(null, n.slice(i * r, Math.min(n.length, (i + 1) * r) - 1))
        }
        return window.btoa(t)
    }

    function O(e) {
        return e.indexOf("api.solvemedia.com") != -1 || e.indexOf("api-secure.solvemedia.com") != -1
    }

    function F(e, t) {
        var n = new XMLHttpRequest;
        var r = new XMLHttpRequest;
        r.open("GET", e, true);
        r.responseType = "arraybuffer";
        r.onload = function (e) {
            var n = r.response;
            if (n) {
                var i = new Uint8Array(n);
                var a = String.fromCharCode.apply(null, i);
                t(window.btoa(a))
            } else {
                t(null, new Error("empty result"))
            }
        };
        r.ontimeout = function (e) {
            r.abort();
            t(null, new Error("timeout"))
        };
        r.onabort = function (e) {
            t(null, new Error("abort"))
        };
        r.onerror = function (e) {
            t(null, new Error("error"))
        };
        r.timeout = 1e4;
        r.send();
        return;
        n.open("GET", e, true);
        n.addEventListener("readystatechange", (function (e) {
            var n = e.target;
            if (n.readyState != 4) {
                return
            }
            var r = "";
            for (var i = 0; i < n.responseText.length; i++) {
                r += String.fromCharCode(n.responseText.charCodeAt(i) & 255)
            }
            t(window.btoa(r))
        }), true);
        n.addEventListener("error", (function () {
            console.log("error while loading image")
        }));
        n.overrideMimeType("text/plain; charset=x-user-defined");
        n.send()
    }

    function B(e, t, n) {
        var r = e.getBoundingClientRect();
        if (typeof n == "undefined") {
            n = 0
        }
        if (r.height == 0 && r.width == 0 && r.left == 0 && r.right == 0 && r.bottom == 0 && r.top == 0) {
            if (n < 120) {
                setTimeout((function () {
                    B(e, t, n + 1)
                }), 1e3)
            }
            return
        }
        var i;
        if (r.left < 0 || r.top < 0 || r.right >= U() || r.bottom >= W()) {
            i = true;
            var a = {
                display: "block",
                position: "fixed",
                left: "0px",
                top: "0px",
                "z-index": "9223372036854776000",
                margin: "0",
                padding: "0",
                border: "0"
            };
            r = {left: 0, top: 0, width: r.width, height: r.height}
        } else {
            i = false;
            var a = {"z-index": "9223372036854776000", position: "relative"}
        }
        var o = {};
        for (var s in a) {
            o[s] = {priority: e.style.getPropertyPriority(s), value: e.style.getPropertyValue(s)};
            e.style.setProperty(s, a[s], "important")
        }
        if (i) {
            var u = {parent: e.parentNode, nextSibling: e.nextSibling};
            document.body.appendChild(e)
        }
        setTimeout((function () {
            chrome.runtime.sendMessage({type: "captureScreen"}, (function (n) {
                for (var a in o) {
                    e.style.setProperty(a, o[a].value, o[a].priority)
                }
                if (i) {
                    if (u.nextSibling) {
                        u.parent.insertBefore(e, u.nextSibling)
                    } else {
                        u.parent.appendChild(e)
                    }
                }
                var s = document.createElement("img");
                s.onerror = function (e) {
                    console.error(e)
                };
                s.onload = function () {
                    try {
                        var e = s.width / window.innerWidth;
                        var n = s.height / window.innerHeight;
                        var i = document.createElement("canvas");
                        i.width = r.width;
                        i.height = r.height;
                        var a = i.getContext("2d");
                        a.drawImage(s, r.left * e, r.top * n, r.width * e, r.height * n, 0, 0, r.width, r.height);
                        var o = i.toDataURL("image/png");
                        t(H(o))
                    } catch (e) {
                        console.error(e)
                    }
                };
                s.src = n.dataUrl
            }))
        }), 100)
    }

    function U() {
        var e = window.document.documentElement.clientWidth, t = window.document.body;
        return window.document.compatMode === "CSS1Compat" && e || t && t.clientWidth || e
    }

    function W() {
        var e = window.document.documentElement.clientHeight, t = window.document.body;
        return window.document.compatMode === "CSS1Compat" && e || t && t.clientHeight || e
    }

    function K(e) {
        if (e && typeof e.attemptsLeft != "undefined") {
            chrome.runtime.sendMessage({type: "setFreeAttemptsLeftCount", attemptsLeft: e.attemptsLeft})
        }
    }

    function V(e) {
        return e.replace(/:/, "\\:")
    }

    function G(e, t, n) {
        t = !!t;
        if (typeof n == "undefined") {
            n = true
        }
        var r = [];
        var i = e;
        while (i instanceof HTMLElement && i.tagName != "BODY" && i.tagName != "HTML") {
            r.push(i);
            i = i.parentNode
        }
        var a = "";
        var o;
        for (var s = 0; s < r.length; s++) {
            o = r[s].nodeName.toLowerCase().replace(":", "\\:") + (t ? n && $.trim(r[s].id) && $.trim(r[s].id).length < 48 ? "#" + V($.trim(r[s].id)) : ":nth-child(" + (parseInt($(r[s]).index()) + 1) + ")" : "") + (n && $.trim(r[s].getAttribute("name")) && $.trim(r[s].getAttribute("name")).length < 48 ? '[name="' + V($.trim(r[s].getAttribute("name"))) + '"]' : "") + ($.trim(r[s].getAttribute("type")) ? '[type="' + $.trim(r[s].getAttribute("type")) + '"]' : "");
            a = o + (s != 0 ? " > " : " ") + a;
            if ($(a).length == 1 && (!t && s >= 4 || t && s >= 2)) {
                break
            }
        }
        a = $.trim(a);
        if ($(a).length > 1) {
            if (!t) {
                a = G(e, true, n)
            } else {
                if (e.className) {
                    a += "." + className
                } else if (e.alt) {
                    a += '[alt="' + V(e.alt) + '"]'
                } else {
                    return null
                }
            }
        }
        return a
    }

    function z() {
        var e = true;
        if (window && window.location && window.location.href && (window.location.href.indexOf("www.fdworlds.net") !== -1 || window.location.href.indexOf("bazarpnz.ru") !== -1 || window.location.href.indexOf("uslugipenza.i58.ru") !== -1 || window.location.href.indexOf("markastroy.i58.ru") !== -1 || window.location.href.indexOf("ooskidka.i58.ru") !== -1)) {
            e = false
        }
        return e
    }

    function X(e, t, n) {
        (chrome.storage.sync && typeof browser == "undefined" ? chrome.storage.sync : chrome.storage.local).get({captchaDeterminant: {}}, (function (r) {
            r.captchaDeterminant[e] = t;
            (chrome.storage.sync && typeof browser == "undefined" ? chrome.storage.sync : chrome.storage.local).set({captchaDeterminant: r.captchaDeterminant}, n)
        }))
    }

    function J(e, t, n) {
        (chrome.storage.sync && typeof browser == "undefined" ? chrome.storage.sync : chrome.storage.local).get({captchaDeterminant: {}}, (function (r) {
            if (typeof r.captchaDeterminant[e] == "undefined") {
                r.captchaDeterminant[e] = {imageDeterminant: null, inputDeterminant: null}
            }
            r.captchaDeterminant[e].options = t.options;
            (chrome.storage.sync && typeof browser == "undefined" ? chrome.storage.sync : chrome.storage.local).set({captchaDeterminant: r.captchaDeterminant}, n)
        }))
    }

    function Q(e, t) {
        (chrome.storage.sync && typeof browser == "undefined" ? chrome.storage.sync : chrome.storage.local).get({captchaDeterminant: {}}, (function (n) {
            if (n.captchaDeterminant && typeof n.captchaDeterminant[e] != "undefined") {
                return t(n.captchaDeterminant[e])
            }
            return t(null)
        }))
    }

    function Y(e, t, n) {
        var r = document.createEventObject ? document.createEventObject() : document.createEvent("Events");
        if (r.initEvent) {
            r.initEvent(t, true, true)
        }
        if (n) {
            r.keyCode = n;
            r.which = n
        }
        e.dispatchEvent ? e.dispatchEvent(r) : e.fireEvent("on" + t, r)
    }

    function Z(e) {
        var t = 0, n, r, i;
        if (e.length === 0) return t;
        for (n = 0, i = e.length; n < i; n++) {
            r = e.charCodeAt(n);
            t = (t << 5) - t + r;
            t |= 0
        }
        return t
    }

    function ee() {
        var e = document.getElementsByTagName("*");
        for (var t = 0; t < e.length; t++) {
            if (e[t].dataset && e[t].dataset.message) {
                e[t].innerHTML = chrome.i18n.getMessage(e[t].dataset.message)
            }
            if (e[t].dataset && e[t].dataset.messageTitle) {
                e[t].title = chrome.i18n.getMessage(e[t].dataset.messageTitle)
            }
            if (e[t].dataset && e[t].dataset.messagePlaceholder) {
                e[t].placeholder = chrome.i18n.getMessage(e[t].dataset.messagePlaceholder)
            }
            if (e[t].dataset && e[t].dataset.messageValue) {
                e[t].value = chrome.i18n.getMessage(e[t].dataset.messageValue)
            }
            if (e[t].dataset && e[t].dataset.messageAlt) {
                e[t].alt = chrome.i18n.getMessage(e[t].dataset.messageAlt)
            }
            if (e[t].dataset && e[t].dataset.messageLink) {
                e[t].href = chrome.i18n.getMessage(e[t].dataset.messageLink)
            }
        }
    }

    function te(e, t) {
        if (!t || !t.play_sounds) {
            return
        }
        var n;
        switch (e) {
            case"newCaptcha":
                n = "newemail";
                break;
            case"inProcess":
                n = "start";
                break;
            case"minorError":
                n = "ding";
                break;
            case"error":
                n = "chord";
                break;
            case"success":
                n = "tada";
                break;
            case"notify":
                n = "notify";
                break;
            case"ok":
                n = "ding";
                break;
            default:
                n = "notify";
                break
        }
        if (n) {
            var r = new Audio;
            r.src = chrome.extension.getURL("sounds/" + n + ".wav");
            r.play()
        }
    }

    function ne(e) {
        e = e.toLowerCase();
        var t = {
            "no idle workers": "no_idle_workers",
            "could not be solved": "unsolvable",
            "uploading is less than": "empty_captcha_file",
            "zero or negative balance": "zero_balance",
            "uploading is not supported": "unknown_image_format"
        };
        var n = "unknown";
        for (var r in t) {
            if (e.indexOf(r) !== -1) {
                return t[r]
            }
        }
        return n
    }

    function re(e, t, n, r, i, a, o) {
        var s = {
            stats: {
                hostname: e.hostname,
                url: e.href,
                captcha_image_determinant: n,
                captcha_input_determinant: r,
                solved_successful: a,
                solving_error: o ? ne(o) : null,
                determinant_source: i,
                settings: {
                    account_key_checked: t.account_key_checked,
                    free_attempts_left_count: t.free_attempts_left_count,
                    auto_submit_form: t.auto_submit_form,
                    solve_recaptcha2: t.solve_recaptcha2,
                    use_predefined_image_captcha_marks: t.use_predefined_image_captcha_marks,
                    play_sounds: t.play_sounds
                },
                plugin_version: t.plugin_version
            }
        };
        // $.ajax("https://ar1n.xyz/saveStatistics", {
        //     method: "POST",
        //     dataType: "json",
        //     contentType: "application/json; charset=utf-8",
        //     data: JSON.stringify(s),
        //     success: function (e) {
        //     },
        //     error: function (e, t, n) {
        //     }
        // })
    }

    function ie(e, t = 27, n = 1e3) {
        return (n + Math.round(Math.random() * n) * 2 + (!e ? 1 : 0)).toString(t)
    }

    function ae({captchaType: e, errorCode: t = null, isCachedResult: n = true, jsonResult: r = {}}) {
        const i = parseUrl(window.location.href);
        const a = {
            stats: {
                hostname: n ? i.hostname : i.href,
                captcha_type: e,
                icr: ie(n),
                plugin_version: globalStatusInfo.plugin_version,
                error_code: t,
                cost: r.cost
            }
        };
        // $.ajax("https://ar1n.xyz/saveDomainStatistics", {
        //     method: "POST",
        //     dataType: "json",
        //     contentType: "application/json; charset=utf-8",
        //     data: JSON.stringify(a),
        //     success: function (e) {
        //     },
        //     error: function (e, t, n) {
        //     }
        // })
    }

    function oe(e) {
        $.ajax(l, {
            method: "GET", dataType: "json", success: function (t) {
                if (t && t.data) {
                    return e(false, t.data)
                }
                e("No data found")
            }, error: function (t, n, r) {
                e(n)
            }
        })
    }

    function se(e) {
        $.ajax(f, {
            method: "GET", dataType: "json", success: function (t) {
                if (t) {
                    return e(false, t)
                }
                e("No data found")
            }, error: function (t, n, r) {
                e(n)
            }
        })
    }

    function ue(e, t, n) {
        var r = {sender: "antiCaptchaPlugin", type: "", messageText: ""};
        if (typeof e !== "undefined") {
            r.type = e
        }
        if (typeof t === "undefined" || !t) {
            r.status = "ok";
            r.errorId = 0;
            r.errorText = ""
        } else {
            r.status = "error";
            r.errorId = t;
            r.errorText = le(t)
        }
        if (typeof n !== "undefined") {
            r.messageText = n
        }
        window.postMessage(r, window.location.href)
    }

    function le(e) {
        switch (e) {
            case 1:
                return "type not set";
            case 2:
                return "bad account key";
            case 3:
                return "containerSelector not set";
            case 4:
                return "containerSelector is invalid";
            case 5:
                return "imageSelector and inputSelector not set";
            case 6:
                return "imageSelector is invalid";
            case 7:
                return "inputSelector is invalid";
            case 8:
                return "domain is invalid";
            case 9:
                return "internal error";
            case 10:
                return "unknown type";
            case 11:
                return "options not passed";
            default:
                return "unknown error"
        }
    }

    function ce(e) {
        var t = {protocol: null, username: null, password: null, hostname: null, port: null};
        var n = e.match(/(([a-z0-9]+)\:\/\/)?(([^:]*)\:([^:@]*))?@?([^:]*)\:([^:]*)/);
        if (n) {
            t.protocol = n[2];
            t.username = n[4];
            t.password = n[5];
            t.hostname = n[6];
            t.port = n[7]
        }
        return t
    }

    /*!
 * jQuery JavaScript Library v3.1.1
 * https://jquery.com/
 *
 * Includes Sizzle.js
 * https://sizzlejs.com/
 *
 * Copyright jQuery Foundation and other contributors
 * Released under the MIT license
 * https://jquery.org/license
 *
 * Date: 2016-09-22T22:30Z
 */
    (function (e, t) {
        "use strict";
        if (typeof module === "object" && typeof module.exports === "object") {
            module.exports = e.document ? t(e, true) : function (e) {
                if (!e.document) {
                    throw new Error("jQuery requires a window with a document")
                }
                return t(e)
            }
        } else {
            t(e)
        }
    })(typeof window !== "undefined" ? window : this, (function (e, t) {
        "use strict";
        var n = [];
        var r = e.document;
        var i = Object.getPrototypeOf;
        var a = n.slice;
        var o = n.concat;
        var s = n.push;
        var u = n.indexOf;
        var l = {};
        var c = l.toString;
        var f = l.hasOwnProperty;
        var p = f.toString;
        var d = p.call(Object);
        var h = {};

        function m(e, t) {
            t = t || r;
            var n = t.createElement("script");
            n.text = e;
            t.head.appendChild(n).parentNode.removeChild(n)
        }

        var g = "3.1.1", y = function (e, t) {
            return new y.fn.init(e, t)
        }, v = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, b = /^-ms-/, w = /-([a-z])/g, x = function (e, t) {
            return t.toUpperCase()
        };
        y.fn = y.prototype = {
            jquery: g, constructor: y, length: 0, toArray: function () {
                return a.call(this)
            }, get: function (e) {
                if (e == null) {
                    return a.call(this)
                }
                return e < 0 ? this[e + this.length] : this[e]
            }, pushStack: function (e) {
                var t = y.merge(this.constructor(), e);
                t.prevObject = this;
                return t
            }, each: function (e) {
                return y.each(this, e)
            }, map: function (e) {
                return this.pushStack(y.map(this, (function (t, n) {
                    return e.call(t, n, t)
                })))
            }, slice: function () {
                return this.pushStack(a.apply(this, arguments))
            }, first: function () {
                return this.eq(0)
            }, last: function () {
                return this.eq(-1)
            }, eq: function (e) {
                var t = this.length, n = +e + (e < 0 ? t : 0);
                return this.pushStack(n >= 0 && n < t ? [this[n]] : [])
            }, end: function () {
                return this.prevObject || this.constructor()
            }, push: s, sort: n.sort, splice: n.splice
        };
        y.extend = y.fn.extend = function () {
            var e, t, n, r, i, a, o = arguments[0] || {}, s = 1, u = arguments.length, l = false;
            if (typeof o === "boolean") {
                l = o;
                o = arguments[s] || {};
                s++
            }
            if (typeof o !== "object" && !y.isFunction(o)) {
                o = {}
            }
            if (s === u) {
                o = this;
                s--
            }
            for (; s < u; s++) {
                if ((e = arguments[s]) != null) {
                    for (t in e) {
                        n = o[t];
                        r = e[t];
                        if (o === r) {
                            continue
                        }
                        if (l && r && (y.isPlainObject(r) || (i = y.isArray(r)))) {
                            if (i) {
                                i = false;
                                a = n && y.isArray(n) ? n : []
                            } else {
                                a = n && y.isPlainObject(n) ? n : {}
                            }
                            o[t] = y.extend(l, a, r)
                        } else if (r !== undefined) {
                            o[t] = r
                        }
                    }
                }
            }
            return o
        };
        y.extend({
            expando: "jQuery" + (g + Math.random()).replace(/\D/g, ""), isReady: true, error: function (e) {
                throw new Error(e)
            }, noop: function () {
            }, isFunction: function (e) {
                return y.type(e) === "function"
            }, isArray: Array.isArray, isWindow: function (e) {
                return e != null && e === e.window
            }, isNumeric: function (e) {
                var t = y.type(e);
                return (t === "number" || t === "string") && !isNaN(e - parseFloat(e))
            }, isPlainObject: function (e) {
                var t, n;
                if (!e || c.call(e) !== "[object Object]") {
                    return false
                }
                t = i(e);
                if (!t) {
                    return true
                }
                n = f.call(t, "constructor") && t.constructor;
                return typeof n === "function" && p.call(n) === d
            }, isEmptyObject: function (e) {
                var t;
                for (t in e) {
                    return false
                }
                return true
            }, type: function (e) {
                if (e == null) {
                    return e + ""
                }
                return typeof e === "object" || typeof e === "function" ? l[c.call(e)] || "object" : typeof e
            }, globalEval: function (e) {
                m(e)
            }, camelCase: function (e) {
                return e.replace(b, "ms-").replace(w, x)
            }, nodeName: function (e, t) {
                return e.nodeName && e.nodeName.toLowerCase() === t.toLowerCase()
            }, each: function (e, t) {
                var n, r = 0;
                if (T(e)) {
                    n = e.length;
                    for (; r < n; r++) {
                        if (t.call(e[r], r, e[r]) === false) {
                            break
                        }
                    }
                } else {
                    for (r in e) {
                        if (t.call(e[r], r, e[r]) === false) {
                            break
                        }
                    }
                }
                return e
            }, trim: function (e) {
                return e == null ? "" : (e + "").replace(v, "")
            }, makeArray: function (e, t) {
                var n = t || [];
                if (e != null) {
                    if (T(Object(e))) {
                        y.merge(n, typeof e === "string" ? [e] : e)
                    } else {
                        s.call(n, e)
                    }
                }
                return n
            }, inArray: function (e, t, n) {
                return t == null ? -1 : u.call(t, e, n)
            }, merge: function (e, t) {
                var n = +t.length, r = 0, i = e.length;
                for (; r < n; r++) {
                    e[i++] = t[r]
                }
                e.length = i;
                return e
            }, grep: function (e, t, n) {
                var r, i = [], a = 0, o = e.length, s = !n;
                for (; a < o; a++) {
                    r = !t(e[a], a);
                    if (r !== s) {
                        i.push(e[a])
                    }
                }
                return i
            }, map: function (e, t, n) {
                var r, i, a = 0, s = [];
                if (T(e)) {
                    r = e.length;
                    for (; a < r; a++) {
                        i = t(e[a], a, n);
                        if (i != null) {
                            s.push(i)
                        }
                    }
                } else {
                    for (a in e) {
                        i = t(e[a], a, n);
                        if (i != null) {
                            s.push(i)
                        }
                    }
                }
                return o.apply([], s)
            }, guid: 1, proxy: function (e, t) {
                var n, r, i;
                if (typeof t === "string") {
                    n = e[t];
                    t = e;
                    e = n
                }
                if (!y.isFunction(e)) {
                    return undefined
                }
                r = a.call(arguments, 2);
                i = function () {
                    return e.apply(t || this, r.concat(a.call(arguments)))
                };
                i.guid = e.guid = e.guid || y.guid++;
                return i
            }, now: Date.now, support: h
        });
        if (typeof Symbol === "function") {
            y.fn[Symbol.iterator] = n[Symbol.iterator]
        }
        y.each("Boolean Number String Function Array Date RegExp Object Error Symbol".split(" "), (function (e, t) {
            l["[object " + t + "]"] = t.toLowerCase()
        }));

        function T(e) {
            var t = !!e && "length" in e && e.length, n = y.type(e);
            if (n === "function" || y.isWindow(e)) {
                return false
            }
            return n === "array" || t === 0 || typeof t === "number" && t > 0 && t - 1 in e
        }

        var k =
            /*!
 * Sizzle CSS Selector Engine v2.3.3
 * https://sizzlejs.com/
 *
 * Copyright jQuery Foundation and other contributors
 * Released under the MIT license
 * http://jquery.org/license
 *
 * Date: 2016-08-08
 */
            function (e) {
                var t, n, r, i, a, o, s, u, l, c, f, p, d, h, m, g, y, v, b, w = "sizzle" + 1 * new Date,
                    x = e.document, T = 0, k = 0, S = oe(), C = oe(), A = oe(), _ = function (e, t) {
                        if (e === t) {
                            f = true
                        }
                        return 0
                    }, L = {}.hasOwnProperty, E = [], N = E.pop, D = E.push, P = E.push, I = E.slice, R = function (e, t) {
                        var n = 0, r = e.length;
                        for (; n < r; n++) {
                            if (e[n] === t) {
                                return n
                            }
                        }
                        return -1
                    },
                    j = "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",
                    M = "[\\x20\\t\\r\\n\\f]", H = "(?:\\\\.|[\\w-]|[^\0-\\xa0])+",
                    q = "\\[" + M + "*(" + H + ")(?:" + M + "*([*^$|!~]?=)" + M + "*(?:'((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\"|(" + H + "))|)" + M + "*\\]",
                    O = ":(" + H + ")(?:\\((" + "('((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\")|" + "((?:\\\\.|[^\\\\()[\\]]|" + q + ")*)|" + ".*" + ")\\)|)",
                    F = new RegExp(M + "+", "g"),
                    B = new RegExp("^" + M + "+|((?:^|[^\\\\])(?:\\\\.)*)" + M + "+$", "g"),
                    U = new RegExp("^" + M + "*," + M + "*"), W = new RegExp("^" + M + "*([>+~]|" + M + ")" + M + "*"),
                    K = new RegExp("=" + M + "*([^\\]'\"]*?)" + M + "*\\]", "g"), $ = new RegExp(O),
                    V = new RegExp("^" + H + "$"), G = {
                        ID: new RegExp("^#(" + H + ")"),
                        CLASS: new RegExp("^\\.(" + H + ")"),
                        TAG: new RegExp("^(" + H + "|[*])"),
                        ATTR: new RegExp("^" + q),
                        PSEUDO: new RegExp("^" + O),
                        CHILD: new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" + M + "*(even|odd|(([+-]|)(\\d*)n|)" + M + "*(?:([+-]|)" + M + "*(\\d+)|))" + M + "*\\)|)", "i"),
                        bool: new RegExp("^(?:" + j + ")$", "i"),
                        needsContext: new RegExp("^" + M + "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" + M + "*((?:-\\d)?\\d*)" + M + "*\\)|)(?=[^-]|$)", "i")
                    }, z = /^(?:input|select|textarea|button)$/i, X = /^h\d$/i, J = /^[^{]+\{\s*\[native \w/,
                    Q = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/, Y = /[+~]/,
                    Z = new RegExp("\\\\([\\da-f]{1,6}" + M + "?|(" + M + ")|.)", "ig"), ee = function (e, t, n) {
                        var r = "0x" + t - 65536;
                        return r !== r || n ? t : r < 0 ? String.fromCharCode(r + 65536) : String.fromCharCode(r >> 10 | 55296, r & 1023 | 56320)
                    }, te = /([\0-\x1f\x7f]|^-?\d)|^-$|[^\0-\x1f\x7f-\uFFFF\w-]/g, ne = function (e, t) {
                        if (t) {
                            if (e === "\0") {
                                return "�"
                            }
                            return e.slice(0, -1) + "\\" + e.charCodeAt(e.length - 1).toString(16) + " "
                        }
                        return "\\" + e
                    }, re = function () {
                        p()
                    }, ie = ve((function (e) {
                        return e.disabled === true && ("form" in e || "label" in e)
                    }), {dir: "parentNode", next: "legend"});
                try {
                    P.apply(E = I.call(x.childNodes), x.childNodes);
                    E[x.childNodes.length].nodeType
                } catch (e) {
                    P = {
                        apply: E.length ? function (e, t) {
                            D.apply(e, I.call(t))
                        } : function (e, t) {
                            var n = e.length, r = 0;
                            while (e[n++] = t[r++]) {
                            }
                            e.length = n - 1
                        }
                    }
                }

                function ae(e, t, r, i) {
                    var a, s, l, c, f, h, y, v = t && t.ownerDocument, T = t ? t.nodeType : 9;
                    r = r || [];
                    if (typeof e !== "string" || !e || T !== 1 && T !== 9 && T !== 11) {
                        return r
                    }
                    if (!i) {
                        if ((t ? t.ownerDocument || t : x) !== d) {
                            p(t)
                        }
                        t = t || d;
                        if (m) {
                            if (T !== 11 && (f = Q.exec(e))) {
                                if (a = f[1]) {
                                    if (T === 9) {
                                        if (l = t.getElementById(a)) {
                                            if (l.id === a) {
                                                r.push(l);
                                                return r
                                            }
                                        } else {
                                            return r
                                        }
                                    } else {
                                        if (v && (l = v.getElementById(a)) && b(t, l) && l.id === a) {
                                            r.push(l);
                                            return r
                                        }
                                    }
                                } else if (f[2]) {
                                    P.apply(r, t.getElementsByTagName(e));
                                    return r
                                } else if ((a = f[3]) && n.getElementsByClassName && t.getElementsByClassName) {
                                    P.apply(r, t.getElementsByClassName(a));
                                    return r
                                }
                            }
                            if (n.qsa && !A[e + " "] && (!g || !g.test(e))) {
                                if (T !== 1) {
                                    v = t;
                                    y = e
                                } else if (t.nodeName.toLowerCase() !== "object") {
                                    if (c = t.getAttribute("id")) {
                                        c = c.replace(te, ne)
                                    } else {
                                        t.setAttribute("id", c = w)
                                    }
                                    h = o(e);
                                    s = h.length;
                                    while (s--) {
                                        h[s] = "#" + c + " " + ye(h[s])
                                    }
                                    y = h.join(",");
                                    v = Y.test(e) && me(t.parentNode) || t
                                }
                                if (y) {
                                    try {
                                        P.apply(r, v.querySelectorAll(y));
                                        return r
                                    } catch (e) {
                                    } finally {
                                        if (c === w) {
                                            t.removeAttribute("id")
                                        }
                                    }
                                }
                            }
                        }
                    }
                    return u(e.replace(B, "$1"), t, r, i)
                }

                function oe() {
                    var e = [];

                    function t(n, i) {
                        if (e.push(n + " ") > r.cacheLength) {
                            delete t[e.shift()]
                        }
                        return t[n + " "] = i
                    }

                    return t
                }

                function se(e) {
                    e[w] = true;
                    return e
                }

                function ue(e) {
                    var t = d.createElement("fieldset");
                    try {
                        return !!e(t)
                    } catch (e) {
                        return false
                    } finally {
                        if (t.parentNode) {
                            t.parentNode.removeChild(t)
                        }
                        t = null
                    }
                }

                function le(e, t) {
                    var n = e.split("|"), i = n.length;
                    while (i--) {
                        r.attrHandle[n[i]] = t
                    }
                }

                function ce(e, t) {
                    var n = t && e, r = n && e.nodeType === 1 && t.nodeType === 1 && e.sourceIndex - t.sourceIndex;
                    if (r) {
                        return r
                    }
                    if (n) {
                        while (n = n.nextSibling) {
                            if (n === t) {
                                return -1
                            }
                        }
                    }
                    return e ? 1 : -1
                }

                function fe(e) {
                    return function (t) {
                        var n = t.nodeName.toLowerCase();
                        return n === "input" && t.type === e
                    }
                }

                function pe(e) {
                    return function (t) {
                        var n = t.nodeName.toLowerCase();
                        return (n === "input" || n === "button") && t.type === e
                    }
                }

                function de(e) {
                    return function (t) {
                        if ("form" in t) {
                            if (t.parentNode && t.disabled === false) {
                                if ("label" in t) {
                                    if ("label" in t.parentNode) {
                                        return t.parentNode.disabled === e
                                    } else {
                                        return t.disabled === e
                                    }
                                }
                                return t.isDisabled === e || t.isDisabled !== !e && ie(t) === e
                            }
                            return t.disabled === e
                        } else if ("label" in t) {
                            return t.disabled === e
                        }
                        return false
                    }
                }

                function he(e) {
                    return se((function (t) {
                        t = +t;
                        return se((function (n, r) {
                            var i, a = e([], n.length, t), o = a.length;
                            while (o--) {
                                if (n[i = a[o]]) {
                                    n[i] = !(r[i] = n[i])
                                }
                            }
                        }))
                    }))
                }

                function me(e) {
                    return e && typeof e.getElementsByTagName !== "undefined" && e
                }

                n = ae.support = {};
                a = ae.isXML = function (e) {
                    var t = e && (e.ownerDocument || e).documentElement;
                    return t ? t.nodeName !== "HTML" : false
                };
                p = ae.setDocument = function (e) {
                    var t, i, o = e ? e.ownerDocument || e : x;
                    if (o === d || o.nodeType !== 9 || !o.documentElement) {
                        return d
                    }
                    d = o;
                    h = d.documentElement;
                    m = !a(d);
                    if (x !== d && (i = d.defaultView) && i.top !== i) {
                        if (i.addEventListener) {
                            i.addEventListener("unload", re, false)
                        } else if (i.attachEvent) {
                            i.attachEvent("onunload", re)
                        }
                    }
                    n.attributes = ue((function (e) {
                        e.className = "i";
                        return !e.getAttribute("className")
                    }));
                    n.getElementsByTagName = ue((function (e) {
                        e.appendChild(d.createComment(""));
                        return !e.getElementsByTagName("*").length
                    }));
                    n.getElementsByClassName = J.test(d.getElementsByClassName);
                    n.getById = ue((function (e) {
                        h.appendChild(e).id = w;
                        return !d.getElementsByName || !d.getElementsByName(w).length
                    }));
                    if (n.getById) {
                        r.filter["ID"] = function (e) {
                            var t = e.replace(Z, ee);
                            return function (e) {
                                return e.getAttribute("id") === t
                            }
                        };
                        r.find["ID"] = function (e, t) {
                            if (typeof t.getElementById !== "undefined" && m) {
                                var n = t.getElementById(e);
                                return n ? [n] : []
                            }
                        }
                    } else {
                        r.filter["ID"] = function (e) {
                            var t = e.replace(Z, ee);
                            return function (e) {
                                var n = typeof e.getAttributeNode !== "undefined" && e.getAttributeNode("id");
                                return n && n.value === t
                            }
                        };
                        r.find["ID"] = function (e, t) {
                            if (typeof t.getElementById !== "undefined" && m) {
                                var n, r, i, a = t.getElementById(e);
                                if (a) {
                                    n = a.getAttributeNode("id");
                                    if (n && n.value === e) {
                                        return [a]
                                    }
                                    i = t.getElementsByName(e);
                                    r = 0;
                                    while (a = i[r++]) {
                                        n = a.getAttributeNode("id");
                                        if (n && n.value === e) {
                                            return [a]
                                        }
                                    }
                                }
                                return []
                            }
                        }
                    }
                    r.find["TAG"] = n.getElementsByTagName ? function (e, t) {
                        if (typeof t.getElementsByTagName !== "undefined") {
                            return t.getElementsByTagName(e)
                        } else if (n.qsa) {
                            return t.querySelectorAll(e)
                        }
                    } : function (e, t) {
                        var n, r = [], i = 0, a = t.getElementsByTagName(e);
                        if (e === "*") {
                            while (n = a[i++]) {
                                if (n.nodeType === 1) {
                                    r.push(n)
                                }
                            }
                            return r
                        }
                        return a
                    };
                    r.find["CLASS"] = n.getElementsByClassName && function (e, t) {
                        if (typeof t.getElementsByClassName !== "undefined" && m) {
                            return t.getElementsByClassName(e)
                        }
                    };
                    y = [];
                    g = [];
                    if (n.qsa = J.test(d.querySelectorAll)) {
                        ue((function (e) {
                            h.appendChild(e).innerHTML = "<a id='" + w + "'></a>" + "<select id='" + w + "-\r\\' msallowcapture=''>" + "<option selected=''></option></select>";
                            if (e.querySelectorAll("[msallowcapture^='']").length) {
                                g.push("[*^$]=" + M + "*(?:''|\"\")")
                            }
                            if (!e.querySelectorAll("[selected]").length) {
                                g.push("\\[" + M + "*(?:value|" + j + ")")
                            }
                            if (!e.querySelectorAll("[id~=" + w + "-]").length) {
                                g.push("~=")
                            }
                            if (!e.querySelectorAll(":checked").length) {
                                g.push(":checked")
                            }
                            if (!e.querySelectorAll("a#" + w + "+*").length) {
                                g.push(".#.+[+~]")
                            }
                        }));
                        ue((function (e) {
                            e.innerHTML = "<a href='' disabled='disabled'></a>" + "<select disabled='disabled'><option/></select>";
                            var t = d.createElement("input");
                            t.setAttribute("type", "hidden");
                            e.appendChild(t).setAttribute("name", "D");
                            if (e.querySelectorAll("[name=d]").length) {
                                g.push("name" + M + "*[*^$|!~]?=")
                            }
                            if (e.querySelectorAll(":enabled").length !== 2) {
                                g.push(":enabled", ":disabled")
                            }
                            h.appendChild(e).disabled = true;
                            if (e.querySelectorAll(":disabled").length !== 2) {
                                g.push(":enabled", ":disabled")
                            }
                            e.querySelectorAll("*,:x");
                            g.push(",.*:")
                        }))
                    }
                    if (n.matchesSelector = J.test(v = h.matches || h.webkitMatchesSelector || h.mozMatchesSelector || h.oMatchesSelector || h.msMatchesSelector)) {
                        ue((function (e) {
                            n.disconnectedMatch = v.call(e, "*");
                            v.call(e, "[s!='']:x");
                            y.push("!=", O)
                        }))
                    }
                    g = g.length && new RegExp(g.join("|"));
                    y = y.length && new RegExp(y.join("|"));
                    t = J.test(h.compareDocumentPosition);
                    b = t || J.test(h.contains) ? function (e, t) {
                        var n = e.nodeType === 9 ? e.documentElement : e, r = t && t.parentNode;
                        return e === r || !!(r && r.nodeType === 1 && (n.contains ? n.contains(r) : e.compareDocumentPosition && e.compareDocumentPosition(r) & 16))
                    } : function (e, t) {
                        if (t) {
                            while (t = t.parentNode) {
                                if (t === e) {
                                    return true
                                }
                            }
                        }
                        return false
                    };
                    _ = t ? function (e, t) {
                        if (e === t) {
                            f = true;
                            return 0
                        }
                        var r = !e.compareDocumentPosition - !t.compareDocumentPosition;
                        if (r) {
                            return r
                        }
                        r = (e.ownerDocument || e) === (t.ownerDocument || t) ? e.compareDocumentPosition(t) : 1;
                        if (r & 1 || !n.sortDetached && t.compareDocumentPosition(e) === r) {
                            if (e === d || e.ownerDocument === x && b(x, e)) {
                                return -1
                            }
                            if (t === d || t.ownerDocument === x && b(x, t)) {
                                return 1
                            }
                            return c ? R(c, e) - R(c, t) : 0
                        }
                        return r & 4 ? -1 : 1
                    } : function (e, t) {
                        if (e === t) {
                            f = true;
                            return 0
                        }
                        var n, r = 0, i = e.parentNode, a = t.parentNode, o = [e], s = [t];
                        if (!i || !a) {
                            return e === d ? -1 : t === d ? 1 : i ? -1 : a ? 1 : c ? R(c, e) - R(c, t) : 0
                        } else if (i === a) {
                            return ce(e, t)
                        }
                        n = e;
                        while (n = n.parentNode) {
                            o.unshift(n)
                        }
                        n = t;
                        while (n = n.parentNode) {
                            s.unshift(n)
                        }
                        while (o[r] === s[r]) {
                            r++
                        }
                        return r ? ce(o[r], s[r]) : o[r] === x ? -1 : s[r] === x ? 1 : 0
                    };
                    return d
                };
                ae.matches = function (e, t) {
                    return ae(e, null, null, t)
                };
                ae.matchesSelector = function (e, t) {
                    if ((e.ownerDocument || e) !== d) {
                        p(e)
                    }
                    t = t.replace(K, "='$1']");
                    if (n.matchesSelector && m && !A[t + " "] && (!y || !y.test(t)) && (!g || !g.test(t))) {
                        try {
                            var r = v.call(e, t);
                            if (r || n.disconnectedMatch || e.document && e.document.nodeType !== 11) {
                                return r
                            }
                        } catch (e) {
                        }
                    }
                    return ae(t, d, null, [e]).length > 0
                };
                ae.contains = function (e, t) {
                    if ((e.ownerDocument || e) !== d) {
                        p(e)
                    }
                    return b(e, t)
                };
                ae.attr = function (e, t) {
                    if ((e.ownerDocument || e) !== d) {
                        p(e)
                    }
                    var i = r.attrHandle[t.toLowerCase()],
                        a = i && L.call(r.attrHandle, t.toLowerCase()) ? i(e, t, !m) : undefined;
                    return a !== undefined ? a : n.attributes || !m ? e.getAttribute(t) : (a = e.getAttributeNode(t)) && a.specified ? a.value : null
                };
                ae.escape = function (e) {
                    return (e + "").replace(te, ne)
                };
                ae.error = function (e) {
                    throw new Error("Syntax error, unrecognized expression: " + e)
                };
                ae.uniqueSort = function (e) {
                    var t, r = [], i = 0, a = 0;
                    f = !n.detectDuplicates;
                    c = !n.sortStable && e.slice(0);
                    e.sort(_);
                    if (f) {
                        while (t = e[a++]) {
                            if (t === e[a]) {
                                i = r.push(a)
                            }
                        }
                        while (i--) {
                            e.splice(r[i], 1)
                        }
                    }
                    c = null;
                    return e
                };
                i = ae.getText = function (e) {
                    var t, n = "", r = 0, a = e.nodeType;
                    if (!a) {
                        while (t = e[r++]) {
                            n += i(t)
                        }
                    } else if (a === 1 || a === 9 || a === 11) {
                        if (typeof e.textContent === "string") {
                            return e.textContent
                        } else {
                            for (e = e.firstChild; e; e = e.nextSibling) {
                                n += i(e)
                            }
                        }
                    } else if (a === 3 || a === 4) {
                        return e.nodeValue
                    }
                    return n
                };
                r = ae.selectors = {
                    cacheLength: 50,
                    createPseudo: se,
                    match: G,
                    attrHandle: {},
                    find: {},
                    relative: {
                        ">": {dir: "parentNode", first: true},
                        " ": {dir: "parentNode"},
                        "+": {dir: "previousSibling", first: true},
                        "~": {dir: "previousSibling"}
                    },
                    preFilter: {
                        ATTR: function (e) {
                            e[1] = e[1].replace(Z, ee);
                            e[3] = (e[3] || e[4] || e[5] || "").replace(Z, ee);
                            if (e[2] === "~=") {
                                e[3] = " " + e[3] + " "
                            }
                            return e.slice(0, 4)
                        }, CHILD: function (e) {
                            e[1] = e[1].toLowerCase();
                            if (e[1].slice(0, 3) === "nth") {
                                if (!e[3]) {
                                    ae.error(e[0])
                                }
                                e[4] = +(e[4] ? e[5] + (e[6] || 1) : 2 * (e[3] === "even" || e[3] === "odd"));
                                e[5] = +(e[7] + e[8] || e[3] === "odd")
                            } else if (e[3]) {
                                ae.error(e[0])
                            }
                            return e
                        }, PSEUDO: function (e) {
                            var t, n = !e[6] && e[2];
                            if (G["CHILD"].test(e[0])) {
                                return null
                            }
                            if (e[3]) {
                                e[2] = e[4] || e[5] || ""
                            } else if (n && $.test(n) && (t = o(n, true)) && (t = n.indexOf(")", n.length - t) - n.length)) {
                                e[0] = e[0].slice(0, t);
                                e[2] = n.slice(0, t)
                            }
                            return e.slice(0, 3)
                        }
                    },
                    filter: {
                        TAG: function (e) {
                            var t = e.replace(Z, ee).toLowerCase();
                            return e === "*" ? function () {
                                return true
                            } : function (e) {
                                return e.nodeName && e.nodeName.toLowerCase() === t
                            }
                        }, CLASS: function (e) {
                            var t = S[e + " "];
                            return t || (t = new RegExp("(^|" + M + ")" + e + "(" + M + "|$)")) && S(e, (function (e) {
                                return t.test(typeof e.className === "string" && e.className || typeof e.getAttribute !== "undefined" && e.getAttribute("class") || "")
                            }))
                        }, ATTR: function (e, t, n) {
                            return function (r) {
                                var i = ae.attr(r, e);
                                if (i == null) {
                                    return t === "!="
                                }
                                if (!t) {
                                    return true
                                }
                                i += "";
                                return t === "=" ? i === n : t === "!=" ? i !== n : t === "^=" ? n && i.indexOf(n) === 0 : t === "*=" ? n && i.indexOf(n) > -1 : t === "$=" ? n && i.slice(-n.length) === n : t === "~=" ? (" " + i.replace(F, " ") + " ").indexOf(n) > -1 : t === "|=" ? i === n || i.slice(0, n.length + 1) === n + "-" : false
                            }
                        }, CHILD: function (e, t, n, r, i) {
                            var a = e.slice(0, 3) !== "nth", o = e.slice(-4) !== "last", s = t === "of-type";
                            return r === 1 && i === 0 ? function (e) {
                                return !!e.parentNode
                            } : function (t, n, u) {
                                var l, c, f, p, d, h, m = a !== o ? "nextSibling" : "previousSibling", g = t.parentNode,
                                    y = s && t.nodeName.toLowerCase(), v = !u && !s, b = false;
                                if (g) {
                                    if (a) {
                                        while (m) {
                                            p = t;
                                            while (p = p[m]) {
                                                if (s ? p.nodeName.toLowerCase() === y : p.nodeType === 1) {
                                                    return false
                                                }
                                            }
                                            h = m = e === "only" && !h && "nextSibling"
                                        }
                                        return true
                                    }
                                    h = [o ? g.firstChild : g.lastChild];
                                    if (o && v) {
                                        p = g;
                                        f = p[w] || (p[w] = {});
                                        c = f[p.uniqueID] || (f[p.uniqueID] = {});
                                        l = c[e] || [];
                                        d = l[0] === T && l[1];
                                        b = d && l[2];
                                        p = d && g.childNodes[d];
                                        while (p = ++d && p && p[m] || (b = d = 0) || h.pop()) {
                                            if (p.nodeType === 1 && ++b && p === t) {
                                                c[e] = [T, d, b];
                                                break
                                            }
                                        }
                                    } else {
                                        if (v) {
                                            p = t;
                                            f = p[w] || (p[w] = {});
                                            c = f[p.uniqueID] || (f[p.uniqueID] = {});
                                            l = c[e] || [];
                                            d = l[0] === T && l[1];
                                            b = d
                                        }
                                        if (b === false) {
                                            while (p = ++d && p && p[m] || (b = d = 0) || h.pop()) {
                                                if ((s ? p.nodeName.toLowerCase() === y : p.nodeType === 1) && ++b) {
                                                    if (v) {
                                                        f = p[w] || (p[w] = {});
                                                        c = f[p.uniqueID] || (f[p.uniqueID] = {});
                                                        c[e] = [T, b]
                                                    }
                                                    if (p === t) {
                                                        break
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    b -= i;
                                    return b === r || b % r === 0 && b / r >= 0
                                }
                            }
                        }, PSEUDO: function (e, t) {
                            var n,
                                i = r.pseudos[e] || r.setFilters[e.toLowerCase()] || ae.error("unsupported pseudo: " + e);
                            if (i[w]) {
                                return i(t)
                            }
                            if (i.length > 1) {
                                n = [e, e, "", t];
                                return r.setFilters.hasOwnProperty(e.toLowerCase()) ? se((function (e, n) {
                                    var r, a = i(e, t), o = a.length;
                                    while (o--) {
                                        r = R(e, a[o]);
                                        e[r] = !(n[r] = a[o])
                                    }
                                })) : function (e) {
                                    return i(e, 0, n)
                                }
                            }
                            return i
                        }
                    },
                    pseudos: {
                        not: se((function (e) {
                            var t = [], n = [], r = s(e.replace(B, "$1"));
                            return r[w] ? se((function (e, t, n, i) {
                                var a, o = r(e, null, i, []), s = e.length;
                                while (s--) {
                                    if (a = o[s]) {
                                        e[s] = !(t[s] = a)
                                    }
                                }
                            })) : function (e, i, a) {
                                t[0] = e;
                                r(t, null, a, n);
                                t[0] = null;
                                return !n.pop()
                            }
                        })), has: se((function (e) {
                            return function (t) {
                                return ae(e, t).length > 0
                            }
                        })), contains: se((function (e) {
                            e = e.replace(Z, ee);
                            return function (t) {
                                return (t.textContent || t.innerText || i(t)).indexOf(e) > -1
                            }
                        })), lang: se((function (e) {
                            if (!V.test(e || "")) {
                                ae.error("unsupported lang: " + e)
                            }
                            e = e.replace(Z, ee).toLowerCase();
                            return function (t) {
                                var n;
                                do {
                                    if (n = m ? t.lang : t.getAttribute("xml:lang") || t.getAttribute("lang")) {
                                        n = n.toLowerCase();
                                        return n === e || n.indexOf(e + "-") === 0
                                    }
                                } while ((t = t.parentNode) && t.nodeType === 1);
                                return false
                            }
                        })), target: function (t) {
                            var n = e.location && e.location.hash;
                            return n && n.slice(1) === t.id
                        }, root: function (e) {
                            return e === h
                        }, focus: function (e) {
                            return e === d.activeElement && (!d.hasFocus || d.hasFocus()) && !!(e.type || e.href || ~e.tabIndex)
                        }, enabled: de(false), disabled: de(true), checked: function (e) {
                            var t = e.nodeName.toLowerCase();
                            return t === "input" && !!e.checked || t === "option" && !!e.selected
                        }, selected: function (e) {
                            if (e.parentNode) {
                                e.parentNode.selectedIndex
                            }
                            return e.selected === true
                        }, empty: function (e) {
                            for (e = e.firstChild; e; e = e.nextSibling) {
                                if (e.nodeType < 6) {
                                    return false
                                }
                            }
                            return true
                        }, parent: function (e) {
                            return !r.pseudos["empty"](e)
                        }, header: function (e) {
                            return X.test(e.nodeName)
                        }, input: function (e) {
                            return z.test(e.nodeName)
                        }, button: function (e) {
                            var t = e.nodeName.toLowerCase();
                            return t === "input" && e.type === "button" || t === "button"
                        }, text: function (e) {
                            var t;
                            return e.nodeName.toLowerCase() === "input" && e.type === "text" && ((t = e.getAttribute("type")) == null || t.toLowerCase() === "text")
                        }, first: he((function () {
                            return [0]
                        })), last: he((function (e, t) {
                            return [t - 1]
                        })), eq: he((function (e, t, n) {
                            return [n < 0 ? n + t : n]
                        })), even: he((function (e, t) {
                            var n = 0;
                            for (; n < t; n += 2) {
                                e.push(n)
                            }
                            return e
                        })), odd: he((function (e, t) {
                            var n = 1;
                            for (; n < t; n += 2) {
                                e.push(n)
                            }
                            return e
                        })), lt: he((function (e, t, n) {
                            var r = n < 0 ? n + t : n;
                            for (; --r >= 0;) {
                                e.push(r)
                            }
                            return e
                        })), gt: he((function (e, t, n) {
                            var r = n < 0 ? n + t : n;
                            for (; ++r < t;) {
                                e.push(r)
                            }
                            return e
                        }))
                    }
                };
                r.pseudos["nth"] = r.pseudos["eq"];
                for (t in {radio: true, checkbox: true, file: true, password: true, image: true}) {
                    r.pseudos[t] = fe(t)
                }
                for (t in {submit: true, reset: true}) {
                    r.pseudos[t] = pe(t)
                }

                function ge() {
                }

                ge.prototype = r.filters = r.pseudos;
                r.setFilters = new ge;
                o = ae.tokenize = function (e, t) {
                    var n, i, a, o, s, u, l, c = C[e + " "];
                    if (c) {
                        return t ? 0 : c.slice(0)
                    }
                    s = e;
                    u = [];
                    l = r.preFilter;
                    while (s) {
                        if (!n || (i = U.exec(s))) {
                            if (i) {
                                s = s.slice(i[0].length) || s
                            }
                            u.push(a = [])
                        }
                        n = false;
                        if (i = W.exec(s)) {
                            n = i.shift();
                            a.push({value: n, type: i[0].replace(B, " ")});
                            s = s.slice(n.length)
                        }
                        for (o in r.filter) {
                            if ((i = G[o].exec(s)) && (!l[o] || (i = l[o](i)))) {
                                n = i.shift();
                                a.push({value: n, type: o, matches: i});
                                s = s.slice(n.length)
                            }
                        }
                        if (!n) {
                            break
                        }
                    }
                    return t ? s.length : s ? ae.error(e) : C(e, u).slice(0)
                };

                function ye(e) {
                    var t = 0, n = e.length, r = "";
                    for (; t < n; t++) {
                        r += e[t].value
                    }
                    return r
                }

                function ve(e, t, n) {
                    var r = t.dir, i = t.next, a = i || r, o = n && a === "parentNode", s = k++;
                    return t.first ? function (t, n, i) {
                        while (t = t[r]) {
                            if (t.nodeType === 1 || o) {
                                return e(t, n, i)
                            }
                        }
                        return false
                    } : function (t, n, u) {
                        var l, c, f, p = [T, s];
                        if (u) {
                            while (t = t[r]) {
                                if (t.nodeType === 1 || o) {
                                    if (e(t, n, u)) {
                                        return true
                                    }
                                }
                            }
                        } else {
                            while (t = t[r]) {
                                if (t.nodeType === 1 || o) {
                                    f = t[w] || (t[w] = {});
                                    c = f[t.uniqueID] || (f[t.uniqueID] = {});
                                    if (i && i === t.nodeName.toLowerCase()) {
                                        t = t[r] || t
                                    } else if ((l = c[a]) && l[0] === T && l[1] === s) {
                                        return p[2] = l[2]
                                    } else {
                                        c[a] = p;
                                        if (p[2] = e(t, n, u)) {
                                            return true
                                        }
                                    }
                                }
                            }
                        }
                        return false
                    }
                }

                function be(e) {
                    return e.length > 1 ? function (t, n, r) {
                        var i = e.length;
                        while (i--) {
                            if (!e[i](t, n, r)) {
                                return false
                            }
                        }
                        return true
                    } : e[0]
                }

                function we(e, t, n) {
                    var r = 0, i = t.length;
                    for (; r < i; r++) {
                        ae(e, t[r], n)
                    }
                    return n
                }

                function xe(e, t, n, r, i) {
                    var a, o = [], s = 0, u = e.length, l = t != null;
                    for (; s < u; s++) {
                        if (a = e[s]) {
                            if (!n || n(a, r, i)) {
                                o.push(a);
                                if (l) {
                                    t.push(s)
                                }
                            }
                        }
                    }
                    return o
                }

                function Te(e, t, n, r, i, a) {
                    if (r && !r[w]) {
                        r = Te(r)
                    }
                    if (i && !i[w]) {
                        i = Te(i, a)
                    }
                    return se((function (a, o, s, u) {
                        var l, c, f, p = [], d = [], h = o.length, m = a || we(t || "*", s.nodeType ? [s] : s, []),
                            g = e && (a || !t) ? xe(m, p, e, s, u) : m, y = n ? i || (a ? e : h || r) ? [] : o : g;
                        if (n) {
                            n(g, y, s, u)
                        }
                        if (r) {
                            l = xe(y, d);
                            r(l, [], s, u);
                            c = l.length;
                            while (c--) {
                                if (f = l[c]) {
                                    y[d[c]] = !(g[d[c]] = f)
                                }
                            }
                        }
                        if (a) {
                            if (i || e) {
                                if (i) {
                                    l = [];
                                    c = y.length;
                                    while (c--) {
                                        if (f = y[c]) {
                                            l.push(g[c] = f)
                                        }
                                    }
                                    i(null, y = [], l, u)
                                }
                                c = y.length;
                                while (c--) {
                                    if ((f = y[c]) && (l = i ? R(a, f) : p[c]) > -1) {
                                        a[l] = !(o[l] = f)
                                    }
                                }
                            }
                        } else {
                            y = xe(y === o ? y.splice(h, y.length) : y);
                            if (i) {
                                i(null, o, y, u)
                            } else {
                                P.apply(o, y)
                            }
                        }
                    }))
                }

                function ke(e) {
                    var t, n, i, a = e.length, o = r.relative[e[0].type], s = o || r.relative[" "], u = o ? 1 : 0,
                        c = ve((function (e) {
                            return e === t
                        }), s, true), f = ve((function (e) {
                            return R(t, e) > -1
                        }), s, true), p = [function (e, n, r) {
                            var i = !o && (r || n !== l) || ((t = n).nodeType ? c(e, n, r) : f(e, n, r));
                            t = null;
                            return i
                        }];
                    for (; u < a; u++) {
                        if (n = r.relative[e[u].type]) {
                            p = [ve(be(p), n)]
                        } else {
                            n = r.filter[e[u].type].apply(null, e[u].matches);
                            if (n[w]) {
                                i = ++u;
                                for (; i < a; i++) {
                                    if (r.relative[e[i].type]) {
                                        break
                                    }
                                }
                                return Te(u > 1 && be(p), u > 1 && ye(e.slice(0, u - 1).concat({value: e[u - 2].type === " " ? "*" : ""})).replace(B, "$1"), n, u < i && ke(e.slice(u, i)), i < a && ke(e = e.slice(i)), i < a && ye(e))
                            }
                            p.push(n)
                        }
                    }
                    return be(p)
                }

                function Se(e, t) {
                    var n = t.length > 0, i = e.length > 0, a = function (a, o, s, u, c) {
                        var f, h, g, y = 0, v = "0", b = a && [], w = [], x = l, k = a || i && r.find["TAG"]("*", c),
                            S = T += x == null ? 1 : Math.random() || .1, C = k.length;
                        if (c) {
                            l = o === d || o || c
                        }
                        for (; v !== C && (f = k[v]) != null; v++) {
                            if (i && f) {
                                h = 0;
                                if (!o && f.ownerDocument !== d) {
                                    p(f);
                                    s = !m
                                }
                                while (g = e[h++]) {
                                    if (g(f, o || d, s)) {
                                        u.push(f);
                                        break
                                    }
                                }
                                if (c) {
                                    T = S
                                }
                            }
                            if (n) {
                                if (f = !g && f) {
                                    y--
                                }
                                if (a) {
                                    b.push(f)
                                }
                            }
                        }
                        y += v;
                        if (n && v !== y) {
                            h = 0;
                            while (g = t[h++]) {
                                g(b, w, o, s)
                            }
                            if (a) {
                                if (y > 0) {
                                    while (v--) {
                                        if (!(b[v] || w[v])) {
                                            w[v] = N.call(u)
                                        }
                                    }
                                }
                                w = xe(w)
                            }
                            P.apply(u, w);
                            if (c && !a && w.length > 0 && y + t.length > 1) {
                                ae.uniqueSort(u)
                            }
                        }
                        if (c) {
                            T = S;
                            l = x
                        }
                        return b
                    };
                    return n ? se(a) : a
                }

                s = ae.compile = function (e, t) {
                    var n, r = [], i = [], a = A[e + " "];
                    if (!a) {
                        if (!t) {
                            t = o(e)
                        }
                        n = t.length;
                        while (n--) {
                            a = ke(t[n]);
                            if (a[w]) {
                                r.push(a)
                            } else {
                                i.push(a)
                            }
                        }
                        a = A(e, Se(i, r));
                        a.selector = e
                    }
                    return a
                };
                u = ae.select = function (e, t, n, i) {
                    var a, u, l, c, f, p = typeof e === "function" && e, d = !i && o(e = p.selector || e);
                    n = n || [];
                    if (d.length === 1) {
                        u = d[0] = d[0].slice(0);
                        if (u.length > 2 && (l = u[0]).type === "ID" && t.nodeType === 9 && m && r.relative[u[1].type]) {
                            t = (r.find["ID"](l.matches[0].replace(Z, ee), t) || [])[0];
                            if (!t) {
                                return n
                            } else if (p) {
                                t = t.parentNode
                            }
                            e = e.slice(u.shift().value.length)
                        }
                        a = G["needsContext"].test(e) ? 0 : u.length;
                        while (a--) {
                            l = u[a];
                            if (r.relative[c = l.type]) {
                                break
                            }
                            if (f = r.find[c]) {
                                if (i = f(l.matches[0].replace(Z, ee), Y.test(u[0].type) && me(t.parentNode) || t)) {
                                    u.splice(a, 1);
                                    e = i.length && ye(u);
                                    if (!e) {
                                        P.apply(n, i);
                                        return n
                                    }
                                    break
                                }
                            }
                        }
                    }
                    (p || s(e, d))(i, t, !m, n, !t || Y.test(e) && me(t.parentNode) || t);
                    return n
                };
                n.sortStable = w.split("").sort(_).join("") === w;
                n.detectDuplicates = !!f;
                p();
                n.sortDetached = ue((function (e) {
                    return e.compareDocumentPosition(d.createElement("fieldset")) & 1
                }));
                if (!ue((function (e) {
                    e.innerHTML = "<a href='#'></a>";
                    return e.firstChild.getAttribute("href") === "#"
                }))) {
                    le("type|href|height|width", (function (e, t, n) {
                        if (!n) {
                            return e.getAttribute(t, t.toLowerCase() === "type" ? 1 : 2)
                        }
                    }))
                }
                if (!n.attributes || !ue((function (e) {
                    e.innerHTML = "<input/>";
                    e.firstChild.setAttribute("value", "");
                    return e.firstChild.getAttribute("value") === ""
                }))) {
                    le("value", (function (e, t, n) {
                        if (!n && e.nodeName.toLowerCase() === "input") {
                            return e.defaultValue
                        }
                    }))
                }
                if (!ue((function (e) {
                    return e.getAttribute("disabled") == null
                }))) {
                    le(j, (function (e, t, n) {
                        var r;
                        if (!n) {
                            return e[t] === true ? t.toLowerCase() : (r = e.getAttributeNode(t)) && r.specified ? r.value : null
                        }
                    }))
                }
                return ae
            }(e);
        y.find = k;
        y.expr = k.selectors;
        y.expr[":"] = y.expr.pseudos;
        y.uniqueSort = y.unique = k.uniqueSort;
        y.text = k.getText;
        y.isXMLDoc = k.isXML;
        y.contains = k.contains;
        y.escapeSelector = k.escape;
        var S = function (e, t, n) {
            var r = [], i = n !== undefined;
            while ((e = e[t]) && e.nodeType !== 9) {
                if (e.nodeType === 1) {
                    if (i && y(e).is(n)) {
                        break
                    }
                    r.push(e)
                }
            }
            return r
        };
        var C = function (e, t) {
            var n = [];
            for (; e; e = e.nextSibling) {
                if (e.nodeType === 1 && e !== t) {
                    n.push(e)
                }
            }
            return n
        };
        var A = y.expr.match.needsContext;
        var _ = /^<([a-z][^\/\0>:\x20\t\r\n\f]*)[\x20\t\r\n\f]*\/?>(?:<\/\1>|)$/i;
        var L = /^.[^:#\[\.,]*$/;

        function E(e, t, n) {
            if (y.isFunction(t)) {
                return y.grep(e, (function (e, r) {
                    return !!t.call(e, r, e) !== n
                }))
            }
            if (t.nodeType) {
                return y.grep(e, (function (e) {
                    return e === t !== n
                }))
            }
            if (typeof t !== "string") {
                return y.grep(e, (function (e) {
                    return u.call(t, e) > -1 !== n
                }))
            }
            if (L.test(t)) {
                return y.filter(t, e, n)
            }
            t = y.filter(t, e);
            return y.grep(e, (function (e) {
                return u.call(t, e) > -1 !== n && e.nodeType === 1
            }))
        }

        y.filter = function (e, t, n) {
            var r = t[0];
            if (n) {
                e = ":not(" + e + ")"
            }
            if (t.length === 1 && r.nodeType === 1) {
                return y.find.matchesSelector(r, e) ? [r] : []
            }
            return y.find.matches(e, y.grep(t, (function (e) {
                return e.nodeType === 1
            })))
        };
        y.fn.extend({
            find: function (e) {
                var t, n, r = this.length, i = this;
                if (typeof e !== "string") {
                    return this.pushStack(y(e).filter((function () {
                        for (t = 0; t < r; t++) {
                            if (y.contains(i[t], this)) {
                                return true
                            }
                        }
                    })))
                }
                n = this.pushStack([]);
                for (t = 0; t < r; t++) {
                    y.find(e, i[t], n)
                }
                return r > 1 ? y.uniqueSort(n) : n
            }, filter: function (e) {
                return this.pushStack(E(this, e || [], false))
            }, not: function (e) {
                return this.pushStack(E(this, e || [], true))
            }, is: function (e) {
                return !!E(this, typeof e === "string" && A.test(e) ? y(e) : e || [], false).length
            }
        });
        var N, D = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]+))$/, P = y.fn.init = function (e, t, n) {
            var i, a;
            if (!e) {
                return this
            }
            n = n || N;
            if (typeof e === "string") {
                if (e[0] === "<" && e[e.length - 1] === ">" && e.length >= 3) {
                    i = [null, e, null]
                } else {
                    i = D.exec(e)
                }
                if (i && (i[1] || !t)) {
                    if (i[1]) {
                        t = t instanceof y ? t[0] : t;
                        y.merge(this, y.parseHTML(i[1], t && t.nodeType ? t.ownerDocument || t : r, true));
                        if (_.test(i[1]) && y.isPlainObject(t)) {
                            for (i in t) {
                                if (y.isFunction(this[i])) {
                                    this[i](t[i])
                                } else {
                                    this.attr(i, t[i])
                                }
                            }
                        }
                        return this
                    } else {
                        a = r.getElementById(i[2]);
                        if (a) {
                            this[0] = a;
                            this.length = 1
                        }
                        return this
                    }
                } else if (!t || t.jquery) {
                    return (t || n).find(e)
                } else {
                    return this.constructor(t).find(e)
                }
            } else if (e.nodeType) {
                this[0] = e;
                this.length = 1;
                return this
            } else if (y.isFunction(e)) {
                return n.ready !== undefined ? n.ready(e) : e(y)
            }
            return y.makeArray(e, this)
        };
        P.prototype = y.fn;
        N = y(r);
        var I = /^(?:parents|prev(?:Until|All))/, R = {children: true, contents: true, next: true, prev: true};
        y.fn.extend({
            has: function (e) {
                var t = y(e, this), n = t.length;
                return this.filter((function () {
                    var e = 0;
                    for (; e < n; e++) {
                        if (y.contains(this, t[e])) {
                            return true
                        }
                    }
                }))
            }, closest: function (e, t) {
                var n, r = 0, i = this.length, a = [], o = typeof e !== "string" && y(e);
                if (!A.test(e)) {
                    for (; r < i; r++) {
                        for (n = this[r]; n && n !== t; n = n.parentNode) {
                            if (n.nodeType < 11 && (o ? o.index(n) > -1 : n.nodeType === 1 && y.find.matchesSelector(n, e))) {
                                a.push(n);
                                break
                            }
                        }
                    }
                }
                return this.pushStack(a.length > 1 ? y.uniqueSort(a) : a)
            }, index: function (e) {
                if (!e) {
                    return this[0] && this[0].parentNode ? this.first().prevAll().length : -1
                }
                if (typeof e === "string") {
                    return u.call(y(e), this[0])
                }
                return u.call(this, e.jquery ? e[0] : e)
            }, add: function (e, t) {
                return this.pushStack(y.uniqueSort(y.merge(this.get(), y(e, t))))
            }, addBack: function (e) {
                return this.add(e == null ? this.prevObject : this.prevObject.filter(e))
            }
        });

        function j(e, t) {
            while ((e = e[t]) && e.nodeType !== 1) {
            }
            return e
        }

        y.each({
            parent: function (e) {
                var t = e.parentNode;
                return t && t.nodeType !== 11 ? t : null
            }, parents: function (e) {
                return S(e, "parentNode")
            }, parentsUntil: function (e, t, n) {
                return S(e, "parentNode", n)
            }, next: function (e) {
                return j(e, "nextSibling")
            }, prev: function (e) {
                return j(e, "previousSibling")
            }, nextAll: function (e) {
                return S(e, "nextSibling")
            }, prevAll: function (e) {
                return S(e, "previousSibling")
            }, nextUntil: function (e, t, n) {
                return S(e, "nextSibling", n)
            }, prevUntil: function (e, t, n) {
                return S(e, "previousSibling", n)
            }, siblings: function (e) {
                return C((e.parentNode || {}).firstChild, e)
            }, children: function (e) {
                return C(e.firstChild)
            }, contents: function (e) {
                return e.contentDocument || y.merge([], e.childNodes)
            }
        }, (function (e, t) {
            y.fn[e] = function (n, r) {
                var i = y.map(this, t, n);
                if (e.slice(-5) !== "Until") {
                    r = n
                }
                if (r && typeof r === "string") {
                    i = y.filter(r, i)
                }
                if (this.length > 1) {
                    if (!R[e]) {
                        y.uniqueSort(i)
                    }
                    if (I.test(e)) {
                        i.reverse()
                    }
                }
                return this.pushStack(i)
            }
        }));
        var M = /[^\x20\t\r\n\f]+/g;

        function H(e) {
            var t = {};
            y.each(e.match(M) || [], (function (e, n) {
                t[n] = true
            }));
            return t
        }

        y.Callbacks = function (e) {
            e = typeof e === "string" ? H(e) : y.extend({}, e);
            var t, n, r, i, a = [], o = [], s = -1, u = function () {
                i = e.once;
                r = t = true;
                for (; o.length; s = -1) {
                    n = o.shift();
                    while (++s < a.length) {
                        if (a[s].apply(n[0], n[1]) === false && e.stopOnFalse) {
                            s = a.length;
                            n = false
                        }
                    }
                }
                if (!e.memory) {
                    n = false
                }
                t = false;
                if (i) {
                    if (n) {
                        a = []
                    } else {
                        a = ""
                    }
                }
            }, l = {
                add: function () {
                    if (a) {
                        if (n && !t) {
                            s = a.length - 1;
                            o.push(n)
                        }
                        (function t(n) {
                            y.each(n, (function (n, r) {
                                if (y.isFunction(r)) {
                                    if (!e.unique || !l.has(r)) {
                                        a.push(r)
                                    }
                                } else if (r && r.length && y.type(r) !== "string") {
                                    t(r)
                                }
                            }))
                        })(arguments);
                        if (n && !t) {
                            u()
                        }
                    }
                    return this
                }, remove: function () {
                    y.each(arguments, (function (e, t) {
                        var n;
                        while ((n = y.inArray(t, a, n)) > -1) {
                            a.splice(n, 1);
                            if (n <= s) {
                                s--
                            }
                        }
                    }));
                    return this
                }, has: function (e) {
                    return e ? y.inArray(e, a) > -1 : a.length > 0
                }, empty: function () {
                    if (a) {
                        a = []
                    }
                    return this
                }, disable: function () {
                    i = o = [];
                    a = n = "";
                    return this
                }, disabled: function () {
                    return !a
                }, lock: function () {
                    i = o = [];
                    if (!n && !t) {
                        a = n = ""
                    }
                    return this
                }, locked: function () {
                    return !!i
                }, fireWith: function (e, n) {
                    if (!i) {
                        n = n || [];
                        n = [e, n.slice ? n.slice() : n];
                        o.push(n);
                        if (!t) {
                            u()
                        }
                    }
                    return this
                }, fire: function () {
                    l.fireWith(this, arguments);
                    return this
                }, fired: function () {
                    return !!r
                }
            };
            return l
        };

        function q(e) {
            return e
        }

        function O(e) {
            throw e
        }

        function F(e, t, n) {
            var r;
            try {
                if (e && y.isFunction(r = e.promise)) {
                    r.call(e).done(t).fail(n)
                } else if (e && y.isFunction(r = e.then)) {
                    r.call(e, t, n)
                } else {
                    t.call(undefined, e)
                }
            } catch (e) {
                n.call(undefined, e)
            }
        }

        y.extend({
            Deferred: function (t) {
                var n = [["notify", "progress", y.Callbacks("memory"), y.Callbacks("memory"), 2], ["resolve", "done", y.Callbacks("once memory"), y.Callbacks("once memory"), 0, "resolved"], ["reject", "fail", y.Callbacks("once memory"), y.Callbacks("once memory"), 1, "rejected"]],
                    r = "pending", i = {
                        state: function () {
                            return r
                        }, always: function () {
                            a.done(arguments).fail(arguments);
                            return this
                        }, catch: function (e) {
                            return i.then(null, e)
                        }, pipe: function () {
                            var e = arguments;
                            return y.Deferred((function (t) {
                                y.each(n, (function (n, r) {
                                    var i = y.isFunction(e[r[4]]) && e[r[4]];
                                    a[r[1]]((function () {
                                        var e = i && i.apply(this, arguments);
                                        if (e && y.isFunction(e.promise)) {
                                            e.promise().progress(t.notify).done(t.resolve).fail(t.reject)
                                        } else {
                                            t[r[0] + "With"](this, i ? [e] : arguments)
                                        }
                                    }))
                                }));
                                e = null
                            })).promise()
                        }, then: function (t, r, i) {
                            var a = 0;

                            function o(t, n, r, i) {
                                return function () {
                                    var s = this, u = arguments, l = function () {
                                        var e, l;
                                        if (t < a) {
                                            return
                                        }
                                        e = r.apply(s, u);
                                        if (e === n.promise()) {
                                            throw new TypeError("Thenable self-resolution")
                                        }
                                        l = e && (typeof e === "object" || typeof e === "function") && e.then;
                                        if (y.isFunction(l)) {
                                            if (i) {
                                                l.call(e, o(a, n, q, i), o(a, n, O, i))
                                            } else {
                                                a++;
                                                l.call(e, o(a, n, q, i), o(a, n, O, i), o(a, n, q, n.notifyWith))
                                            }
                                        } else {
                                            if (r !== q) {
                                                s = undefined;
                                                u = [e]
                                            }
                                            (i || n.resolveWith)(s, u)
                                        }
                                    }, c = i ? l : function () {
                                        try {
                                            l()
                                        } catch (e) {
                                            if (y.Deferred.exceptionHook) {
                                                y.Deferred.exceptionHook(e, c.stackTrace)
                                            }
                                            if (t + 1 >= a) {
                                                if (r !== O) {
                                                    s = undefined;
                                                    u = [e]
                                                }
                                                n.rejectWith(s, u)
                                            }
                                        }
                                    };
                                    if (t) {
                                        c()
                                    } else {
                                        if (y.Deferred.getStackHook) {
                                            c.stackTrace = y.Deferred.getStackHook()
                                        }
                                        e.setTimeout(c)
                                    }
                                }
                            }

                            return y.Deferred((function (e) {
                                n[0][3].add(o(0, e, y.isFunction(i) ? i : q, e.notifyWith));
                                n[1][3].add(o(0, e, y.isFunction(t) ? t : q));
                                n[2][3].add(o(0, e, y.isFunction(r) ? r : O))
                            })).promise()
                        }, promise: function (e) {
                            return e != null ? y.extend(e, i) : i
                        }
                    }, a = {};
                y.each(n, (function (e, t) {
                    var o = t[2], s = t[5];
                    i[t[1]] = o.add;
                    if (s) {
                        o.add((function () {
                            r = s
                        }), n[3 - e][2].disable, n[0][2].lock)
                    }
                    o.add(t[3].fire);
                    a[t[0]] = function () {
                        a[t[0] + "With"](this === a ? undefined : this, arguments);
                        return this
                    };
                    a[t[0] + "With"] = o.fireWith
                }));
                i.promise(a);
                if (t) {
                    t.call(a, a)
                }
                return a
            }, when: function (e) {
                var t = arguments.length, n = t, r = Array(n), i = a.call(arguments), o = y.Deferred(),
                    s = function (e) {
                        return function (n) {
                            r[e] = this;
                            i[e] = arguments.length > 1 ? a.call(arguments) : n;
                            if (!--t) {
                                o.resolveWith(r, i)
                            }
                        }
                    };
                if (t <= 1) {
                    F(e, o.done(s(n)).resolve, o.reject);
                    if (o.state() === "pending" || y.isFunction(i[n] && i[n].then)) {
                        return o.then()
                    }
                }
                while (n--) {
                    F(i[n], s(n), o.reject)
                }
                return o.promise()
            }
        });
        var B = /^(Eval|Internal|Range|Reference|Syntax|Type|URI)Error$/;
        y.Deferred.exceptionHook = function (t, n) {
            if (e.console && e.console.warn && t && B.test(t.name)) {
                e.console.warn("jQuery.Deferred exception: " + t.message, t.stack, n)
            }
        };
        y.readyException = function (t) {
            e.setTimeout((function () {
                throw t
            }))
        };
        var U = y.Deferred();
        y.fn.ready = function (e) {
            U.then(e).catch((function (e) {
                y.readyException(e)
            }));
            return this
        };
        y.extend({
            isReady: false, readyWait: 1, holdReady: function (e) {
                if (e) {
                    y.readyWait++
                } else {
                    y.ready(true)
                }
            }, ready: function (e) {
                if (e === true ? --y.readyWait : y.isReady) {
                    return
                }
                y.isReady = true;
                if (e !== true && --y.readyWait > 0) {
                    return
                }
                U.resolveWith(r, [y])
            }
        });
        y.ready.then = U.then;

        function W() {
            r.removeEventListener("DOMContentLoaded", W);
            e.removeEventListener("load", W);
            y.ready()
        }

        if (r.readyState === "complete" || r.readyState !== "loading" && !r.documentElement.doScroll) {
            e.setTimeout(y.ready)
        } else {
            r.addEventListener("DOMContentLoaded", W);
            e.addEventListener("load", W)
        }
        var K = function (e, t, n, r, i, a, o) {
            var s = 0, u = e.length, l = n == null;
            if (y.type(n) === "object") {
                i = true;
                for (s in n) {
                    K(e, t, s, n[s], true, a, o)
                }
            } else if (r !== undefined) {
                i = true;
                if (!y.isFunction(r)) {
                    o = true
                }
                if (l) {
                    if (o) {
                        t.call(e, r);
                        t = null
                    } else {
                        l = t;
                        t = function (e, t, n) {
                            return l.call(y(e), n)
                        }
                    }
                }
                if (t) {
                    for (; s < u; s++) {
                        t(e[s], n, o ? r : r.call(e[s], s, t(e[s], n)))
                    }
                }
            }
            if (i) {
                return e
            }
            if (l) {
                return t.call(e)
            }
            return u ? t(e[0], n) : a
        };
        var $ = function (e) {
            return e.nodeType === 1 || e.nodeType === 9 || !+e.nodeType
        };

        function V() {
            this.expando = y.expando + V.uid++
        }

        V.uid = 1;
        V.prototype = {
            cache: function (e) {
                var t = e[this.expando];
                if (!t) {
                    t = {};
                    if ($(e)) {
                        if (e.nodeType) {
                            e[this.expando] = t
                        } else {
                            Object.defineProperty(e, this.expando, {value: t, configurable: true})
                        }
                    }
                }
                return t
            }, set: function (e, t, n) {
                var r, i = this.cache(e);
                if (typeof t === "string") {
                    i[y.camelCase(t)] = n
                } else {
                    for (r in t) {
                        i[y.camelCase(r)] = t[r]
                    }
                }
                return i
            }, get: function (e, t) {
                return t === undefined ? this.cache(e) : e[this.expando] && e[this.expando][y.camelCase(t)]
            }, access: function (e, t, n) {
                if (t === undefined || t && typeof t === "string" && n === undefined) {
                    return this.get(e, t)
                }
                this.set(e, t, n);
                return n !== undefined ? n : t
            }, remove: function (e, t) {
                var n, r = e[this.expando];
                if (r === undefined) {
                    return
                }
                if (t !== undefined) {
                    if (y.isArray(t)) {
                        t = t.map(y.camelCase)
                    } else {
                        t = y.camelCase(t);
                        t = t in r ? [t] : t.match(M) || []
                    }
                    n = t.length;
                    while (n--) {
                        delete r[t[n]]
                    }
                }
                if (t === undefined || y.isEmptyObject(r)) {
                    if (e.nodeType) {
                        e[this.expando] = undefined
                    } else {
                        delete e[this.expando]
                    }
                }
            }, hasData: function (e) {
                var t = e[this.expando];
                return t !== undefined && !y.isEmptyObject(t)
            }
        };
        var G = new V;
        var z = new V;
        var X = /^(?:\{[\w\W]*\}|\[[\w\W]*\])$/, J = /[A-Z]/g;

        function Q(e) {
            if (e === "true") {
                return true
            }
            if (e === "false") {
                return false
            }
            if (e === "null") {
                return null
            }
            if (e === +e + "") {
                return +e
            }
            if (X.test(e)) {
                return JSON.parse(e)
            }
            return e
        }

        function Y(e, t, n) {
            var r;
            if (n === undefined && e.nodeType === 1) {
                r = "data-" + t.replace(J, "-$&").toLowerCase();
                n = e.getAttribute(r);
                if (typeof n === "string") {
                    try {
                        n = Q(n)
                    } catch (e) {
                    }
                    z.set(e, t, n)
                } else {
                    n = undefined
                }
            }
            return n
        }

        y.extend({
            hasData: function (e) {
                return z.hasData(e) || G.hasData(e)
            }, data: function (e, t, n) {
                return z.access(e, t, n)
            }, removeData: function (e, t) {
                z.remove(e, t)
            }, _data: function (e, t, n) {
                return G.access(e, t, n)
            }, _removeData: function (e, t) {
                G.remove(e, t)
            }
        });
        y.fn.extend({
            data: function (e, t) {
                var n, r, i, a = this[0], o = a && a.attributes;
                if (e === undefined) {
                    if (this.length) {
                        i = z.get(a);
                        if (a.nodeType === 1 && !G.get(a, "hasDataAttrs")) {
                            n = o.length;
                            while (n--) {
                                if (o[n]) {
                                    r = o[n].name;
                                    if (r.indexOf("data-") === 0) {
                                        r = y.camelCase(r.slice(5));
                                        Y(a, r, i[r])
                                    }
                                }
                            }
                            G.set(a, "hasDataAttrs", true)
                        }
                    }
                    return i
                }
                if (typeof e === "object") {
                    return this.each((function () {
                        z.set(this, e)
                    }))
                }
                return K(this, (function (t) {
                    var n;
                    if (a && t === undefined) {
                        n = z.get(a, e);
                        if (n !== undefined) {
                            return n
                        }
                        n = Y(a, e);
                        if (n !== undefined) {
                            return n
                        }
                        return
                    }
                    this.each((function () {
                        z.set(this, e, t)
                    }))
                }), null, t, arguments.length > 1, null, true)
            }, removeData: function (e) {
                return this.each((function () {
                    z.remove(this, e)
                }))
            }
        });
        y.extend({
            queue: function (e, t, n) {
                var r;
                if (e) {
                    t = (t || "fx") + "queue";
                    r = G.get(e, t);
                    if (n) {
                        if (!r || y.isArray(n)) {
                            r = G.access(e, t, y.makeArray(n))
                        } else {
                            r.push(n)
                        }
                    }
                    return r || []
                }
            }, dequeue: function (e, t) {
                t = t || "fx";
                var n = y.queue(e, t), r = n.length, i = n.shift(), a = y._queueHooks(e, t), o = function () {
                    y.dequeue(e, t)
                };
                if (i === "inprogress") {
                    i = n.shift();
                    r--
                }
                if (i) {
                    if (t === "fx") {
                        n.unshift("inprogress")
                    }
                    delete a.stop;
                    i.call(e, o, a)
                }
                if (!r && a) {
                    a.empty.fire()
                }
            }, _queueHooks: function (e, t) {
                var n = t + "queueHooks";
                return G.get(e, n) || G.access(e, n, {
                    empty: y.Callbacks("once memory").add((function () {
                        G.remove(e, [t + "queue", n])
                    }))
                })
            }
        });
        y.fn.extend({
            queue: function (e, t) {
                var n = 2;
                if (typeof e !== "string") {
                    t = e;
                    e = "fx";
                    n--
                }
                if (arguments.length < n) {
                    return y.queue(this[0], e)
                }
                return t === undefined ? this : this.each((function () {
                    var n = y.queue(this, e, t);
                    y._queueHooks(this, e);
                    if (e === "fx" && n[0] !== "inprogress") {
                        y.dequeue(this, e)
                    }
                }))
            }, dequeue: function (e) {
                return this.each((function () {
                    y.dequeue(this, e)
                }))
            }, clearQueue: function (e) {
                return this.queue(e || "fx", [])
            }, promise: function (e, t) {
                var n, r = 1, i = y.Deferred(), a = this, o = this.length, s = function () {
                    if (!--r) {
                        i.resolveWith(a, [a])
                    }
                };
                if (typeof e !== "string") {
                    t = e;
                    e = undefined
                }
                e = e || "fx";
                while (o--) {
                    n = G.get(a[o], e + "queueHooks");
                    if (n && n.empty) {
                        r++;
                        n.empty.add(s)
                    }
                }
                s();
                return i.promise(t)
            }
        });
        var Z = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source;
        var ee = new RegExp("^(?:([+-])=|)(" + Z + ")([a-z%]*)$", "i");
        var te = ["Top", "Right", "Bottom", "Left"];
        var ne = function (e, t) {
            e = t || e;
            return e.style.display === "none" || e.style.display === "" && y.contains(e.ownerDocument, e) && y.css(e, "display") === "none"
        };
        var re = function (e, t, n, r) {
            var i, a, o = {};
            for (a in t) {
                o[a] = e.style[a];
                e.style[a] = t[a]
            }
            i = n.apply(e, r || []);
            for (a in t) {
                e.style[a] = o[a]
            }
            return i
        };

        function ie(e, t, n, r) {
            var i, a = 1, o = 20, s = r ? function () {
                    return r.cur()
                } : function () {
                    return y.css(e, t, "")
                }, u = s(), l = n && n[3] || (y.cssNumber[t] ? "" : "px"),
                c = (y.cssNumber[t] || l !== "px" && +u) && ee.exec(y.css(e, t));
            if (c && c[3] !== l) {
                l = l || c[3];
                n = n || [];
                c = +u || 1;
                do {
                    a = a || ".5";
                    c = c / a;
                    y.style(e, t, c + l)
                } while (a !== (a = s() / u) && a !== 1 && --o)
            }
            if (n) {
                c = +c || +u || 0;
                i = n[1] ? c + (n[1] + 1) * n[2] : +n[2];
                if (r) {
                    r.unit = l;
                    r.start = c;
                    r.end = i
                }
            }
            return i
        }

        var ae = {};

        function oe(e) {
            var t, n = e.ownerDocument, r = e.nodeName, i = ae[r];
            if (i) {
                return i
            }
            t = n.body.appendChild(n.createElement(r));
            i = y.css(t, "display");
            t.parentNode.removeChild(t);
            if (i === "none") {
                i = "block"
            }
            ae[r] = i;
            return i
        }

        function se(e, t) {
            var n, r, i = [], a = 0, o = e.length;
            for (; a < o; a++) {
                r = e[a];
                if (!r.style) {
                    continue
                }
                n = r.style.display;
                if (t) {
                    if (n === "none") {
                        i[a] = G.get(r, "display") || null;
                        if (!i[a]) {
                            r.style.display = ""
                        }
                    }
                    if (r.style.display === "" && ne(r)) {
                        i[a] = oe(r)
                    }
                } else {
                    if (n !== "none") {
                        i[a] = "none";
                        G.set(r, "display", n)
                    }
                }
            }
            for (a = 0; a < o; a++) {
                if (i[a] != null) {
                    e[a].style.display = i[a]
                }
            }
            return e
        }

        y.fn.extend({
            show: function () {
                return se(this, true)
            }, hide: function () {
                return se(this)
            }, toggle: function (e) {
                if (typeof e === "boolean") {
                    return e ? this.show() : this.hide()
                }
                return this.each((function () {
                    if (ne(this)) {
                        y(this).show()
                    } else {
                        y(this).hide()
                    }
                }))
            }
        });
        var ue = /^(?:checkbox|radio)$/i;
        var le = /<([a-z][^\/\0>\x20\t\r\n\f]+)/i;
        var ce = /^$|\/(?:java|ecma)script/i;
        var fe = {
            option: [1, "<select multiple='multiple'>", "</select>"],
            thead: [1, "<table>", "</table>"],
            col: [2, "<table><colgroup>", "</colgroup></table>"],
            tr: [2, "<table><tbody>", "</tbody></table>"],
            td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
            _default: [0, "", ""]
        };
        fe.optgroup = fe.option;
        fe.tbody = fe.tfoot = fe.colgroup = fe.caption = fe.thead;
        fe.th = fe.td;

        function pe(e, t) {
            var n;
            if (typeof e.getElementsByTagName !== "undefined") {
                n = e.getElementsByTagName(t || "*")
            } else if (typeof e.querySelectorAll !== "undefined") {
                n = e.querySelectorAll(t || "*")
            } else {
                n = []
            }
            if (t === undefined || t && y.nodeName(e, t)) {
                return y.merge([e], n)
            }
            return n
        }

        function de(e, t) {
            var n = 0, r = e.length;
            for (; n < r; n++) {
                G.set(e[n], "globalEval", !t || G.get(t[n], "globalEval"))
            }
        }

        var he = /<|&#?\w+;/;

        function me(e, t, n, r, i) {
            var a, o, s, u, l, c, f = t.createDocumentFragment(), p = [], d = 0, h = e.length;
            for (; d < h; d++) {
                a = e[d];
                if (a || a === 0) {
                    if (y.type(a) === "object") {
                        y.merge(p, a.nodeType ? [a] : a)
                    } else if (!he.test(a)) {
                        p.push(t.createTextNode(a))
                    } else {
                        o = o || f.appendChild(t.createElement("div"));
                        s = (le.exec(a) || ["", ""])[1].toLowerCase();
                        u = fe[s] || fe._default;
                        o.innerHTML = u[1] + y.htmlPrefilter(a) + u[2];
                        c = u[0];
                        while (c--) {
                            o = o.lastChild
                        }
                        y.merge(p, o.childNodes);
                        o = f.firstChild;
                        o.textContent = ""
                    }
                }
            }
            f.textContent = "";
            d = 0;
            while (a = p[d++]) {
                if (r && y.inArray(a, r) > -1) {
                    if (i) {
                        i.push(a)
                    }
                    continue
                }
                l = y.contains(a.ownerDocument, a);
                o = pe(f.appendChild(a), "script");
                if (l) {
                    de(o)
                }
                if (n) {
                    c = 0;
                    while (a = o[c++]) {
                        if (ce.test(a.type || "")) {
                            n.push(a)
                        }
                    }
                }
            }
            return f
        }

        (function () {
            var e = r.createDocumentFragment(), t = e.appendChild(r.createElement("div")), n = r.createElement("input");
            n.setAttribute("type", "radio");
            n.setAttribute("checked", "checked");
            n.setAttribute("name", "t");
            t.appendChild(n);
            h.checkClone = t.cloneNode(true).cloneNode(true).lastChild.checked;
            t.innerHTML = "<textarea>x</textarea>";
            h.noCloneChecked = !!t.cloneNode(true).lastChild.defaultValue
        })();
        var ge = r.documentElement;
        var ye = /^key/, ve = /^(?:mouse|pointer|contextmenu|drag|drop)|click/, be = /^([^.]*)(?:\.(.+)|)/;

        function we() {
            return true
        }

        function xe() {
            return false
        }

        function Te() {
            try {
                return r.activeElement
            } catch (e) {
            }
        }

        function ke(e, t, n, r, i, a) {
            var o, s;
            if (typeof t === "object") {
                if (typeof n !== "string") {
                    r = r || n;
                    n = undefined
                }
                for (s in t) {
                    ke(e, s, n, r, t[s], a)
                }
                return e
            }
            if (r == null && i == null) {
                i = n;
                r = n = undefined
            } else if (i == null) {
                if (typeof n === "string") {
                    i = r;
                    r = undefined
                } else {
                    i = r;
                    r = n;
                    n = undefined
                }
            }
            if (i === false) {
                i = xe
            } else if (!i) {
                return e
            }
            if (a === 1) {
                o = i;
                i = function (e) {
                    y().off(e);
                    return o.apply(this, arguments)
                };
                i.guid = o.guid || (o.guid = y.guid++)
            }
            return e.each((function () {
                y.event.add(this, t, i, r, n)
            }))
        }

        y.event = {
            global: {}, add: function (e, t, n, r, i) {
                var a, o, s, u, l, c, f, p, d, h, m, g = G.get(e);
                if (!g) {
                    return
                }
                if (n.handler) {
                    a = n;
                    n = a.handler;
                    i = a.selector
                }
                if (i) {
                    y.find.matchesSelector(ge, i)
                }
                if (!n.guid) {
                    n.guid = y.guid++
                }
                if (!(u = g.events)) {
                    u = g.events = {}
                }
                if (!(o = g.handle)) {
                    o = g.handle = function (t) {
                        return typeof y !== "undefined" && y.event.triggered !== t.type ? y.event.dispatch.apply(e, arguments) : undefined
                    }
                }
                t = (t || "").match(M) || [""];
                l = t.length;
                while (l--) {
                    s = be.exec(t[l]) || [];
                    d = m = s[1];
                    h = (s[2] || "").split(".").sort();
                    if (!d) {
                        continue
                    }
                    f = y.event.special[d] || {};
                    d = (i ? f.delegateType : f.bindType) || d;
                    f = y.event.special[d] || {};
                    c = y.extend({
                        type: d,
                        origType: m,
                        data: r,
                        handler: n,
                        guid: n.guid,
                        selector: i,
                        needsContext: i && y.expr.match.needsContext.test(i),
                        namespace: h.join(".")
                    }, a);
                    if (!(p = u[d])) {
                        p = u[d] = [];
                        p.delegateCount = 0;
                        if (!f.setup || f.setup.call(e, r, h, o) === false) {
                            if (e.addEventListener) {
                                e.addEventListener(d, o)
                            }
                        }
                    }
                    if (f.add) {
                        f.add.call(e, c);
                        if (!c.handler.guid) {
                            c.handler.guid = n.guid
                        }
                    }
                    if (i) {
                        p.splice(p.delegateCount++, 0, c)
                    } else {
                        p.push(c)
                    }
                    y.event.global[d] = true
                }
            }, remove: function (e, t, n, r, i) {
                var a, o, s, u, l, c, f, p, d, h, m, g = G.hasData(e) && G.get(e);
                if (!g || !(u = g.events)) {
                    return
                }
                t = (t || "").match(M) || [""];
                l = t.length;
                while (l--) {
                    s = be.exec(t[l]) || [];
                    d = m = s[1];
                    h = (s[2] || "").split(".").sort();
                    if (!d) {
                        for (d in u) {
                            y.event.remove(e, d + t[l], n, r, true)
                        }
                        continue
                    }
                    f = y.event.special[d] || {};
                    d = (r ? f.delegateType : f.bindType) || d;
                    p = u[d] || [];
                    s = s[2] && new RegExp("(^|\\.)" + h.join("\\.(?:.*\\.|)") + "(\\.|$)");
                    o = a = p.length;
                    while (a--) {
                        c = p[a];
                        if ((i || m === c.origType) && (!n || n.guid === c.guid) && (!s || s.test(c.namespace)) && (!r || r === c.selector || r === "**" && c.selector)) {
                            p.splice(a, 1);
                            if (c.selector) {
                                p.delegateCount--
                            }
                            if (f.remove) {
                                f.remove.call(e, c)
                            }
                        }
                    }
                    if (o && !p.length) {
                        if (!f.teardown || f.teardown.call(e, h, g.handle) === false) {
                            y.removeEvent(e, d, g.handle)
                        }
                        delete u[d]
                    }
                }
                if (y.isEmptyObject(u)) {
                    G.remove(e, "handle events")
                }
            }, dispatch: function (e) {
                var t = y.event.fix(e);
                var n, r, i, a, o, s, u = new Array(arguments.length), l = (G.get(this, "events") || {})[t.type] || [],
                    c = y.event.special[t.type] || {};
                u[0] = t;
                for (n = 1; n < arguments.length; n++) {
                    u[n] = arguments[n]
                }
                t.delegateTarget = this;
                if (c.preDispatch && c.preDispatch.call(this, t) === false) {
                    return
                }
                s = y.event.handlers.call(this, t, l);
                n = 0;
                while ((a = s[n++]) && !t.isPropagationStopped()) {
                    t.currentTarget = a.elem;
                    r = 0;
                    while ((o = a.handlers[r++]) && !t.isImmediatePropagationStopped()) {
                        if (!t.rnamespace || t.rnamespace.test(o.namespace)) {
                            t.handleObj = o;
                            t.data = o.data;
                            i = ((y.event.special[o.origType] || {}).handle || o.handler).apply(a.elem, u);
                            if (i !== undefined) {
                                if ((t.result = i) === false) {
                                    t.preventDefault();
                                    t.stopPropagation()
                                }
                            }
                        }
                    }
                }
                if (c.postDispatch) {
                    c.postDispatch.call(this, t)
                }
                return t.result
            }, handlers: function (e, t) {
                var n, r, i, a, o, s = [], u = t.delegateCount, l = e.target;
                if (u && l.nodeType && !(e.type === "click" && e.button >= 1)) {
                    for (; l !== this; l = l.parentNode || this) {
                        if (l.nodeType === 1 && !(e.type === "click" && l.disabled === true)) {
                            a = [];
                            o = {};
                            for (n = 0; n < u; n++) {
                                r = t[n];
                                i = r.selector + " ";
                                if (o[i] === undefined) {
                                    o[i] = r.needsContext ? y(i, this).index(l) > -1 : y.find(i, this, null, [l]).length
                                }
                                if (o[i]) {
                                    a.push(r)
                                }
                            }
                            if (a.length) {
                                s.push({elem: l, handlers: a})
                            }
                        }
                    }
                }
                l = this;
                if (u < t.length) {
                    s.push({elem: l, handlers: t.slice(u)})
                }
                return s
            }, addProp: function (e, t) {
                Object.defineProperty(y.Event.prototype, e, {
                    enumerable: true,
                    configurable: true,
                    get: y.isFunction(t) ? function () {
                        if (this.originalEvent) {
                            return t(this.originalEvent)
                        }
                    } : function () {
                        if (this.originalEvent) {
                            return this.originalEvent[e]
                        }
                    },
                    set: function (t) {
                        Object.defineProperty(this, e, {enumerable: true, configurable: true, writable: true, value: t})
                    }
                })
            }, fix: function (e) {
                return e[y.expando] ? e : new y.Event(e)
            }, special: {
                load: {noBubble: true}, focus: {
                    trigger: function () {
                        if (this !== Te() && this.focus) {
                            this.focus();
                            return false
                        }
                    }, delegateType: "focusin"
                }, blur: {
                    trigger: function () {
                        if (this === Te() && this.blur) {
                            this.blur();
                            return false
                        }
                    }, delegateType: "focusout"
                }, click: {
                    trigger: function () {
                        if (this.type === "checkbox" && this.click && y.nodeName(this, "input")) {
                            this.click();
                            return false
                        }
                    }, _default: function (e) {
                        return y.nodeName(e.target, "a")
                    }
                }, beforeunload: {
                    postDispatch: function (e) {
                        if (e.result !== undefined && e.originalEvent) {
                            e.originalEvent.returnValue = e.result
                        }
                    }
                }
            }
        };
        y.removeEvent = function (e, t, n) {
            if (e.removeEventListener) {
                e.removeEventListener(t, n)
            }
        };
        y.Event = function (e, t) {
            if (!(this instanceof y.Event)) {
                return new y.Event(e, t)
            }
            if (e && e.type) {
                this.originalEvent = e;
                this.type = e.type;
                this.isDefaultPrevented = e.defaultPrevented || e.defaultPrevented === undefined && e.returnValue === false ? we : xe;
                this.target = e.target && e.target.nodeType === 3 ? e.target.parentNode : e.target;
                this.currentTarget = e.currentTarget;
                this.relatedTarget = e.relatedTarget
            } else {
                this.type = e
            }
            if (t) {
                y.extend(this, t)
            }
            this.timeStamp = e && e.timeStamp || y.now();
            this[y.expando] = true
        };
        y.Event.prototype = {
            constructor: y.Event,
            isDefaultPrevented: xe,
            isPropagationStopped: xe,
            isImmediatePropagationStopped: xe,
            isSimulated: false,
            preventDefault: function () {
                var e = this.originalEvent;
                this.isDefaultPrevented = we;
                if (e && !this.isSimulated) {
                    e.preventDefault()
                }
            },
            stopPropagation: function () {
                var e = this.originalEvent;
                this.isPropagationStopped = we;
                if (e && !this.isSimulated) {
                    e.stopPropagation()
                }
            },
            stopImmediatePropagation: function () {
                var e = this.originalEvent;
                this.isImmediatePropagationStopped = we;
                if (e && !this.isSimulated) {
                    e.stopImmediatePropagation()
                }
                this.stopPropagation()
            }
        };
        y.each({
            altKey: true,
            bubbles: true,
            cancelable: true,
            changedTouches: true,
            ctrlKey: true,
            detail: true,
            eventPhase: true,
            metaKey: true,
            pageX: true,
            pageY: true,
            shiftKey: true,
            view: true,
            char: true,
            charCode: true,
            key: true,
            keyCode: true,
            button: true,
            buttons: true,
            clientX: true,
            clientY: true,
            offsetX: true,
            offsetY: true,
            pointerId: true,
            pointerType: true,
            screenX: true,
            screenY: true,
            targetTouches: true,
            toElement: true,
            touches: true,
            which: function (e) {
                var t = e.button;
                if (e.which == null && ye.test(e.type)) {
                    return e.charCode != null ? e.charCode : e.keyCode
                }
                if (!e.which && t !== undefined && ve.test(e.type)) {
                    if (t & 1) {
                        return 1
                    }
                    if (t & 2) {
                        return 3
                    }
                    if (t & 4) {
                        return 2
                    }
                    return 0
                }
                return e.which
            }
        }, y.event.addProp);
        y.each({
            mouseenter: "mouseover",
            mouseleave: "mouseout",
            pointerenter: "pointerover",
            pointerleave: "pointerout"
        }, (function (e, t) {
            y.event.special[e] = {
                delegateType: t, bindType: t, handle: function (e) {
                    var n, r = this, i = e.relatedTarget, a = e.handleObj;
                    if (!i || i !== r && !y.contains(r, i)) {
                        e.type = a.origType;
                        n = a.handler.apply(this, arguments);
                        e.type = t
                    }
                    return n
                }
            }
        }));
        y.fn.extend({
            on: function (e, t, n, r) {
                return ke(this, e, t, n, r)
            }, one: function (e, t, n, r) {
                return ke(this, e, t, n, r, 1)
            }, off: function (e, t, n) {
                var r, i;
                if (e && e.preventDefault && e.handleObj) {
                    r = e.handleObj;
                    y(e.delegateTarget).off(r.namespace ? r.origType + "." + r.namespace : r.origType, r.selector, r.handler);
                    return this
                }
                if (typeof e === "object") {
                    for (i in e) {
                        this.off(i, t, e[i])
                    }
                    return this
                }
                if (t === false || typeof t === "function") {
                    n = t;
                    t = undefined
                }
                if (n === false) {
                    n = xe
                }
                return this.each((function () {
                    y.event.remove(this, e, n, t)
                }))
            }
        });
        var Se = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([a-z][^\/\0>\x20\t\r\n\f]*)[^>]*)\/>/gi,
            Ce = /<script|<style|<link/i, Ae = /checked\s*(?:[^=]|=\s*.checked.)/i, _e = /^true\/(.*)/,
            Le = /^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g;

        function Ee(e, t) {
            if (y.nodeName(e, "table") && y.nodeName(t.nodeType !== 11 ? t : t.firstChild, "tr")) {
                return e.getElementsByTagName("tbody")[0] || e
            }
            return e
        }

        function Ne(e) {
            e.type = (e.getAttribute("type") !== null) + "/" + e.type;
            return e
        }

        function De(e) {
            var t = _e.exec(e.type);
            if (t) {
                e.type = t[1]
            } else {
                e.removeAttribute("type")
            }
            return e
        }

        function Pe(e, t) {
            var n, r, i, a, o, s, u, l;
            if (t.nodeType !== 1) {
                return
            }
            if (G.hasData(e)) {
                a = G.access(e);
                o = G.set(t, a);
                l = a.events;
                if (l) {
                    delete o.handle;
                    o.events = {};
                    for (i in l) {
                        for (n = 0, r = l[i].length; n < r; n++) {
                            y.event.add(t, i, l[i][n])
                        }
                    }
                }
            }
            if (z.hasData(e)) {
                s = z.access(e);
                u = y.extend({}, s);
                z.set(t, u)
            }
        }

        function Ie(e, t) {
            var n = t.nodeName.toLowerCase();
            if (n === "input" && ue.test(e.type)) {
                t.checked = e.checked
            } else if (n === "input" || n === "textarea") {
                t.defaultValue = e.defaultValue
            }
        }

        function Re(e, t, n, r) {
            t = o.apply([], t);
            var i, a, s, u, l, c, f = 0, p = e.length, d = p - 1, g = t[0], v = y.isFunction(g);
            if (v || p > 1 && typeof g === "string" && !h.checkClone && Ae.test(g)) {
                return e.each((function (i) {
                    var a = e.eq(i);
                    if (v) {
                        t[0] = g.call(this, i, a.html())
                    }
                    Re(a, t, n, r)
                }))
            }
            if (p) {
                i = me(t, e[0].ownerDocument, false, e, r);
                a = i.firstChild;
                if (i.childNodes.length === 1) {
                    i = a
                }
                if (a || r) {
                    s = y.map(pe(i, "script"), Ne);
                    u = s.length;
                    for (; f < p; f++) {
                        l = i;
                        if (f !== d) {
                            l = y.clone(l, true, true);
                            if (u) {
                                y.merge(s, pe(l, "script"))
                            }
                        }
                        n.call(e[f], l, f)
                    }
                    if (u) {
                        c = s[s.length - 1].ownerDocument;
                        y.map(s, De);
                        for (f = 0; f < u; f++) {
                            l = s[f];
                            if (ce.test(l.type || "") && !G.access(l, "globalEval") && y.contains(c, l)) {
                                if (l.src) {
                                    if (y._evalUrl) {
                                        y._evalUrl(l.src)
                                    }
                                } else {
                                    m(l.textContent.replace(Le, ""), c)
                                }
                            }
                        }
                    }
                }
            }
            return e
        }

        function je(e, t, n) {
            var r, i = t ? y.filter(t, e) : e, a = 0;
            for (; (r = i[a]) != null; a++) {
                if (!n && r.nodeType === 1) {
                    y.cleanData(pe(r))
                }
                if (r.parentNode) {
                    if (n && y.contains(r.ownerDocument, r)) {
                        de(pe(r, "script"))
                    }
                    r.parentNode.removeChild(r)
                }
            }
            return e
        }

        y.extend({
            htmlPrefilter: function (e) {
                return e.replace(Se, "<$1></$2>")
            }, clone: function (e, t, n) {
                var r, i, a, o, s = e.cloneNode(true), u = y.contains(e.ownerDocument, e);
                if (!h.noCloneChecked && (e.nodeType === 1 || e.nodeType === 11) && !y.isXMLDoc(e)) {
                    o = pe(s);
                    a = pe(e);
                    for (r = 0, i = a.length; r < i; r++) {
                        Ie(a[r], o[r])
                    }
                }
                if (t) {
                    if (n) {
                        a = a || pe(e);
                        o = o || pe(s);
                        for (r = 0, i = a.length; r < i; r++) {
                            Pe(a[r], o[r])
                        }
                    } else {
                        Pe(e, s)
                    }
                }
                o = pe(s, "script");
                if (o.length > 0) {
                    de(o, !u && pe(e, "script"))
                }
                return s
            }, cleanData: function (e) {
                var t, n, r, i = y.event.special, a = 0;
                for (; (n = e[a]) !== undefined; a++) {
                    if ($(n)) {
                        if (t = n[G.expando]) {
                            if (t.events) {
                                for (r in t.events) {
                                    if (i[r]) {
                                        y.event.remove(n, r)
                                    } else {
                                        y.removeEvent(n, r, t.handle)
                                    }
                                }
                            }
                            n[G.expando] = undefined
                        }
                        if (n[z.expando]) {
                            n[z.expando] = undefined
                        }
                    }
                }
            }
        });
        y.fn.extend({
            detach: function (e) {
                return je(this, e, true)
            }, remove: function (e) {
                return je(this, e)
            }, text: function (e) {
                return K(this, (function (e) {
                    return e === undefined ? y.text(this) : this.empty().each((function () {
                        if (this.nodeType === 1 || this.nodeType === 11 || this.nodeType === 9) {
                            this.textContent = e
                        }
                    }))
                }), null, e, arguments.length)
            }, append: function () {
                return Re(this, arguments, (function (e) {
                    if (this.nodeType === 1 || this.nodeType === 11 || this.nodeType === 9) {
                        var t = Ee(this, e);
                        t.appendChild(e)
                    }
                }))
            }, prepend: function () {
                return Re(this, arguments, (function (e) {
                    if (this.nodeType === 1 || this.nodeType === 11 || this.nodeType === 9) {
                        var t = Ee(this, e);
                        t.insertBefore(e, t.firstChild)
                    }
                }))
            }, before: function () {
                return Re(this, arguments, (function (e) {
                    if (this.parentNode) {
                        this.parentNode.insertBefore(e, this)
                    }
                }))
            }, after: function () {
                return Re(this, arguments, (function (e) {
                    if (this.parentNode) {
                        this.parentNode.insertBefore(e, this.nextSibling)
                    }
                }))
            }, empty: function () {
                var e, t = 0;
                for (; (e = this[t]) != null; t++) {
                    if (e.nodeType === 1) {
                        y.cleanData(pe(e, false));
                        e.textContent = ""
                    }
                }
                return this
            }, clone: function (e, t) {
                e = e == null ? false : e;
                t = t == null ? e : t;
                return this.map((function () {
                    return y.clone(this, e, t)
                }))
            }, html: function (e) {
                return K(this, (function (e) {
                    var t = this[0] || {}, n = 0, r = this.length;
                    if (e === undefined && t.nodeType === 1) {
                        return t.innerHTML
                    }
                    if (typeof e === "string" && !Ce.test(e) && !fe[(le.exec(e) || ["", ""])[1].toLowerCase()]) {
                        e = y.htmlPrefilter(e);
                        try {
                            for (; n < r; n++) {
                                t = this[n] || {};
                                if (t.nodeType === 1) {
                                    y.cleanData(pe(t, false));
                                    t.innerHTML = e
                                }
                            }
                            t = 0
                        } catch (e) {
                        }
                    }
                    if (t) {
                        this.empty().append(e)
                    }
                }), null, e, arguments.length)
            }, replaceWith: function () {
                var e = [];
                return Re(this, arguments, (function (t) {
                    var n = this.parentNode;
                    if (y.inArray(this, e) < 0) {
                        y.cleanData(pe(this));
                        if (n) {
                            n.replaceChild(t, this)
                        }
                    }
                }), e)
            }
        });
        y.each({
            appendTo: "append",
            prependTo: "prepend",
            insertBefore: "before",
            insertAfter: "after",
            replaceAll: "replaceWith"
        }, (function (e, t) {
            y.fn[e] = function (e) {
                var n, r = [], i = y(e), a = i.length - 1, o = 0;
                for (; o <= a; o++) {
                    n = o === a ? this : this.clone(true);
                    y(i[o])[t](n);
                    s.apply(r, n.get())
                }
                return this.pushStack(r)
            }
        }));
        var Me = /^margin/;
        var He = new RegExp("^(" + Z + ")(?!px)[a-z%]+$", "i");
        var qe = function (t) {
            var n = t.ownerDocument.defaultView;
            if (!n || !n.opener) {
                n = e
            }
            return n.getComputedStyle(t)
        };
        (function () {
            function t() {
                if (!u) {
                    return
                }
                u.style.cssText = "box-sizing:border-box;" + "position:relative;display:block;" + "margin:auto;border:1px;padding:1px;" + "top:1%;width:50%";
                u.innerHTML = "";
                ge.appendChild(s);
                var t = e.getComputedStyle(u);
                n = t.top !== "1%";
                o = t.marginLeft === "2px";
                i = t.width === "4px";
                u.style.marginRight = "50%";
                a = t.marginRight === "4px";
                ge.removeChild(s);
                u = null
            }

            var n, i, a, o, s = r.createElement("div"), u = r.createElement("div");
            if (!u.style) {
                return
            }
            u.style.backgroundClip = "content-box";
            u.cloneNode(true).style.backgroundClip = "";
            h.clearCloneStyle = u.style.backgroundClip === "content-box";
            s.style.cssText = "border:0;width:8px;height:0;top:0;left:-9999px;" + "padding:0;margin-top:1px;position:absolute";
            s.appendChild(u);
            y.extend(h, {
                pixelPosition: function () {
                    t();
                    return n
                }, boxSizingReliable: function () {
                    t();
                    return i
                }, pixelMarginRight: function () {
                    t();
                    return a
                }, reliableMarginLeft: function () {
                    t();
                    return o
                }
            })
        })();

        function Oe(e, t, n) {
            var r, i, a, o, s = e.style;
            n = n || qe(e);
            if (n) {
                o = n.getPropertyValue(t) || n[t];
                if (o === "" && !y.contains(e.ownerDocument, e)) {
                    o = y.style(e, t)
                }
                if (!h.pixelMarginRight() && He.test(o) && Me.test(t)) {
                    r = s.width;
                    i = s.minWidth;
                    a = s.maxWidth;
                    s.minWidth = s.maxWidth = s.width = o;
                    o = n.width;
                    s.width = r;
                    s.minWidth = i;
                    s.maxWidth = a
                }
            }
            return o !== undefined ? o + "" : o
        }

        function Fe(e, t) {
            return {
                get: function () {
                    if (e()) {
                        delete this.get;
                        return
                    }
                    return (this.get = t).apply(this, arguments)
                }
            }
        }

        var Be = /^(none|table(?!-c[ea]).+)/, Ue = {position: "absolute", visibility: "hidden", display: "block"},
            We = {letterSpacing: "0", fontWeight: "400"}, Ke = ["Webkit", "Moz", "ms"],
            $e = r.createElement("div").style;

        function Ve(e) {
            if (e in $e) {
                return e
            }
            var t = e[0].toUpperCase() + e.slice(1), n = Ke.length;
            while (n--) {
                e = Ke[n] + t;
                if (e in $e) {
                    return e
                }
            }
        }

        function Ge(e, t, n) {
            var r = ee.exec(t);
            return r ? Math.max(0, r[2] - (n || 0)) + (r[3] || "px") : t
        }

        function ze(e, t, n, r, i) {
            var a, o = 0;
            if (n === (r ? "border" : "content")) {
                a = 4
            } else {
                a = t === "width" ? 1 : 0
            }
            for (; a < 4; a += 2) {
                if (n === "margin") {
                    o += y.css(e, n + te[a], true, i)
                }
                if (r) {
                    if (n === "content") {
                        o -= y.css(e, "padding" + te[a], true, i)
                    }
                    if (n !== "margin") {
                        o -= y.css(e, "border" + te[a] + "Width", true, i)
                    }
                } else {
                    o += y.css(e, "padding" + te[a], true, i);
                    if (n !== "padding") {
                        o += y.css(e, "border" + te[a] + "Width", true, i)
                    }
                }
            }
            return o
        }

        function Xe(e, t, n) {
            var r, i = true, a = qe(e), o = y.css(e, "boxSizing", false, a) === "border-box";
            if (e.getClientRects().length) {
                r = e.getBoundingClientRect()[t]
            }
            if (r <= 0 || r == null) {
                r = Oe(e, t, a);
                if (r < 0 || r == null) {
                    r = e.style[t]
                }
                if (He.test(r)) {
                    return r
                }
                i = o && (h.boxSizingReliable() || r === e.style[t]);
                r = parseFloat(r) || 0
            }
            return r + ze(e, t, n || (o ? "border" : "content"), i, a) + "px"
        }

        y.extend({
            cssHooks: {
                opacity: {
                    get: function (e, t) {
                        if (t) {
                            var n = Oe(e, "opacity");
                            return n === "" ? "1" : n
                        }
                    }
                }
            },
            cssNumber: {
                animationIterationCount: true,
                columnCount: true,
                fillOpacity: true,
                flexGrow: true,
                flexShrink: true,
                fontWeight: true,
                lineHeight: true,
                opacity: true,
                order: true,
                orphans: true,
                widows: true,
                zIndex: true,
                zoom: true
            },
            cssProps: {float: "cssFloat"},
            style: function (e, t, n, r) {
                if (!e || e.nodeType === 3 || e.nodeType === 8 || !e.style) {
                    return
                }
                var i, a, o, s = y.camelCase(t), u = e.style;
                t = y.cssProps[s] || (y.cssProps[s] = Ve(s) || s);
                o = y.cssHooks[t] || y.cssHooks[s];
                if (n !== undefined) {
                    a = typeof n;
                    if (a === "string" && (i = ee.exec(n)) && i[1]) {
                        n = ie(e, t, i);
                        a = "number"
                    }
                    if (n == null || n !== n) {
                        return
                    }
                    if (a === "number") {
                        n += i && i[3] || (y.cssNumber[s] ? "" : "px")
                    }
                    if (!h.clearCloneStyle && n === "" && t.indexOf("background") === 0) {
                        u[t] = "inherit"
                    }
                    if (!o || !("set" in o) || (n = o.set(e, n, r)) !== undefined) {
                        u[t] = n
                    }
                } else {
                    if (o && "get" in o && (i = o.get(e, false, r)) !== undefined) {
                        return i
                    }
                    return u[t]
                }
            },
            css: function (e, t, n, r) {
                var i, a, o, s = y.camelCase(t);
                t = y.cssProps[s] || (y.cssProps[s] = Ve(s) || s);
                o = y.cssHooks[t] || y.cssHooks[s];
                if (o && "get" in o) {
                    i = o.get(e, true, n)
                }
                if (i === undefined) {
                    i = Oe(e, t, r)
                }
                if (i === "normal" && t in We) {
                    i = We[t]
                }
                if (n === "" || n) {
                    a = parseFloat(i);
                    return n === true || isFinite(a) ? a || 0 : i
                }
                return i
            }
        });
        y.each(["height", "width"], (function (e, t) {
            y.cssHooks[t] = {
                get: function (e, n, r) {
                    if (n) {
                        return Be.test(y.css(e, "display")) && (!e.getClientRects().length || !e.getBoundingClientRect().width) ? re(e, Ue, (function () {
                            return Xe(e, t, r)
                        })) : Xe(e, t, r)
                    }
                }, set: function (e, n, r) {
                    var i, a = r && qe(e), o = r && ze(e, t, r, y.css(e, "boxSizing", false, a) === "border-box", a);
                    if (o && (i = ee.exec(n)) && (i[3] || "px") !== "px") {
                        e.style[t] = n;
                        n = y.css(e, t)
                    }
                    return Ge(e, n, o)
                }
            }
        }));
        y.cssHooks.marginLeft = Fe(h.reliableMarginLeft, (function (e, t) {
            if (t) {
                return (parseFloat(Oe(e, "marginLeft")) || e.getBoundingClientRect().left - re(e, {marginLeft: 0}, (function () {
                    return e.getBoundingClientRect().left
                }))) + "px"
            }
        }));
        y.each({margin: "", padding: "", border: "Width"}, (function (e, t) {
            y.cssHooks[e + t] = {
                expand: function (n) {
                    var r = 0, i = {}, a = typeof n === "string" ? n.split(" ") : [n];
                    for (; r < 4; r++) {
                        i[e + te[r] + t] = a[r] || a[r - 2] || a[0]
                    }
                    return i
                }
            };
            if (!Me.test(e)) {
                y.cssHooks[e + t].set = Ge
            }
        }));
        y.fn.extend({
            css: function (e, t) {
                return K(this, (function (e, t, n) {
                    var r, i, a = {}, o = 0;
                    if (y.isArray(t)) {
                        r = qe(e);
                        i = t.length;
                        for (; o < i; o++) {
                            a[t[o]] = y.css(e, t[o], false, r)
                        }
                        return a
                    }
                    return n !== undefined ? y.style(e, t, n) : y.css(e, t)
                }), e, t, arguments.length > 1)
            }
        });

        function Je(e, t, n, r, i) {
            return new Je.prototype.init(e, t, n, r, i)
        }

        y.Tween = Je;
        Je.prototype = {
            constructor: Je, init: function (e, t, n, r, i, a) {
                this.elem = e;
                this.prop = n;
                this.easing = i || y.easing._default;
                this.options = t;
                this.start = this.now = this.cur();
                this.end = r;
                this.unit = a || (y.cssNumber[n] ? "" : "px")
            }, cur: function () {
                var e = Je.propHooks[this.prop];
                return e && e.get ? e.get(this) : Je.propHooks._default.get(this)
            }, run: function (e) {
                var t, n = Je.propHooks[this.prop];
                if (this.options.duration) {
                    this.pos = t = y.easing[this.easing](e, this.options.duration * e, 0, 1, this.options.duration)
                } else {
                    this.pos = t = e
                }
                this.now = (this.end - this.start) * t + this.start;
                if (this.options.step) {
                    this.options.step.call(this.elem, this.now, this)
                }
                if (n && n.set) {
                    n.set(this)
                } else {
                    Je.propHooks._default.set(this)
                }
                return this
            }
        };
        Je.prototype.init.prototype = Je.prototype;
        Je.propHooks = {
            _default: {
                get: function (e) {
                    var t;
                    if (e.elem.nodeType !== 1 || e.elem[e.prop] != null && e.elem.style[e.prop] == null) {
                        return e.elem[e.prop]
                    }
                    t = y.css(e.elem, e.prop, "");
                    return !t || t === "auto" ? 0 : t
                }, set: function (e) {
                    if (y.fx.step[e.prop]) {
                        y.fx.step[e.prop](e)
                    } else if (e.elem.nodeType === 1 && (e.elem.style[y.cssProps[e.prop]] != null || y.cssHooks[e.prop])) {
                        y.style(e.elem, e.prop, e.now + e.unit)
                    } else {
                        e.elem[e.prop] = e.now
                    }
                }
            }
        };
        Je.propHooks.scrollTop = Je.propHooks.scrollLeft = {
            set: function (e) {
                if (e.elem.nodeType && e.elem.parentNode) {
                    e.elem[e.prop] = e.now
                }
            }
        };
        y.easing = {
            linear: function (e) {
                return e
            }, swing: function (e) {
                return .5 - Math.cos(e * Math.PI) / 2
            }, _default: "swing"
        };
        y.fx = Je.prototype.init;
        y.fx.step = {};
        var Qe, Ye, Ze = /^(?:toggle|show|hide)$/, et = /queueHooks$/;

        function tt() {
            if (Ye) {
                e.requestAnimationFrame(tt);
                y.fx.tick()
            }
        }

        function nt() {
            e.setTimeout((function () {
                Qe = undefined
            }));
            return Qe = y.now()
        }

        function rt(e, t) {
            var n, r = 0, i = {height: e};
            t = t ? 1 : 0;
            for (; r < 4; r += 2 - t) {
                n = te[r];
                i["margin" + n] = i["padding" + n] = e
            }
            if (t) {
                i.opacity = i.width = e
            }
            return i
        }

        function it(e, t, n) {
            var r, i = (st.tweeners[t] || []).concat(st.tweeners["*"]), a = 0, o = i.length;
            for (; a < o; a++) {
                if (r = i[a].call(n, t, e)) {
                    return r
                }
            }
        }

        function at(e, t, n) {
            var r, i, a, o, s, u, l, c, f = "width" in t || "height" in t, p = this, d = {}, h = e.style,
                m = e.nodeType && ne(e), g = G.get(e, "fxshow");
            if (!n.queue) {
                o = y._queueHooks(e, "fx");
                if (o.unqueued == null) {
                    o.unqueued = 0;
                    s = o.empty.fire;
                    o.empty.fire = function () {
                        if (!o.unqueued) {
                            s()
                        }
                    }
                }
                o.unqueued++;
                p.always((function () {
                    p.always((function () {
                        o.unqueued--;
                        if (!y.queue(e, "fx").length) {
                            o.empty.fire()
                        }
                    }))
                }))
            }
            for (r in t) {
                i = t[r];
                if (Ze.test(i)) {
                    delete t[r];
                    a = a || i === "toggle";
                    if (i === (m ? "hide" : "show")) {
                        if (i === "show" && g && g[r] !== undefined) {
                            m = true
                        } else {
                            continue
                        }
                    }
                    d[r] = g && g[r] || y.style(e, r)
                }
            }
            u = !y.isEmptyObject(t);
            if (!u && y.isEmptyObject(d)) {
                return
            }
            if (f && e.nodeType === 1) {
                n.overflow = [h.overflow, h.overflowX, h.overflowY];
                l = g && g.display;
                if (l == null) {
                    l = G.get(e, "display")
                }
                c = y.css(e, "display");
                if (c === "none") {
                    if (l) {
                        c = l
                    } else {
                        se([e], true);
                        l = e.style.display || l;
                        c = y.css(e, "display");
                        se([e])
                    }
                }
                if (c === "inline" || c === "inline-block" && l != null) {
                    if (y.css(e, "float") === "none") {
                        if (!u) {
                            p.done((function () {
                                h.display = l
                            }));
                            if (l == null) {
                                c = h.display;
                                l = c === "none" ? "" : c
                            }
                        }
                        h.display = "inline-block"
                    }
                }
            }
            if (n.overflow) {
                h.overflow = "hidden";
                p.always((function () {
                    h.overflow = n.overflow[0];
                    h.overflowX = n.overflow[1];
                    h.overflowY = n.overflow[2]
                }))
            }
            u = false;
            for (r in d) {
                if (!u) {
                    if (g) {
                        if ("hidden" in g) {
                            m = g.hidden
                        }
                    } else {
                        g = G.access(e, "fxshow", {display: l})
                    }
                    if (a) {
                        g.hidden = !m
                    }
                    if (m) {
                        se([e], true)
                    }
                    p.done((function () {
                        if (!m) {
                            se([e])
                        }
                        G.remove(e, "fxshow");
                        for (r in d) {
                            y.style(e, r, d[r])
                        }
                    }))
                }
                u = it(m ? g[r] : 0, r, p);
                if (!(r in g)) {
                    g[r] = u.start;
                    if (m) {
                        u.end = u.start;
                        u.start = 0
                    }
                }
            }
        }

        function ot(e, t) {
            var n, r, i, a, o;
            for (n in e) {
                r = y.camelCase(n);
                i = t[r];
                a = e[n];
                if (y.isArray(a)) {
                    i = a[1];
                    a = e[n] = a[0]
                }
                if (n !== r) {
                    e[r] = a;
                    delete e[n]
                }
                o = y.cssHooks[r];
                if (o && "expand" in o) {
                    a = o.expand(a);
                    delete e[r];
                    for (n in a) {
                        if (!(n in e)) {
                            e[n] = a[n];
                            t[n] = i
                        }
                    }
                } else {
                    t[r] = i
                }
            }
        }

        function st(e, t, n) {
            var r, i, a = 0, o = st.prefilters.length, s = y.Deferred().always((function () {
                delete u.elem
            })), u = function () {
                if (i) {
                    return false
                }
                var t = Qe || nt(), n = Math.max(0, l.startTime + l.duration - t), r = n / l.duration || 0, a = 1 - r,
                    o = 0, u = l.tweens.length;
                for (; o < u; o++) {
                    l.tweens[o].run(a)
                }
                s.notifyWith(e, [l, a, n]);
                if (a < 1 && u) {
                    return n
                } else {
                    s.resolveWith(e, [l]);
                    return false
                }
            }, l = s.promise({
                elem: e,
                props: y.extend({}, t),
                opts: y.extend(true, {specialEasing: {}, easing: y.easing._default}, n),
                originalProperties: t,
                originalOptions: n,
                startTime: Qe || nt(),
                duration: n.duration,
                tweens: [],
                createTween: function (t, n) {
                    var r = y.Tween(e, l.opts, t, n, l.opts.specialEasing[t] || l.opts.easing);
                    l.tweens.push(r);
                    return r
                },
                stop: function (t) {
                    var n = 0, r = t ? l.tweens.length : 0;
                    if (i) {
                        return this
                    }
                    i = true;
                    for (; n < r; n++) {
                        l.tweens[n].run(1)
                    }
                    if (t) {
                        s.notifyWith(e, [l, 1, 0]);
                        s.resolveWith(e, [l, t])
                    } else {
                        s.rejectWith(e, [l, t])
                    }
                    return this
                }
            }), c = l.props;
            ot(c, l.opts.specialEasing);
            for (; a < o; a++) {
                r = st.prefilters[a].call(l, e, c, l.opts);
                if (r) {
                    if (y.isFunction(r.stop)) {
                        y._queueHooks(l.elem, l.opts.queue).stop = y.proxy(r.stop, r)
                    }
                    return r
                }
            }
            y.map(c, it, l);
            if (y.isFunction(l.opts.start)) {
                l.opts.start.call(e, l)
            }
            y.fx.timer(y.extend(u, {elem: e, anim: l, queue: l.opts.queue}));
            return l.progress(l.opts.progress).done(l.opts.done, l.opts.complete).fail(l.opts.fail).always(l.opts.always)
        }

        y.Animation = y.extend(st, {
            tweeners: {
                "*": [function (e, t) {
                    var n = this.createTween(e, t);
                    ie(n.elem, e, ee.exec(t), n);
                    return n
                }]
            }, tweener: function (e, t) {
                if (y.isFunction(e)) {
                    t = e;
                    e = ["*"]
                } else {
                    e = e.match(M)
                }
                var n, r = 0, i = e.length;
                for (; r < i; r++) {
                    n = e[r];
                    st.tweeners[n] = st.tweeners[n] || [];
                    st.tweeners[n].unshift(t)
                }
            }, prefilters: [at], prefilter: function (e, t) {
                if (t) {
                    st.prefilters.unshift(e)
                } else {
                    st.prefilters.push(e)
                }
            }
        });
        y.speed = function (e, t, n) {
            var i = e && typeof e === "object" ? y.extend({}, e) : {
                complete: n || !n && t || y.isFunction(e) && e,
                duration: e,
                easing: n && t || t && !y.isFunction(t) && t
            };
            if (y.fx.off || r.hidden) {
                i.duration = 0
            } else {
                if (typeof i.duration !== "number") {
                    if (i.duration in y.fx.speeds) {
                        i.duration = y.fx.speeds[i.duration]
                    } else {
                        i.duration = y.fx.speeds._default
                    }
                }
            }
            if (i.queue == null || i.queue === true) {
                i.queue = "fx"
            }
            i.old = i.complete;
            i.complete = function () {
                if (y.isFunction(i.old)) {
                    i.old.call(this)
                }
                if (i.queue) {
                    y.dequeue(this, i.queue)
                }
            };
            return i
        };
        y.fn.extend({
            fadeTo: function (e, t, n, r) {
                return this.filter(ne).css("opacity", 0).show().end().animate({opacity: t}, e, n, r)
            }, animate: function (e, t, n, r) {
                var i = y.isEmptyObject(e), a = y.speed(t, n, r), o = function () {
                    var t = st(this, y.extend({}, e), a);
                    if (i || G.get(this, "finish")) {
                        t.stop(true)
                    }
                };
                o.finish = o;
                return i || a.queue === false ? this.each(o) : this.queue(a.queue, o)
            }, stop: function (e, t, n) {
                var r = function (e) {
                    var t = e.stop;
                    delete e.stop;
                    t(n)
                };
                if (typeof e !== "string") {
                    n = t;
                    t = e;
                    e = undefined
                }
                if (t && e !== false) {
                    this.queue(e || "fx", [])
                }
                return this.each((function () {
                    var t = true, i = e != null && e + "queueHooks", a = y.timers, o = G.get(this);
                    if (i) {
                        if (o[i] && o[i].stop) {
                            r(o[i])
                        }
                    } else {
                        for (i in o) {
                            if (o[i] && o[i].stop && et.test(i)) {
                                r(o[i])
                            }
                        }
                    }
                    for (i = a.length; i--;) {
                        if (a[i].elem === this && (e == null || a[i].queue === e)) {
                            a[i].anim.stop(n);
                            t = false;
                            a.splice(i, 1)
                        }
                    }
                    if (t || !n) {
                        y.dequeue(this, e)
                    }
                }))
            }, finish: function (e) {
                if (e !== false) {
                    e = e || "fx"
                }
                return this.each((function () {
                    var t, n = G.get(this), r = n[e + "queue"], i = n[e + "queueHooks"], a = y.timers,
                        o = r ? r.length : 0;
                    n.finish = true;
                    y.queue(this, e, []);
                    if (i && i.stop) {
                        i.stop.call(this, true)
                    }
                    for (t = a.length; t--;) {
                        if (a[t].elem === this && a[t].queue === e) {
                            a[t].anim.stop(true);
                            a.splice(t, 1)
                        }
                    }
                    for (t = 0; t < o; t++) {
                        if (r[t] && r[t].finish) {
                            r[t].finish.call(this)
                        }
                    }
                    delete n.finish
                }))
            }
        });
        y.each(["toggle", "show", "hide"], (function (e, t) {
            var n = y.fn[t];
            y.fn[t] = function (e, r, i) {
                return e == null || typeof e === "boolean" ? n.apply(this, arguments) : this.animate(rt(t, true), e, r, i)
            }
        }));
        y.each({
            slideDown: rt("show"),
            slideUp: rt("hide"),
            slideToggle: rt("toggle"),
            fadeIn: {opacity: "show"},
            fadeOut: {opacity: "hide"},
            fadeToggle: {opacity: "toggle"}
        }, (function (e, t) {
            y.fn[e] = function (e, n, r) {
                return this.animate(t, e, n, r)
            }
        }));
        y.timers = [];
        y.fx.tick = function () {
            var e, t = 0, n = y.timers;
            Qe = y.now();
            for (; t < n.length; t++) {
                e = n[t];
                if (!e() && n[t] === e) {
                    n.splice(t--, 1)
                }
            }
            if (!n.length) {
                y.fx.stop()
            }
            Qe = undefined
        };
        y.fx.timer = function (e) {
            y.timers.push(e);
            if (e()) {
                y.fx.start()
            } else {
                y.timers.pop()
            }
        };
        y.fx.interval = 13;
        y.fx.start = function () {
            if (!Ye) {
                Ye = e.requestAnimationFrame ? e.requestAnimationFrame(tt) : e.setInterval(y.fx.tick, y.fx.interval)
            }
        };
        y.fx.stop = function () {
            if (e.cancelAnimationFrame) {
                e.cancelAnimationFrame(Ye)
            } else {
                e.clearInterval(Ye)
            }
            Ye = null
        };
        y.fx.speeds = {slow: 600, fast: 200, _default: 400};
        y.fn.delay = function (t, n) {
            t = y.fx ? y.fx.speeds[t] || t : t;
            n = n || "fx";
            return this.queue(n, (function (n, r) {
                var i = e.setTimeout(n, t);
                r.stop = function () {
                    e.clearTimeout(i)
                }
            }))
        };
        (function () {
            var e = r.createElement("input"), t = r.createElement("select"),
                n = t.appendChild(r.createElement("option"));
            e.type = "checkbox";
            h.checkOn = e.value !== "";
            h.optSelected = n.selected;
            e = r.createElement("input");
            e.value = "t";
            e.type = "radio";
            h.radioValue = e.value === "t"
        })();
        var ut, lt = y.expr.attrHandle;
        y.fn.extend({
            attr: function (e, t) {
                return K(this, y.attr, e, t, arguments.length > 1)
            }, removeAttr: function (e) {
                return this.each((function () {
                    y.removeAttr(this, e)
                }))
            }
        });
        y.extend({
            attr: function (e, t, n) {
                var r, i, a = e.nodeType;
                if (a === 3 || a === 8 || a === 2) {
                    return
                }
                if (typeof e.getAttribute === "undefined") {
                    return y.prop(e, t, n)
                }
                if (a !== 1 || !y.isXMLDoc(e)) {
                    i = y.attrHooks[t.toLowerCase()] || (y.expr.match.bool.test(t) ? ut : undefined)
                }
                if (n !== undefined) {
                    if (n === null) {
                        y.removeAttr(e, t);
                        return
                    }
                    if (i && "set" in i && (r = i.set(e, n, t)) !== undefined) {
                        return r
                    }
                    e.setAttribute(t, n + "");
                    return n
                }
                if (i && "get" in i && (r = i.get(e, t)) !== null) {
                    return r
                }
                r = y.find.attr(e, t);
                return r == null ? undefined : r
            }, attrHooks: {
                type: {
                    set: function (e, t) {
                        if (!h.radioValue && t === "radio" && y.nodeName(e, "input")) {
                            var n = e.value;
                            e.setAttribute("type", t);
                            if (n) {
                                e.value = n
                            }
                            return t
                        }
                    }
                }
            }, removeAttr: function (e, t) {
                var n, r = 0, i = t && t.match(M);
                if (i && e.nodeType === 1) {
                    while (n = i[r++]) {
                        e.removeAttribute(n)
                    }
                }
            }
        });
        ut = {
            set: function (e, t, n) {
                if (t === false) {
                    y.removeAttr(e, n)
                } else {
                    e.setAttribute(n, n)
                }
                return n
            }
        };
        y.each(y.expr.match.bool.source.match(/\w+/g), (function (e, t) {
            var n = lt[t] || y.find.attr;
            lt[t] = function (e, t, r) {
                var i, a, o = t.toLowerCase();
                if (!r) {
                    a = lt[o];
                    lt[o] = i;
                    i = n(e, t, r) != null ? o : null;
                    lt[o] = a
                }
                return i
            }
        }));
        var ct = /^(?:input|select|textarea|button)$/i, ft = /^(?:a|area)$/i;
        y.fn.extend({
            prop: function (e, t) {
                return K(this, y.prop, e, t, arguments.length > 1)
            }, removeProp: function (e) {
                return this.each((function () {
                    delete this[y.propFix[e] || e]
                }))
            }
        });
        y.extend({
            prop: function (e, t, n) {
                var r, i, a = e.nodeType;
                if (a === 3 || a === 8 || a === 2) {
                    return
                }
                if (a !== 1 || !y.isXMLDoc(e)) {
                    t = y.propFix[t] || t;
                    i = y.propHooks[t]
                }
                if (n !== undefined) {
                    if (i && "set" in i && (r = i.set(e, n, t)) !== undefined) {
                        return r
                    }
                    return e[t] = n
                }
                if (i && "get" in i && (r = i.get(e, t)) !== null) {
                    return r
                }
                return e[t]
            }, propHooks: {
                tabIndex: {
                    get: function (e) {
                        var t = y.find.attr(e, "tabindex");
                        if (t) {
                            return parseInt(t, 10)
                        }
                        if (ct.test(e.nodeName) || ft.test(e.nodeName) && e.href) {
                            return 0
                        }
                        return -1
                    }
                }
            }, propFix: {for: "htmlFor", class: "className"}
        });
        if (!h.optSelected) {
            y.propHooks.selected = {
                get: function (e) {
                    var t = e.parentNode;
                    if (t && t.parentNode) {
                        t.parentNode.selectedIndex
                    }
                    return null
                }, set: function (e) {
                    var t = e.parentNode;
                    if (t) {
                        t.selectedIndex;
                        if (t.parentNode) {
                            t.parentNode.selectedIndex
                        }
                    }
                }
            }
        }
        y.each(["tabIndex", "readOnly", "maxLength", "cellSpacing", "cellPadding", "rowSpan", "colSpan", "useMap", "frameBorder", "contentEditable"], (function () {
            y.propFix[this.toLowerCase()] = this
        }));

        function pt(e) {
            var t = e.match(M) || [];
            return t.join(" ")
        }

        function dt(e) {
            return e.getAttribute && e.getAttribute("class") || ""
        }

        y.fn.extend({
            addClass: function (e) {
                var t, n, r, i, a, o, s, u = 0;
                if (y.isFunction(e)) {
                    return this.each((function (t) {
                        y(this).addClass(e.call(this, t, dt(this)))
                    }))
                }
                if (typeof e === "string" && e) {
                    t = e.match(M) || [];
                    while (n = this[u++]) {
                        i = dt(n);
                        r = n.nodeType === 1 && " " + pt(i) + " ";
                        if (r) {
                            o = 0;
                            while (a = t[o++]) {
                                if (r.indexOf(" " + a + " ") < 0) {
                                    r += a + " "
                                }
                            }
                            s = pt(r);
                            if (i !== s) {
                                n.setAttribute("class", s)
                            }
                        }
                    }
                }
                return this
            }, removeClass: function (e) {
                var t, n, r, i, a, o, s, u = 0;
                if (y.isFunction(e)) {
                    return this.each((function (t) {
                        y(this).removeClass(e.call(this, t, dt(this)))
                    }))
                }
                if (!arguments.length) {
                    return this.attr("class", "")
                }
                if (typeof e === "string" && e) {
                    t = e.match(M) || [];
                    while (n = this[u++]) {
                        i = dt(n);
                        r = n.nodeType === 1 && " " + pt(i) + " ";
                        if (r) {
                            o = 0;
                            while (a = t[o++]) {
                                while (r.indexOf(" " + a + " ") > -1) {
                                    r = r.replace(" " + a + " ", " ")
                                }
                            }
                            s = pt(r);
                            if (i !== s) {
                                n.setAttribute("class", s)
                            }
                        }
                    }
                }
                return this
            }, toggleClass: function (e, t) {
                var n = typeof e;
                if (typeof t === "boolean" && n === "string") {
                    return t ? this.addClass(e) : this.removeClass(e)
                }
                if (y.isFunction(e)) {
                    return this.each((function (n) {
                        y(this).toggleClass(e.call(this, n, dt(this), t), t)
                    }))
                }
                return this.each((function () {
                    var t, r, i, a;
                    if (n === "string") {
                        r = 0;
                        i = y(this);
                        a = e.match(M) || [];
                        while (t = a[r++]) {
                            if (i.hasClass(t)) {
                                i.removeClass(t)
                            } else {
                                i.addClass(t)
                            }
                        }
                    } else if (e === undefined || n === "boolean") {
                        t = dt(this);
                        if (t) {
                            G.set(this, "__className__", t)
                        }
                        if (this.setAttribute) {
                            this.setAttribute("class", t || e === false ? "" : G.get(this, "__className__") || "")
                        }
                    }
                }))
            }, hasClass: function (e) {
                var t, n, r = 0;
                t = " " + e + " ";
                while (n = this[r++]) {
                    if (n.nodeType === 1 && (" " + pt(dt(n)) + " ").indexOf(t) > -1) {
                        return true
                    }
                }
                return false
            }
        });
        var ht = /\r/g;
        y.fn.extend({
            val: function (e) {
                var t, n, r, i = this[0];
                if (!arguments.length) {
                    if (i) {
                        t = y.valHooks[i.type] || y.valHooks[i.nodeName.toLowerCase()];
                        if (t && "get" in t && (n = t.get(i, "value")) !== undefined) {
                            return n
                        }
                        n = i.value;
                        if (typeof n === "string") {
                            return n.replace(ht, "")
                        }
                        return n == null ? "" : n
                    }
                    return
                }
                r = y.isFunction(e);
                return this.each((function (n) {
                    var i;
                    if (this.nodeType !== 1) {
                        return
                    }
                    if (r) {
                        i = e.call(this, n, y(this).val())
                    } else {
                        i = e
                    }
                    if (i == null) {
                        i = ""
                    } else if (typeof i === "number") {
                        i += ""
                    } else if (y.isArray(i)) {
                        i = y.map(i, (function (e) {
                            return e == null ? "" : e + ""
                        }))
                    }
                    t = y.valHooks[this.type] || y.valHooks[this.nodeName.toLowerCase()];
                    if (!t || !("set" in t) || t.set(this, i, "value") === undefined) {
                        this.value = i
                    }
                }))
            }
        });
        y.extend({
            valHooks: {
                option: {
                    get: function (e) {
                        var t = y.find.attr(e, "value");
                        return t != null ? t : pt(y.text(e))
                    }
                }, select: {
                    get: function (e) {
                        var t, n, r, i = e.options, a = e.selectedIndex, o = e.type === "select-one", s = o ? null : [],
                            u = o ? a + 1 : i.length;
                        if (a < 0) {
                            r = u
                        } else {
                            r = o ? a : 0
                        }
                        for (; r < u; r++) {
                            n = i[r];
                            if ((n.selected || r === a) && !n.disabled && (!n.parentNode.disabled || !y.nodeName(n.parentNode, "optgroup"))) {
                                t = y(n).val();
                                if (o) {
                                    return t
                                }
                                s.push(t)
                            }
                        }
                        return s
                    }, set: function (e, t) {
                        var n, r, i = e.options, a = y.makeArray(t), o = i.length;
                        while (o--) {
                            r = i[o];
                            if (r.selected = y.inArray(y.valHooks.option.get(r), a) > -1) {
                                n = true
                            }
                        }
                        if (!n) {
                            e.selectedIndex = -1
                        }
                        return a
                    }
                }
            }
        });
        y.each(["radio", "checkbox"], (function () {
            y.valHooks[this] = {
                set: function (e, t) {
                    if (y.isArray(t)) {
                        return e.checked = y.inArray(y(e).val(), t) > -1
                    }
                }
            };
            if (!h.checkOn) {
                y.valHooks[this].get = function (e) {
                    return e.getAttribute("value") === null ? "on" : e.value
                }
            }
        }));
        var mt = /^(?:focusinfocus|focusoutblur)$/;
        y.extend(y.event, {
            trigger: function (t, n, i, a) {
                var o, s, u, l, c, p, d, h = [i || r], m = f.call(t, "type") ? t.type : t,
                    g = f.call(t, "namespace") ? t.namespace.split(".") : [];
                s = u = i = i || r;
                if (i.nodeType === 3 || i.nodeType === 8) {
                    return
                }
                if (mt.test(m + y.event.triggered)) {
                    return
                }
                if (m.indexOf(".") > -1) {
                    g = m.split(".");
                    m = g.shift();
                    g.sort()
                }
                c = m.indexOf(":") < 0 && "on" + m;
                t = t[y.expando] ? t : new y.Event(m, typeof t === "object" && t);
                t.isTrigger = a ? 2 : 3;
                t.namespace = g.join(".");
                t.rnamespace = t.namespace ? new RegExp("(^|\\.)" + g.join("\\.(?:.*\\.|)") + "(\\.|$)") : null;
                t.result = undefined;
                if (!t.target) {
                    t.target = i
                }
                n = n == null ? [t] : y.makeArray(n, [t]);
                d = y.event.special[m] || {};
                if (!a && d.trigger && d.trigger.apply(i, n) === false) {
                    return
                }
                if (!a && !d.noBubble && !y.isWindow(i)) {
                    l = d.delegateType || m;
                    if (!mt.test(l + m)) {
                        s = s.parentNode
                    }
                    for (; s; s = s.parentNode) {
                        h.push(s);
                        u = s
                    }
                    if (u === (i.ownerDocument || r)) {
                        h.push(u.defaultView || u.parentWindow || e)
                    }
                }
                o = 0;
                while ((s = h[o++]) && !t.isPropagationStopped()) {
                    t.type = o > 1 ? l : d.bindType || m;
                    p = (G.get(s, "events") || {})[t.type] && G.get(s, "handle");
                    if (p) {
                        p.apply(s, n)
                    }
                    p = c && s[c];
                    if (p && p.apply && $(s)) {
                        t.result = p.apply(s, n);
                        if (t.result === false) {
                            t.preventDefault()
                        }
                    }
                }
                t.type = m;
                if (!a && !t.isDefaultPrevented()) {
                    if ((!d._default || d._default.apply(h.pop(), n) === false) && $(i)) {
                        if (c && y.isFunction(i[m]) && !y.isWindow(i)) {
                            u = i[c];
                            if (u) {
                                i[c] = null
                            }
                            y.event.triggered = m;
                            i[m]();
                            y.event.triggered = undefined;
                            if (u) {
                                i[c] = u
                            }
                        }
                    }
                }
                return t.result
            }, simulate: function (e, t, n) {
                var r = y.extend(new y.Event, n, {type: e, isSimulated: true});
                y.event.trigger(r, null, t)
            }
        });
        y.fn.extend({
            trigger: function (e, t) {
                return this.each((function () {
                    y.event.trigger(e, t, this)
                }))
            }, triggerHandler: function (e, t) {
                var n = this[0];
                if (n) {
                    return y.event.trigger(e, t, n, true)
                }
            }
        });
        y.each(("blur focus focusin focusout resize scroll click dblclick " + "mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave " + "change select submit keydown keypress keyup contextmenu").split(" "), (function (e, t) {
            y.fn[t] = function (e, n) {
                return arguments.length > 0 ? this.on(t, null, e, n) : this.trigger(t)
            }
        }));
        y.fn.extend({
            hover: function (e, t) {
                return this.mouseenter(e).mouseleave(t || e)
            }
        });
        h.focusin = "onfocusin" in e;
        if (!h.focusin) {
            y.each({focus: "focusin", blur: "focusout"}, (function (e, t) {
                var n = function (e) {
                    y.event.simulate(t, e.target, y.event.fix(e))
                };
                y.event.special[t] = {
                    setup: function () {
                        var r = this.ownerDocument || this, i = G.access(r, t);
                        if (!i) {
                            r.addEventListener(e, n, true)
                        }
                        G.access(r, t, (i || 0) + 1)
                    }, teardown: function () {
                        var r = this.ownerDocument || this, i = G.access(r, t) - 1;
                        if (!i) {
                            r.removeEventListener(e, n, true);
                            G.remove(r, t)
                        } else {
                            G.access(r, t, i)
                        }
                    }
                }
            }))
        }
        var gt = e.location;
        var yt = y.now();
        var vt = /\?/;
        y.parseXML = function (t) {
            var n;
            if (!t || typeof t !== "string") {
                return null
            }
            try {
                n = (new e.DOMParser).parseFromString(t, "text/xml")
            } catch (e) {
                n = undefined
            }
            if (!n || n.getElementsByTagName("parsererror").length) {
                y.error("Invalid XML: " + t)
            }
            return n
        };
        var bt = /\[\]$/, wt = /\r?\n/g, xt = /^(?:submit|button|image|reset|file)$/i,
            Tt = /^(?:input|select|textarea|keygen)/i;

        function kt(e, t, n, r) {
            var i;
            if (y.isArray(t)) {
                y.each(t, (function (t, i) {
                    if (n || bt.test(e)) {
                        r(e, i)
                    } else {
                        kt(e + "[" + (typeof i === "object" && i != null ? t : "") + "]", i, n, r)
                    }
                }))
            } else if (!n && y.type(t) === "object") {
                for (i in t) {
                    kt(e + "[" + i + "]", t[i], n, r)
                }
            } else {
                r(e, t)
            }
        }

        y.param = function (e, t) {
            var n, r = [], i = function (e, t) {
                var n = y.isFunction(t) ? t() : t;
                r[r.length] = encodeURIComponent(e) + "=" + encodeURIComponent(n == null ? "" : n)
            };
            if (y.isArray(e) || e.jquery && !y.isPlainObject(e)) {
                y.each(e, (function () {
                    i(this.name, this.value)
                }))
            } else {
                for (n in e) {
                    kt(n, e[n], t, i)
                }
            }
            return r.join("&")
        };
        y.fn.extend({
            serialize: function () {
                return y.param(this.serializeArray())
            }, serializeArray: function () {
                return this.map((function () {
                    var e = y.prop(this, "elements");
                    return e ? y.makeArray(e) : this
                })).filter((function () {
                    var e = this.type;
                    return this.name && !y(this).is(":disabled") && Tt.test(this.nodeName) && !xt.test(e) && (this.checked || !ue.test(e))
                })).map((function (e, t) {
                    var n = y(this).val();
                    if (n == null) {
                        return null
                    }
                    if (y.isArray(n)) {
                        return y.map(n, (function (e) {
                            return {name: t.name, value: e.replace(wt, "\r\n")}
                        }))
                    }
                    return {name: t.name, value: n.replace(wt, "\r\n")}
                })).get()
            }
        });
        var St = /%20/g, Ct = /#.*$/, At = /([?&])_=[^&]*/, _t = /^(.*?):[ \t]*([^\r\n]*)$/gm,
            Lt = /^(?:about|app|app-storage|.+-extension|file|res|widget):$/, Et = /^(?:GET|HEAD)$/, Nt = /^\/\//,
            Dt = {}, Pt = {}, It = "*/".concat("*"), Rt = r.createElement("a");
        Rt.href = gt.href;

        function jt(e) {
            return function (t, n) {
                if (typeof t !== "string") {
                    n = t;
                    t = "*"
                }
                var r, i = 0, a = t.toLowerCase().match(M) || [];
                if (y.isFunction(n)) {
                    while (r = a[i++]) {
                        if (r[0] === "+") {
                            r = r.slice(1) || "*";
                            (e[r] = e[r] || []).unshift(n)
                        } else {
                            (e[r] = e[r] || []).push(n)
                        }
                    }
                }
            }
        }

        function Mt(e, t, n, r) {
            var i = {}, a = e === Pt;

            function o(s) {
                var u;
                i[s] = true;
                y.each(e[s] || [], (function (e, s) {
                    var l = s(t, n, r);
                    if (typeof l === "string" && !a && !i[l]) {
                        t.dataTypes.unshift(l);
                        o(l);
                        return false
                    } else if (a) {
                        return !(u = l)
                    }
                }));
                return u
            }

            return o(t.dataTypes[0]) || !i["*"] && o("*")
        }

        function Ht(e, t) {
            var n, r, i = y.ajaxSettings.flatOptions || {};
            for (n in t) {
                if (t[n] !== undefined) {
                    (i[n] ? e : r || (r = {}))[n] = t[n]
                }
            }
            if (r) {
                y.extend(true, e, r)
            }
            return e
        }

        function qt(e, t, n) {
            var r, i, a, o, s = e.contents, u = e.dataTypes;
            while (u[0] === "*") {
                u.shift();
                if (r === undefined) {
                    r = e.mimeType || t.getResponseHeader("Content-Type")
                }
            }
            if (r) {
                for (i in s) {
                    if (s[i] && s[i].test(r)) {
                        u.unshift(i);
                        break
                    }
                }
            }
            if (u[0] in n) {
                a = u[0]
            } else {
                for (i in n) {
                    if (!u[0] || e.converters[i + " " + u[0]]) {
                        a = i;
                        break
                    }
                    if (!o) {
                        o = i
                    }
                }
                a = a || o
            }
            if (a) {
                if (a !== u[0]) {
                    u.unshift(a)
                }
                return n[a]
            }
        }

        function Ot(e, t, n, r) {
            var i, a, o, s, u, l = {}, c = e.dataTypes.slice();
            if (c[1]) {
                for (o in e.converters) {
                    l[o.toLowerCase()] = e.converters[o]
                }
            }
            a = c.shift();
            while (a) {
                if (e.responseFields[a]) {
                    n[e.responseFields[a]] = t
                }
                if (!u && r && e.dataFilter) {
                    t = e.dataFilter(t, e.dataType)
                }
                u = a;
                a = c.shift();
                if (a) {
                    if (a === "*") {
                        a = u
                    } else if (u !== "*" && u !== a) {
                        o = l[u + " " + a] || l["* " + a];
                        if (!o) {
                            for (i in l) {
                                s = i.split(" ");
                                if (s[1] === a) {
                                    o = l[u + " " + s[0]] || l["* " + s[0]];
                                    if (o) {
                                        if (o === true) {
                                            o = l[i]
                                        } else if (l[i] !== true) {
                                            a = s[0];
                                            c.unshift(s[1])
                                        }
                                        break
                                    }
                                }
                            }
                        }
                        if (o !== true) {
                            if (o && e.throws) {
                                t = o(t)
                            } else {
                                try {
                                    t = o(t)
                                } catch (e) {
                                    return {state: "parsererror", error: o ? e : "No conversion from " + u + " to " + a}
                                }
                            }
                        }
                    }
                }
            }
            return {state: "success", data: t}
        }

        y.extend({
            active: 0,
            lastModified: {},
            etag: {},
            ajaxSettings: {
                url: gt.href,
                type: "GET",
                isLocal: Lt.test(gt.protocol),
                global: true,
                processData: true,
                async: true,
                contentType: "application/x-www-form-urlencoded; charset=UTF-8",
                accepts: {
                    "*": It,
                    text: "text/plain",
                    html: "text/html",
                    xml: "application/xml, text/xml",
                    json: "application/json, text/javascript"
                },
                contents: {xml: /\bxml\b/, html: /\bhtml/, json: /\bjson\b/},
                responseFields: {xml: "responseXML", text: "responseText", json: "responseJSON"},
                converters: {"* text": String, "text html": true, "text json": JSON.parse, "text xml": y.parseXML},
                flatOptions: {url: true, context: true}
            },
            ajaxSetup: function (e, t) {
                return t ? Ht(Ht(e, y.ajaxSettings), t) : Ht(y.ajaxSettings, e)
            },
            ajaxPrefilter: jt(Dt),
            ajaxTransport: jt(Pt),
            ajax: function (t, n) {
                if (typeof t === "object") {
                    n = t;
                    t = undefined
                }
                n = n || {};
                var i, a, o, s, u, l, c, f, p, d, h = y.ajaxSetup({}, n), m = h.context || h,
                    g = h.context && (m.nodeType || m.jquery) ? y(m) : y.event, v = y.Deferred(),
                    b = y.Callbacks("once memory"), w = h.statusCode || {}, x = {}, T = {}, k = "canceled", S = {
                        readyState: 0, getResponseHeader: function (e) {
                            var t;
                            if (c) {
                                if (!s) {
                                    s = {};
                                    while (t = _t.exec(o)) {
                                        s[t[1].toLowerCase()] = t[2]
                                    }
                                }
                                t = s[e.toLowerCase()]
                            }
                            return t == null ? null : t
                        }, getAllResponseHeaders: function () {
                            return c ? o : null
                        }, setRequestHeader: function (e, t) {
                            if (c == null) {
                                e = T[e.toLowerCase()] = T[e.toLowerCase()] || e;
                                x[e] = t
                            }
                            return this
                        }, overrideMimeType: function (e) {
                            if (c == null) {
                                h.mimeType = e
                            }
                            return this
                        }, statusCode: function (e) {
                            var t;
                            if (e) {
                                if (c) {
                                    S.always(e[S.status])
                                } else {
                                    for (t in e) {
                                        w[t] = [w[t], e[t]]
                                    }
                                }
                            }
                            return this
                        }, abort: function (e) {
                            var t = e || k;
                            if (i) {
                                i.abort(t)
                            }
                            C(0, t);
                            return this
                        }
                    };
                v.promise(S);
                h.url = ((t || h.url || gt.href) + "").replace(Nt, gt.protocol + "//");
                h.type = n.method || n.type || h.method || h.type;
                h.dataTypes = (h.dataType || "*").toLowerCase().match(M) || [""];
                if (h.crossDomain == null) {
                    l = r.createElement("a");
                    try {
                        l.href = h.url;
                        l.href = l.href;
                        h.crossDomain = Rt.protocol + "//" + Rt.host !== l.protocol + "//" + l.host
                    } catch (e) {
                        h.crossDomain = true
                    }
                }
                if (h.data && h.processData && typeof h.data !== "string") {
                    h.data = y.param(h.data, h.traditional)
                }
                Mt(Dt, h, n, S);
                if (c) {
                    return S
                }
                f = y.event && h.global;
                if (f && y.active++ === 0) {
                    y.event.trigger("ajaxStart")
                }
                h.type = h.type.toUpperCase();
                h.hasContent = !Et.test(h.type);
                a = h.url.replace(Ct, "");
                if (!h.hasContent) {
                    d = h.url.slice(a.length);
                    if (h.data) {
                        a += (vt.test(a) ? "&" : "?") + h.data;
                        delete h.data
                    }
                    if (h.cache === false) {
                        a = a.replace(At, "$1");
                        d = (vt.test(a) ? "&" : "?") + "_=" + yt++ + d
                    }
                    h.url = a + d
                } else if (h.data && h.processData && (h.contentType || "").indexOf("application/x-www-form-urlencoded") === 0) {
                    h.data = h.data.replace(St, "+")
                }
                if (h.ifModified) {
                    if (y.lastModified[a]) {
                        S.setRequestHeader("If-Modified-Since", y.lastModified[a])
                    }
                    if (y.etag[a]) {
                        S.setRequestHeader("If-None-Match", y.etag[a])
                    }
                }
                if (h.data && h.hasContent && h.contentType !== false || n.contentType) {
                    S.setRequestHeader("Content-Type", h.contentType)
                }
                S.setRequestHeader("Accept", h.dataTypes[0] && h.accepts[h.dataTypes[0]] ? h.accepts[h.dataTypes[0]] + (h.dataTypes[0] !== "*" ? ", " + It + "; q=0.01" : "") : h.accepts["*"]);
                for (p in h.headers) {
                    S.setRequestHeader(p, h.headers[p])
                }
                if (h.beforeSend && (h.beforeSend.call(m, S, h) === false || c)) {
                    return S.abort()
                }
                k = "abort";
                b.add(h.complete);
                S.done(h.success);
                S.fail(h.error);
                i = Mt(Pt, h, n, S);
                if (!i) {
                    C(-1, "No Transport")
                } else {
                    S.readyState = 1;
                    if (f) {
                        g.trigger("ajaxSend", [S, h])
                    }
                    if (c) {
                        return S
                    }
                    if (h.async && h.timeout > 0) {
                        u = e.setTimeout((function () {
                            S.abort("timeout")
                        }), h.timeout)
                    }
                    try {
                        c = false;
                        i.send(x, C)
                    } catch (e) {
                        if (c) {
                            throw e
                        }
                        C(-1, e)
                    }
                }

                function C(t, n, r, s) {
                    var l, p, d, x, T, k = n;
                    if (c) {
                        return
                    }
                    c = true;
                    if (u) {
                        e.clearTimeout(u)
                    }
                    i = undefined;
                    o = s || "";
                    S.readyState = t > 0 ? 4 : 0;
                    l = t >= 200 && t < 300 || t === 304;
                    if (r) {
                        x = qt(h, S, r)
                    }
                    x = Ot(h, x, S, l);
                    if (l) {
                        if (h.ifModified) {
                            T = S.getResponseHeader("Last-Modified");
                            if (T) {
                                y.lastModified[a] = T
                            }
                            T = S.getResponseHeader("etag");
                            if (T) {
                                y.etag[a] = T
                            }
                        }
                        if (t === 204 || h.type === "HEAD") {
                            k = "nocontent"
                        } else if (t === 304) {
                            k = "notmodified"
                        } else {
                            k = x.state;
                            p = x.data;
                            d = x.error;
                            l = !d
                        }
                    } else {
                        d = k;
                        if (t || !k) {
                            k = "error";
                            if (t < 0) {
                                t = 0
                            }
                        }
                    }
                    S.status = t;
                    S.statusText = (n || k) + "";
                    if (l) {
                        v.resolveWith(m, [p, k, S])
                    } else {
                        v.rejectWith(m, [S, k, d])
                    }
                    S.statusCode(w);
                    w = undefined;
                    if (f) {
                        g.trigger(l ? "ajaxSuccess" : "ajaxError", [S, h, l ? p : d])
                    }
                    b.fireWith(m, [S, k]);
                    if (f) {
                        g.trigger("ajaxComplete", [S, h]);
                        if (!--y.active) {
                            y.event.trigger("ajaxStop")
                        }
                    }
                }

                return S
            },
            getJSON: function (e, t, n) {
                return y.get(e, t, n, "json")
            },
            getScript: function (e, t) {
                return y.get(e, undefined, t, "script")
            }
        });
        y.each(["get", "post"], (function (e, t) {
            y[t] = function (e, n, r, i) {
                if (y.isFunction(n)) {
                    i = i || r;
                    r = n;
                    n = undefined
                }
                return y.ajax(y.extend({url: e, type: t, dataType: i, data: n, success: r}, y.isPlainObject(e) && e))
            }
        }));
        y._evalUrl = function (e) {
            return y.ajax({
                url: e,
                type: "GET",
                dataType: "script",
                cache: true,
                async: false,
                global: false,
                throws: true
            })
        };
        y.fn.extend({
            wrapAll: function (e) {
                var t;
                if (this[0]) {
                    if (y.isFunction(e)) {
                        e = e.call(this[0])
                    }
                    t = y(e, this[0].ownerDocument).eq(0).clone(true);
                    if (this[0].parentNode) {
                        t.insertBefore(this[0])
                    }
                    t.map((function () {
                        var e = this;
                        while (e.firstElementChild) {
                            e = e.firstElementChild
                        }
                        return e
                    })).append(this)
                }
                return this
            }, wrapInner: function (e) {
                if (y.isFunction(e)) {
                    return this.each((function (t) {
                        y(this).wrapInner(e.call(this, t))
                    }))
                }
                return this.each((function () {
                    var t = y(this), n = t.contents();
                    if (n.length) {
                        n.wrapAll(e)
                    } else {
                        t.append(e)
                    }
                }))
            }, wrap: function (e) {
                var t = y.isFunction(e);
                return this.each((function (n) {
                    y(this).wrapAll(t ? e.call(this, n) : e)
                }))
            }, unwrap: function (e) {
                this.parent(e).not("body").each((function () {
                    y(this).replaceWith(this.childNodes)
                }));
                return this
            }
        });
        y.expr.pseudos.hidden = function (e) {
            return !y.expr.pseudos.visible(e)
        };
        y.expr.pseudos.visible = function (e) {
            return !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length)
        };
        y.ajaxSettings.xhr = function () {
            try {
                return new e.XMLHttpRequest
            } catch (e) {
            }
        };
        var Ft = {0: 200, 1223: 204}, Bt = y.ajaxSettings.xhr();
        h.cors = !!Bt && "withCredentials" in Bt;
        h.ajax = Bt = !!Bt;
        y.ajaxTransport((function (t) {
            var n, r;
            if (h.cors || Bt && !t.crossDomain) {
                return {
                    send: function (i, a) {
                        var o, s = t.xhr();
                        s.open(t.type, t.url, t.async, t.username, t.password);
                        if (t.xhrFields) {
                            for (o in t.xhrFields) {
                                s[o] = t.xhrFields[o]
                            }
                        }
                        if (t.mimeType && s.overrideMimeType) {
                            s.overrideMimeType(t.mimeType)
                        }
                        if (!t.crossDomain && !i["X-Requested-With"]) {
                            i["X-Requested-With"] = "XMLHttpRequest"
                        }
                        for (o in i) {
                            s.setRequestHeader(o, i[o])
                        }
                        n = function (e) {
                            return function () {
                                if (n) {
                                    n = r = s.onload = s.onerror = s.onabort = s.onreadystatechange = null;
                                    if (e === "abort") {
                                        s.abort()
                                    } else if (e === "error") {
                                        if (typeof s.status !== "number") {
                                            a(0, "error")
                                        } else {
                                            a(s.status, s.statusText)
                                        }
                                    } else {
                                        a(Ft[s.status] || s.status, s.statusText, (s.responseType || "text") !== "text" || typeof s.responseText !== "string" ? {binary: s.response} : {text: s.responseText}, s.getAllResponseHeaders())
                                    }
                                }
                            }
                        };
                        s.onload = n();
                        r = s.onerror = n("error");
                        if (s.onabort !== undefined) {
                            s.onabort = r
                        } else {
                            s.onreadystatechange = function () {
                                if (s.readyState === 4) {
                                    e.setTimeout((function () {
                                        if (n) {
                                            r()
                                        }
                                    }))
                                }
                            }
                        }
                        n = n("abort");
                        try {
                            s.send(t.hasContent && t.data || null)
                        } catch (e) {
                            if (n) {
                                throw e
                            }
                        }
                    }, abort: function () {
                        if (n) {
                            n()
                        }
                    }
                }
            }
        }));
        y.ajaxPrefilter((function (e) {
            if (e.crossDomain) {
                e.contents.script = false
            }
        }));
        y.ajaxSetup({
            accepts: {script: "text/javascript, application/javascript, " + "application/ecmascript, application/x-ecmascript"},
            contents: {script: /\b(?:java|ecma)script\b/},
            converters: {
                "text script": function (e) {
                    y.globalEval(e);
                    return e
                }
            }
        });
        y.ajaxPrefilter("script", (function (e) {
            if (e.cache === undefined) {
                e.cache = false
            }
            if (e.crossDomain) {
                e.type = "GET"
            }
        }));
        y.ajaxTransport("script", (function (e) {
            if (e.crossDomain) {
                var t, n;
                return {
                    send: function (i, a) {
                        t = y("<script>").prop({
                            charset: e.scriptCharset,
                            src: e.url
                        }).on("load error", n = function (e) {
                            t.remove();
                            n = null;
                            if (e) {
                                a(e.type === "error" ? 404 : 200, e.type)
                            }
                        });
                        r.head.appendChild(t[0])
                    }, abort: function () {
                        if (n) {
                            n()
                        }
                    }
                }
            }
        }));
        var Ut = [], Wt = /(=)\?(?=&|$)|\?\?/;
        y.ajaxSetup({
            jsonp: "callback", jsonpCallback: function () {
                var e = Ut.pop() || y.expando + "_" + yt++;
                this[e] = true;
                return e
            }
        });
        y.ajaxPrefilter("json jsonp", (function (t, n, r) {
            var i, a, o,
                s = t.jsonp !== false && (Wt.test(t.url) ? "url" : typeof t.data === "string" && (t.contentType || "").indexOf("application/x-www-form-urlencoded") === 0 && Wt.test(t.data) && "data");
            if (s || t.dataTypes[0] === "jsonp") {
                i = t.jsonpCallback = y.isFunction(t.jsonpCallback) ? t.jsonpCallback() : t.jsonpCallback;
                if (s) {
                    t[s] = t[s].replace(Wt, "$1" + i)
                } else if (t.jsonp !== false) {
                    t.url += (vt.test(t.url) ? "&" : "?") + t.jsonp + "=" + i
                }
                t.converters["script json"] = function () {
                    if (!o) {
                        y.error(i + " was not called")
                    }
                    return o[0]
                };
                t.dataTypes[0] = "json";
                a = e[i];
                e[i] = function () {
                    o = arguments
                };
                r.always((function () {
                    if (a === undefined) {
                        y(e).removeProp(i)
                    } else {
                        e[i] = a
                    }
                    if (t[i]) {
                        t.jsonpCallback = n.jsonpCallback;
                        Ut.push(i)
                    }
                    if (o && y.isFunction(a)) {
                        a(o[0])
                    }
                    o = a = undefined
                }));
                return "script"
            }
        }));
        h.createHTMLDocument = function () {
            var e = r.implementation.createHTMLDocument("").body;
            e.innerHTML = "<form></form><form></form>";
            return e.childNodes.length === 2
        }();
        y.parseHTML = function (e, t, n) {
            if (typeof e !== "string") {
                return []
            }
            if (typeof t === "boolean") {
                n = t;
                t = false
            }
            var i, a, o;
            if (!t) {
                if (h.createHTMLDocument) {
                    t = r.implementation.createHTMLDocument("");
                    i = t.createElement("base");
                    i.href = r.location.href;
                    t.head.appendChild(i)
                } else {
                    t = r
                }
            }
            a = _.exec(e);
            o = !n && [];
            if (a) {
                return [t.createElement(a[1])]
            }
            a = me([e], t, o);
            if (o && o.length) {
                y(o).remove()
            }
            return y.merge([], a.childNodes)
        };
        y.fn.load = function (e, t, n) {
            var r, i, a, o = this, s = e.indexOf(" ");
            if (s > -1) {
                r = pt(e.slice(s));
                e = e.slice(0, s)
            }
            if (y.isFunction(t)) {
                n = t;
                t = undefined
            } else if (t && typeof t === "object") {
                i = "POST"
            }
            if (o.length > 0) {
                y.ajax({url: e, type: i || "GET", dataType: "html", data: t}).done((function (e) {
                    a = arguments;
                    o.html(r ? y("<div>").append(y.parseHTML(e)).find(r) : e)
                })).always(n && function (e, t) {
                    o.each((function () {
                        n.apply(this, a || [e.responseText, t, e])
                    }))
                })
            }
            return this
        };
        y.each(["ajaxStart", "ajaxStop", "ajaxComplete", "ajaxError", "ajaxSuccess", "ajaxSend"], (function (e, t) {
            y.fn[t] = function (e) {
                return this.on(t, e)
            }
        }));
        y.expr.pseudos.animated = function (e) {
            return y.grep(y.timers, (function (t) {
                return e === t.elem
            })).length
        };

        function Kt(e) {
            return y.isWindow(e) ? e : e.nodeType === 9 && e.defaultView
        }

        y.offset = {
            setOffset: function (e, t, n) {
                var r, i, a, o, s, u, l, c = y.css(e, "position"), f = y(e), p = {};
                if (c === "static") {
                    e.style.position = "relative"
                }
                s = f.offset();
                a = y.css(e, "top");
                u = y.css(e, "left");
                l = (c === "absolute" || c === "fixed") && (a + u).indexOf("auto") > -1;
                if (l) {
                    r = f.position();
                    o = r.top;
                    i = r.left
                } else {
                    o = parseFloat(a) || 0;
                    i = parseFloat(u) || 0
                }
                if (y.isFunction(t)) {
                    t = t.call(e, n, y.extend({}, s))
                }
                if (t.top != null) {
                    p.top = t.top - s.top + o
                }
                if (t.left != null) {
                    p.left = t.left - s.left + i
                }
                if ("using" in t) {
                    t.using.call(e, p)
                } else {
                    f.css(p)
                }
            }
        };
        y.fn.extend({
            offset: function (e) {
                if (arguments.length) {
                    return e === undefined ? this : this.each((function (t) {
                        y.offset.setOffset(this, e, t)
                    }))
                }
                var t, n, r, i, a = this[0];
                if (!a) {
                    return
                }
                if (!a.getClientRects().length) {
                    return {top: 0, left: 0}
                }
                r = a.getBoundingClientRect();
                if (r.width || r.height) {
                    i = a.ownerDocument;
                    n = Kt(i);
                    t = i.documentElement;
                    return {top: r.top + n.pageYOffset - t.clientTop, left: r.left + n.pageXOffset - t.clientLeft}
                }
                return r
            }, position: function () {
                if (!this[0]) {
                    return
                }
                var e, t, n = this[0], r = {top: 0, left: 0};
                if (y.css(n, "position") === "fixed") {
                    t = n.getBoundingClientRect()
                } else {
                    e = this.offsetParent();
                    t = this.offset();
                    if (!y.nodeName(e[0], "html")) {
                        r = e.offset()
                    }
                    r = {
                        top: r.top + y.css(e[0], "borderTopWidth", true),
                        left: r.left + y.css(e[0], "borderLeftWidth", true)
                    }
                }
                return {
                    top: t.top - r.top - y.css(n, "marginTop", true),
                    left: t.left - r.left - y.css(n, "marginLeft", true)
                }
            }, offsetParent: function () {
                return this.map((function () {
                    var e = this.offsetParent;
                    while (e && y.css(e, "position") === "static") {
                        e = e.offsetParent
                    }
                    return e || ge
                }))
            }
        });
        y.each({scrollLeft: "pageXOffset", scrollTop: "pageYOffset"}, (function (e, t) {
            var n = "pageYOffset" === t;
            y.fn[e] = function (r) {
                return K(this, (function (e, r, i) {
                    var a = Kt(e);
                    if (i === undefined) {
                        return a ? a[t] : e[r]
                    }
                    if (a) {
                        a.scrollTo(!n ? i : a.pageXOffset, n ? i : a.pageYOffset)
                    } else {
                        e[r] = i
                    }
                }), e, r, arguments.length)
            }
        }));
        y.each(["top", "left"], (function (e, t) {
            y.cssHooks[t] = Fe(h.pixelPosition, (function (e, n) {
                if (n) {
                    n = Oe(e, t);
                    return He.test(n) ? y(e).position()[t] + "px" : n
                }
            }))
        }));
        y.each({Height: "height", Width: "width"}, (function (e, t) {
            y.each({padding: "inner" + e, content: t, "": "outer" + e}, (function (n, r) {
                y.fn[r] = function (i, a) {
                    var o = arguments.length && (n || typeof i !== "boolean"),
                        s = n || (i === true || a === true ? "margin" : "border");
                    return K(this, (function (t, n, i) {
                        var a;
                        if (y.isWindow(t)) {
                            return r.indexOf("outer") === 0 ? t["inner" + e] : t.document.documentElement["client" + e]
                        }
                        if (t.nodeType === 9) {
                            a = t.documentElement;
                            return Math.max(t.body["scroll" + e], a["scroll" + e], t.body["offset" + e], a["offset" + e], a["client" + e])
                        }
                        return i === undefined ? y.css(t, n, s) : y.style(t, n, i, s)
                    }), t, o ? i : undefined, o)
                }
            }))
        }));
        y.fn.extend({
            bind: function (e, t, n) {
                return this.on(e, null, t, n)
            }, unbind: function (e, t) {
                return this.off(e, null, t)
            }, delegate: function (e, t, n, r) {
                return this.on(t, e, n, r)
            }, undelegate: function (e, t, n) {
                return arguments.length === 1 ? this.off(e, "**") : this.off(t, e || "**", n)
            }
        });
        y.parseJSON = JSON.parse;
        if (typeof define === "function" && define.amd) {
            define("jquery", [], (function () {
                return y
            }))
        }
        var $t = e.jQuery, Vt = e.$;
        y.noConflict = function (t) {
            if (e.$ === y) {
                e.$ = Vt
            }
            if (t && e.jQuery === y) {
                e.jQuery = $t
            }
            return y
        };
        if (!t) {
            e.jQuery = e.$ = y
        }
        return y
    }));
    chrome.webRequest.onHeadersReceived.addListener((function (e) {
        for (var t = 0; t < e.responseHeaders.length; ++t) {
            if (e.responseHeaders[t].name.toLowerCase() === "content-security-policy") {
                e.responseHeaders.splice(t, 1);
                break
            }
        }
        for (var t = 0; t < e.responseHeaders.length; ++t) {
            if (e.responseHeaders[t].name.toLowerCase() === "x-content-security-policy") {
                e.responseHeaders.splice(t, 1);
                break
            }
        }
        for (var t = 0; t < e.responseHeaders.length; ++t) {
            if (e.responseHeaders[t].name.toLowerCase() === "x-webkit-csp") {
                e.responseHeaders.splice(t, 1);
                break
            }
        }
        return {responseHeaders: e.responseHeaders}
    }), {urls: ["<all_urls>"]}, ["blocking", "responseHeaders"]);
    chrome.webRequest.onHeadersReceived.addListener((function (e) {
        if (typeof globalStatus === "undefined" || !globalStatus.enable || typeof globalStatus.solve_funcaptcha === "undefined" || !globalStatus.solve_funcaptcha || typeof e.initiator !== "undefined" && currentHostnameWhiteBlackListedOut(globalStatus, e.initiator)) {
            return
        }
        if (typeof URLSearchParams === "function") {
            var t = e.url;
            var n = parseUrl(t);
            var r = new URLSearchParams(n.search);
            var i = r.get("onload");
            var a;
            var o;
            if (!i && i !== "_funcaptchaOnloadMethod") {
                a = "_funcaptchaOnloadMethod";
                r.set("onload", "_funcaptchaOnloadMethod");
                n.search = r.toString();
                o = n.toString()
            } else {
                o = t;
                a = i
            }
            if (e.tabId) {
                chrome.tabs.sendMessage(e.tabId, {
                    type: "funcaptchaApiScriptRequested",
                    originalFuncaptchaApiUrl: t,
                    originalOnloadMethodName: i,
                    currentFuncaptchaApiUrl: o,
                    currentOnloadMethodName: a
                }, {frameId: e.frameId}, (function () {
                }))
            }
            return
        }
    }), {urls: ["https://funcaptcha.com/fc/api/*", "https://*.funcaptcha.com/fc/api/*", "https://arkoselabs.com/fc/api/*", "https://*.arkoselabs.com/fc/api/*"]});
    chrome.webRequest.onHeadersReceived.addListener((function (e) {
        if (typeof globalStatus === "undefined" || !globalStatus.enable || typeof globalStatus.solve_hcaptcha === "undefined" || !globalStatus.solve_hcaptcha || typeof e.initiator !== "undefined" && currentHostnameWhiteBlackListedOut(globalStatus, e.initiator)) {
            return
        }
        if (typeof URLSearchParams === "function") {
            var t = e.url;
            var n = parseUrl(t);
            var r = new URLSearchParams(n.search);
            var i = r.get("onload");
            var a;
            var o;
            if (!i && i !== h) {
                a = h;
                r.set("onload", h);
                n.search = r.toString();
                o = n.toString()
            } else {
                o = t;
                a = i
            }
            if (e.tabId) {
                chrome.tabs.sendMessage(e.tabId, {
                    type: "hcaptchaApiScriptRequested",
                    originalHcaptchaApiUrl: t,
                    originalOnloadMethodName: i,
                    currentHcaptchaApiUrl: o,
                    currentOnloadMethodName: a,
                    runExplicitInvisibleHcaptchaCallbackWhenChallengeShown: globalStatus.run_explicit_invisible_hcaptcha_callback_when_challenge_shown
                }, {frameId: e.frameId}, (function () {
                }))
            }
        }
    }), {urls: ["https://hcaptcha.com/1/api.js*", "https://*.hcaptcha.com/1/api.js*"]});
    chrome.webRequest.onHeadersReceived.addListener((function (e) {
        if (typeof URLSearchParams === "function") {
            var t = parseUrl(e.url);
            var n = new URLSearchParams(t.search);
            var r = n.get("render");
            if (r && r !== "explicit" && r !== "onload" && r.length > 20) {
                for (var i = 0; i < e.responseHeaders.length; ++i) {
                    if (e.responseHeaders[i].name.toLowerCase() === "cache-control") {
                        e.responseHeaders.splice(i, 1);
                        break
                    }
                }
            }
        }
        return {responseHeaders: e.responseHeaders}
    }), {urls: ["https://www.google.com/recaptcha/api.js*", "https://google.com/recaptcha/api.js*", "https://www.google.com/recaptcha/enterprise.js*", "https://google.com/recaptcha/enterprise.js*", "https://www.recaptcha.net/recaptcha/api.js*", "https://recaptcha.net/recaptcha/api.js*", "https://www.recaptcha.net/recaptcha/enterprise.js*", "https://recaptcha.net/recaptcha/enterprise.js*"]}, ["blocking", "responseHeaders"]);
    chrome.webRequest.onBeforeRequest.addListener((function (e) {
        if (typeof globalStatus === "undefined" || !globalStatus.enable || typeof globalStatus.solve_recaptcha3 === "undefined" || !globalStatus.solve_recaptcha3 || typeof e.initiator !== "undefined" && currentHostnameWhiteBlackListedOut(globalStatus, e.initiator)) {
            return
        }
        if (typeof URLSearchParams === "function") {
            var t = e.url;
            var n = parseUrl(t);
            var r = new URLSearchParams(n.search);
            var i = r.get("onload");
            var a = r.get("render");
            if (a && a !== "explicit" && a !== "onload" && a.length > 20) {
                if (
                    /*!originalOnloadMethodName
                    // this check in case we do return { redirectUrl: '...' } in previous iteration

                    // looks like we don't need it anymore. todo: remove this check maybe
                    &&*/
                    !i || i.indexOf(d) === -1) {
                    if (e.tabId) {
                        chrome.tabs.sendMessage(e.tabId, {
                            type: "recaptcha3OriginalCallback",
                            lastOriginalOnloadMethodName: i
                        }, {frameId: e.frameId})
                    }
                    r.set("onload", d);
                    n.search = r.toString();
                    var o = n.toString();
                    return {redirectUrl: o}
                } else {
                }
            }
        }
        return {responseHeaders: e.responseHeaders}
    }), {urls: ["https://www.google.com/recaptcha/api.js*", "https://google.com/recaptcha/api.js*", "https://www.google.com/recaptcha/enterprise.js*", "https://google.com/recaptcha/enterprise.js*", "https://www.recaptcha.net/recaptcha/api.js*", "https://recaptcha.net/recaptcha/api.js*", "https://www.recaptcha.net/recaptcha/enterprise.js*", "https://recaptcha.net/recaptcha/enterprise.js*"]}, ["blocking"]);
    globalStatus = {
        profile_user_info: null,
        plugin_version: chrome.app && chrome.app.getDetails && chrome.app.getDetails().version ? chrome.app.getDetails().version : chrome.runtime && chrome.runtime.getManifest() && chrome.runtime.getManifest().version ? chrome.runtime.getManifest().version : "0.001",
        plugin_last_version_data: null,
        options_current_tab: null
    };
    var fe = {};
    var pe = {};
    var de = _() - t + n;
    var he = _() - r + a;
    var me = 0;
    var ge = 0;
    setInterval((function () {
        if (globalStatus.enable !== fe.enable || globalStatus.account_key !== fe.account_key || globalStatus.profile_user_info !== fe.profile_user_info) {
            Te();
            getAndRefreshAntigateBalance();
            Se()
        }
    }), 500);
    g(ke);
    xe();
    ye();
    ve();
    setInterval(g.bind(null, ke), 2e3);
    setInterval(xe, 2e3);

    function ye() {
        if (de + t + me <= _()) {
            be()
        }
    }

    function ve() {
        if (he + r + ge <= _()) {
            we()
        }
    }

    function be() {
        oe((function (e, t) {
            if (!e) {
                pe = t;
                de = _();
                me = 0
            } else {
                if (!me) {
                    me = 10
                } else {
                    me = me * 2
                }
            }
        }))
    }

    function we() {
        se((function (e, t) {
            if (!e) {
                globalStatus.plugin_last_version_data = t;
                he = _();
                ge = 0
            } else {
                if (!ge) {
                    ge = 10
                } else {
                    ge = ge * 2
                }
            }
        }))
    }

    function xe() {
        typeof chrome.identity != "undefined" && typeof chrome.identity.getProfileUserInfo != "undefined" && chrome.identity.getProfileUserInfo((function (e) {
            if (e && e.id && e.email) {
                globalStatus.profile_user_info = e
            } else {
                globalStatus.profile_user_info = false
            }
        }))
    }

    function Te() {
        Ae();
        _e()
    }

    chrome.runtime.onMessage.addListener((function (e, t, n) {
        if (e.type == "getProfileUserInfo") {
            delete e.type;
            n(globalStatus.profile_user_info)
        } else if (e.type == "setFreeAttemptsLeftCount") {
            delete e.type;
            if (typeof e.attemptsLeft != "undefined") {
                (chrome.storage.sync && typeof browser == "undefined" ? chrome.storage.sync : chrome.storage.local).set({free_attempts_left_count: e.attemptsLeft}, (function () {
                    globalStatus.free_attempts_left_count = e.attemptsLeft
                }))
            }
        } else if (e.type == "getGlobalStatus") {
            delete e.type;
            n(globalStatus)
        } else if (e.type == "saveOptions") {
            delete e.type;
            var r = typeof e.options === "undefined" || typeof e.options.enable === "undefined" || typeof e.options.account_key === "undefined";
            saveOptions(e.options, n, r)
        } else if (e.type == "getAndRefreshAntigateBalance") {
            getAndRefreshAntigateBalance()
        }
        return true
    }));
    saveOptions = function (e, t, n) {
        n = !!n;
        if (!n) {
            e.account_key_checked = false
        }
        (chrome.storage.sync && typeof browser == "undefined" ? chrome.storage.sync : chrome.storage.local).set(e, (function () {
            ke(e);
            t(e);
            Pe.refreshPrecachedSolutionsCountKForEveryHost();
            if (!n || typeof window.ApplePayError !== "undefined") {
                Te();
                getAndRefreshAntigateBalance();
                Se()
            }
        }))
    };

    function ke(e) {
        for (var t in e) {
            globalStatus[t] = e[t]
        }
    }

    function Se() {
        fe = {
            enable: globalStatus.enable,
            account_key: globalStatus.account_key,
            profile_user_info: globalStatus.profile_user_info
        }
    }

    function Ce(e, t) {
        if (e) {
            chrome.runtime.sendMessage({type: "showMessage", method: "showErrorMessage", arguments: [e.message]});
            if (globalStatus.profile_user_info !== null) {
                chrome.runtime.sendMessage({type: "showMessage", method: "refreshFreeAttemptsMessage"})
            }
            return
        }
        chrome.runtime.sendMessage({type: "showMessage", method: "showBalanceMessage", arguments: [t]});
        if (t > 0) {
            (chrome.storage.sync && typeof browser == "undefined" ? chrome.storage.sync : chrome.storage.local).set({account_key_checked: true}, (function () {
                globalStatus.account_key_checked = true
            }))
        } else {
        }
    }

    getAndRefreshAntigateBalance = function () {
        if (globalStatus.enable) {
            if (globalStatus.account_key) {
                var e = Re(globalStatus.account_key);
                e.getBalance(Ce)
            } else {
                if (globalStatus.profile_user_info !== null) {
                    chrome.runtime.sendMessage({type: "showMessage", method: "refreshFreeAttemptsMessage"})
                }
            }
        } else {
            chrome.runtime.sendMessage({type: "showMessage", method: "showBalanceMessage", arguments: [""]})
        }
    };

    function Ae() {
        var e = "";
        var t = chrome.i18n.getMessage("appShortName");
        if (globalStatus.enable && globalStatus.profile_user_info && globalStatus.free_attempts_left_count && (!globalStatus.account_key || !globalStatus.account_key_checked)) {
            e = globalStatus.free_attempts_left_count + ""
        } else if (globalStatus.plugin_last_version_data && typeof globalStatus.plugin_last_version_data.version !== "undefined" && globalStatus.plugin_version < globalStatus.plugin_last_version_data.version) {
            e = "new"
        } else {
            e = ""
        }
        if (globalStatus.free_attempts_left_count && (!globalStatus.account_key || !globalStatus.account_key_checked) && globalStatus.profile_user_info) {
            t += ": " + chrome.i18n.getMessage("freeAttemptsLeftActionTitle", globalStatus.free_attempts_left_count + "")
        } else {
        }
        chrome.browserAction.setBadgeText({text: e});
        chrome.browserAction.setTitle({title: t})
    }

    function _e() {
        if (globalStatus.enable) {
            chrome.browserAction.setIcon({
                path: {
                    16: "/img/anticaptcha-logo/16.png",
                    32: "/img/anticaptcha-logo/32.png"
                }
            })
        } else {
            chrome.browserAction.setIcon({
                path: {
                    16: "/img/anticaptcha-logo/disabled-16.png",
                    32: "/img/anticaptcha-logo/disabled-32.png"
                }
            })
        }
    }

    var Le = new function () {
        var e, t, n;
        this.showImageContextMenu = function () {
            this.hideImageContextMenu();
            e = chrome.contextMenus.create({
                id: "1",
                title: chrome.i18n.getMessage("markImageTitle"),
                contexts: ["image", "page"],
                onclick: this.markAsCaptchaRelated.bind(null, "image", false)
            })
        };
        this.hideImageContextMenu = function () {
            if (e) {
                chrome.contextMenus.remove(e)
            }
        };
        this.showInputContextMenu = function () {
            this.hideInputContextMenu();
            n = chrome.contextMenus.create({
                id: "2",
                title: chrome.i18n.getMessage("markInputTitle"),
                contexts: ["editable"],
                onclick: this.markAsCaptchaRelated.bind(null, "input", false)
            })
        };
        this.hideInputContextMenu = function () {
            if (n) {
                chrome.contextMenus.remove(n)
            }
        };
        this.showImageAutosearchContextMenu = function () {
            this.hideImageAutosearchContextMenu();
            t = chrome.contextMenus.create({
                id: "3",
                title: chrome.i18n.getMessage("imageAutosearchTitle"),
                contexts: ["editable"],
                onclick: this.markAsCaptchaRelated.bind(null, "input", true)
            })
        };
        this.hideImageAutosearchContextMenu = function () {
            if (t) {
                chrome.contextMenus.remove(t)
            }
        };
        this.markAsCaptchaRelated = function (e, t, n, r) {
            chrome.tabs.sendMessage(r.id, {
                type: "contextMenuClickedOnCaptchaRelated",
                elementType: e,
                autosearch: t
            }, {frameId: n.frameId}, (function () {
            }))
        }
    };
    Le.showImageContextMenu();
    Le.showInputContextMenu();
    Le.showImageAutosearchContextMenu();
    chrome.runtime.onMessage.addListener((function (e, t, n) {
        if (e.type == "setCaptchaDeterminer") {
            delete e.type;
            var r;
            if (e.domain) {
                r = e.domain
            } else {
                r = parseUrl(t.url).hostname;
                e.domain = r
            }
            X(r, e, (function () {
                (chrome.storage.sync && typeof browser == "undefined" ? chrome.storage.sync : chrome.storage.local).get((function (e) {
                    n(typeof e.captchaDeterminant !== "undefined" ? e.captchaDeterminant : null)
                }))
            }))
        } else if (e.type == "getCaptchaDeterminer") {
            delete e.type;
            var r = parseUrl(t.url).hostname;
            e.domain = r;
            Q(r, (function (e) {
                if (e) {
                    if (typeof e.source == "undefined") {
                        e.source = "manual"
                    }
                    if (!e.options) {
                        e.options = {}
                    }
                    e.options = Object.assign(Object.assign({}, c), e.options);
                    n(e)
                } else if (globalStatus.use_predefined_image_captcha_marks && typeof pe[r] != "undefined") {
                    pe[r].source = "predefined";
                    pe[r].options = c;
                    n(pe[r])
                } else {
                }
                n(e)
            }));
            ye();
            ve()
        } else if (e.type == "setCaptchaDeterminerOptions") {
            delete e.type;
            var r = parseUrl(t.url).hostname;
            e.domain = r;
            J(r, e, (function () {
            }))
        } else if (e.type == "requestPermissions") {
            delete e.type;
            chrome.permissions.request({permissions: e.permissions}, n);
            return true
        } else if (e.type == "setImageCaptchaCache") {
            delete e.type;
            je.set(e.index, e.value)
        } else if (e.type == "getImageCaptchaCache") {
            delete e.type;
            n(je.get(e.index))
        }
        return true
    }));
    var Ee = function (e) {
        return new function (e) {
            this.params = {websiteUrl: null, websiteKey: null, websiteSToken: null, userAgent: ""};
            this.getCacheForHostname = function (t, n, r) {
                ALogger.log("getCacheForHostname called");
                var i = parseUrl(t.task.websiteURL).hostname;
                var a = e.getByHostname(i, n);
                ALogger.log("cacheContent by hostname = ", a);
                var o;
                if (a) {
                    o = a.fakeTaskId
                } else {
                    o = e.create(i, t.task.websiteKey, n)
                }
                var s = {errorId: 0, taskId: o};
                r(s)
            };
            this.getSolution = function (t, n, r) {
                var i = e.getByTaskId(t.taskId, n);
                ALogger.log("cacheContent by task id = ", i);
                var a = null;
                ALogger.log("cacheContent by hostname = ", a);
                var o;
                var s = false;
                if (i) {
                    if (i.taskData && i.taskData.hostname) {
                        o = e.getByHostname(i.taskData.hostname, n)
                    }
                    if (i.fakeTaskId !== o.fakeTaskId && !o.error) {
                        ALogger.log("Better result is found, switching to it", a);
                        i = o;
                        s = true
                    }
                    if (i.endTime) {
                        e.markTaskAsProcessedToContentScript(i);
                        r({
                            errorId: 0,
                            status: "ready",
                            solution: {gRecaptchaResponse: i.solution},
                            lifetime: e.cacheFreshnessTime - (_() - i.endTime)
                        })
                    } else if (i.error) {
                        e.markTaskAsProcessedToContentScript(i);
                        r({errorId: 1, errorCode: "error", errorDescription: i.error})
                    } else {
                        var u = {errorId: 0, status: "processing"};
                        if (s) {
                            u.newTaskId = i.fakeTaskId
                        }
                        r(u)
                    }
                } else {
                    return r({
                        errorId: 16,
                        errorCode: "ERROR_NO_SUCH_CAPCHA_ID",
                        errorDescription: "Task you are requesting does not exist in your current task list or has been expired.Tasks not found in active tasks"
                    })
                }
            }
        }(e)
    };
    var Ne = new function () {
        this.log = function (e, t) {
            chrome.runtime.sendMessage({type: "notifyRecaptchaPrecacheDebugPage", dataType: e, postData: t})
        }
    };
    var De = function (e) {
        return new function (e) {
            var t = this;
            var n = $.Callbacks();
            n.add((function (e) {
                if (typeof v[e] !== "undefined" && typeof m[v[e].taskData.hostname] !== "undefined") {
                    var t = m[v[e].taskData.hostname];
                    t.totalSolvingTime += v[e].endTime - v[e].startTime;
                    t.totalSolvedTasks++;
                    t.mediumSolvingTime = (t.totalSolvingTime + t.mediumSolvingTime) / (t.totalSolvedTasks + 1)
                }
            }));
            var r = $.Callbacks();
            r.add((function (e) {
                if (typeof v[e] !== "undefined" && typeof m[v[e].taskData.hostname] !== "undefined") {
                    var t = m[v[e].taskData.hostname];
                    t.totalFeelsLikeSolvingTime += v[e].taskProcessingToContentScriptTime - v[e].requestTime;
                    t.mediumFeelsLikeSolvingTime = (t.totalFeelsLikeSolvingTime + t.mediumFeelsLikeSolvingTime) / (t.totalSolvedTasks + 1)
                }
            }));
            var i = $.Callbacks();
            i.add((function (e) {
                if (typeof m[e] === "undefined") {
                    return
                }
                var t = m[e];
                t.tasks = t.tasks.sort((function (e, t) {
                    if (S(e) && !S(t)) {
                        return -1
                    } else if (!S(e) && S(t)) {
                        return 1
                    } else {
                        if (!e.error && t.error) {
                            return -1
                        } else if (e.error && !t.error) {
                            return 1
                        } else {
                            if (e.endTime !== null && t.endTime === null) {
                                return -1
                            } else if (e.endTime === null && t.endTime !== null) {
                                return 1
                            } else if (e.endTime === null && t.endTime === null) {
                                return 0
                            } else {
                                if (e.endTime < t.endTime) {
                                    return -1
                                } else if (e.endTime > t.endTime) {
                                    return 1
                                } else {
                                    if (e.startTime < t.startTime) {
                                        return -1
                                    } else if (e.startTime > t.startTime) {
                                        return 1
                                    } else {
                                        return 0
                                    }
                                }
                            }
                        }
                    }
                }))
            }));
            var a = $.Callbacks();
            a.add((function (e, t) {
                if (typeof v[e] !== "undefined") {
                    switch (t.type) {
                        case"start":
                            v[e].startTime = _();
                            break;
                        case"error":
                            v[e].error = t.error.message;
                            break;
                        case"attach":
                        case"detach":
                        case"reattach":
                            i.fire(v[e].taskData.hostname);
                            break;
                        case"setRealTaskId":
                            v[e].realTaskId = t.realTaskId;
                            break;
                        case"finish":
                            v[e].endTime = _();
                            v[e].solution = t.taskSolution;
                            i.fire(v[e].taskData.hostname);
                            break
                    }
                }
            }));
            var o = $.Callbacks();
            o.add((function (e, t) {
                e.tabIdLastCheckTime = _();
                if (e.tabId != t) {
                    e.tabId = t;
                    e.requestTime = _();
                    a.fire(e.fakeTaskId, {type: "attach"})
                }
            }));
            var s = $.Callbacks();
            s.add((function (e) {
                e.tabId = null;
                e.tabIdLastCheckTime = null;
                e.requestTime = null;
                a.fire(e.fakeTaskId, {type: "detach"})
            }));
            var u = $.Callbacks();
            u.add((function (e, t) {
                e.tabIdLastCheckTime = _();
                if (e.tabId != t) {
                    e.tabId = t;
                    a.fire(e.fakeTaskId, {type: "reattach"})
                }
            }));
            var l = $.Callbacks();
            l.add((function (e, t) {
                if (typeof m[e] !== "undefined") {
                    var n = m[e];
                    n.noCacheRequestsSinceLastSolutionExpiration = t
                }
            }));
            var c = setInterval((function () {
                for (var e in v) {
                    if (!v[e].startTime) {
                        a.fire(e, {type: "start"});
                        var t = Re(globalStatus.account_key);
                        t.setWebsiteURL("https://" + v[e].taskData.hostname + "/");
                        t.setWebsiteKey(v[e].taskData.siteKey);
                        t.setSoftId(802);
                        var r = t.createTaskProxyless;
                        if (globalStatus.solve_proxy_on_tasks) {
                            t.setProxyType(globalStatus.user_proxy_protocol);
                            t.setProxyAddress(globalStatus.user_proxy_server);
                            t.setProxyPort(globalStatus.user_proxy_port);
                            t.setProxyLogin(globalStatus.user_proxy_login);
                            t.setProxyPassword(globalStatus.user_proxy_password);
                            t.setUserAgent(navigator.userAgent);
                            r = t.createTask
                        }
                        (function (e) {
                            r.call(t, (function (r, i) {
                                if (r) {
                                    console.error(r);
                                    a.fire(e, {type: "error", error: r});
                                    return
                                }
                                a.fire(e, {type: "setRealTaskId", realTaskId: i});
                                t.getTaskSolution(i, (function (t, r) {
                                    if (t) {
                                        a.fire(e, {type: "error", error: t});
                                        console.error(t);
                                        return
                                    }
                                    a.fire(e, {type: "finish", taskSolution: r});
                                    n.fire(e)
                                }))
                            }))
                        })(e)
                    }
                }
            }), 1e3);
            var f = setInterval((function () {
                for (var e in v) {
                    if (!v[e].expired && C(v[e])) {
                        ALogger.log("task expired, fakeid = ", e, v[e]);
                        v[e].expired = true;
                        if (!v[e].taskProcessingToContentScriptTime) {
                            if (typeof m[v[e].taskData.hostname] !== "undefined") {
                                l.fire(v[e].taskData.hostname, true)
                            }
                        }
                    }
                }
            }), 1e3);
            var p = setInterval((function () {
                for (var e in v) {
                    if (!T(v[e]) && v[e].tabIdLastCheckTime && v[e].tabIdLastCheckTime + g < _() && S(v[e])) {
                        ALogger.log("clear tabId attachment, taskid = ", e);
                        s.fire(v[e])
                    }
                }
            }), 1e3);
            var d = setInterval((function () {
                for (var e in m) {
                    var n = 0;
                    for (var r in m[e].tasks) {
                        if (S(m[e].tasks[r]) && T(m[e].tasks[r])) {
                            n++
                        }
                    }
                    if (n < m[e].precachedSolutionsCountK && !m[e].noCacheRequestsSinceLastSolutionExpiration) {
                        ALogger.log("Creating new tasks");
                        for (var r = 0; r < m[e].precachedSolutionsCountK - n; r++) {
                            t.create(e, m[e].siteKey, null, true)
                        }
                    }
                }
            }), 3e3);
            var h = setInterval((function () {
                for (var e in m) {
                    for (var t in m[e].tasks) {
                        if (x(m[e].tasks[t], m[e])) {
                            delete v[m[e].tasks[t].fakeTaskId];
                            delete m[e].tasks[t]
                        }
                    }
                    m[e].tasks = m[e].tasks.filter((function (e) {
                        return e != undefined
                    }));
                    if (m[e].tasks.length == 0 && m[e].lastTaskCreateTime + w * 60 < _()) {
                        clearInterval(m[e].everyMinuteCheckInterval);
                        delete m[e]
                    }
                }
            }), 60 * 1e3);
            setInterval((function () {
                Ne.log("precachedSolutions", m)
            }), 1e3);
            var m = {
                "antcpt.com": {
                    hostname: "antcpt.com",
                    siteKey: "fdfsf2343fdsfds3424",
                    tasks: [{
                        fakeTaskId: 123,
                        realTaskId: 321,
                        startTime: 1234567890,
                        endTime: 1234567890,
                        solution: "",
                        tabId: 54321,
                        tabIdLastCheckTime: 1234567890,
                        taskProcessingToContentScriptTime: 0,
                        error: null,
                        taskData: {hostname: "antcpt.com", siteKey: "fdfsf2343fdsfds3424"}
                    }],
                    noCacheRequestsSinceLastSolutionExpiration: false,
                    precachedSolutionsCountK: b,
                    totalSolvingTime: 0,
                    totalFeelsLikeSolvingTime: 0,
                    totalSolvedTasks: 0,
                    mediumSolvingTime: y,
                    mediumFeelsLikeSolvingTime: y,
                    mediumRatePerMinute: b * (60 / y),
                    totalTasksRequested: 0,
                    totalMinutesWithTasks: 0,
                    lastMiniuteCheckTime: _()
                }
            };
            m = {};
            t.cacheFreshnessTime = 110;
            var g = 10;
            var y = 40;
            var v = {};
            var b = 2;
            var w = 5;
            this.getByHostname = function (e, t) {
                ALogger.log("getByHostname called with arguments", arguments);
                l.fire(e, false);
                if (typeof m[e] != "undefined") {
                    for (var n in m[e].tasks) {
                        if (S(m[e].tasks[n]) && (T(m[e].tasks[n]) || k(m[e].tasks[n], t))) {
                            var r = m[e].tasks[n];
                            o.fire(r, t);
                            return r
                        }
                    }
                    return false
                } else {
                    return false
                }
            };

            function x(e, t) {
                return !S(e) && !A(e, t)
            }

            function T(e) {
                return !e.tabId
            }

            function k(e, t) {
                return e.tabId == t
            }

            function S(e) {
                return !e.taskProcessingToContentScriptTime && !e.expired && !C(e);
                e.tabId && (typeof tabId == "undefined" || e.tabId != tabId) || e.taskProcessingToContentScriptTime || e.expired || C(e)
            }

            function C(e) {
                return e.endTime && e.endTime + t.cacheFreshnessTime <= _()
            }

            this.markTaskAsProcessedToContentScript = function (e) {
                e.taskProcessingToContentScriptTime = _();
                r.fire(e.fakeTaskId);
                l.fire(e.taskData.hostname, false)
            };
            this.copyRequestTimeToAnotherTask = function (e, t) {
                e.requestTime = t.requestTime
            };
            this.getByTaskId = function (e, t) {
                ALogger.log("getByTaskId called with arguments", arguments);
                if (typeof v[e] != "undefined") {
                    if (S(v[e]) && (T(v[e]) || k(v[e], t))) {
                        l.fire(v[e].taskData.hostname, false);
                        if (t) {
                            u.fire(v[e], t)
                        }
                        return v[e]
                    } else {
                        return false
                    }
                } else {
                    return false
                }
            };

            function A(e, t) {
                return e.requestTime && e.requestTime >= t.lastMiniuteCheckTime
            }

            this.refreshPrecachedSolutionsCountKForEveryHost = function () {
                for (var e in m) {
                    L(e)
                }
            };

            function L(e) {
                if (typeof globalStatus.k_precached_solution_count_min != "undefined" && typeof m[e] !== "undefined") {
                    m[e].precachedSolutionsCountK = Math.max(m[e].precachedSolutionsCountK, globalStatus.k_precached_solution_count_min)
                }
                if (typeof globalStatus.k_precached_solution_count_max != "undefined" && typeof m[e] !== "undefined") {
                    m[e].precachedSolutionsCountK = Math.min(m[e].precachedSolutionsCountK, globalStatus.k_precached_solution_count_max)
                }
            }

            this.createHost = function (e, t) {
                var n = typeof globalStatus.k_precached_solution_count_min != "undefined" ? globalStatus.k_precached_solution_count_min : b;
                m[e] = {
                    hostname: e,
                    siteKey: t,
                    tasks: [],
                    noCacheRequestsSinceLastSolutionExpiration: false,
                    precachedSolutionsCountK: n,
                    totalSolvingTime: 0,
                    totalFeelsLikeSolvingTime: 0,
                    totalSolvedTasks: 0,
                    mediumSolvingTime: y,
                    mediumFeelsLikeSolvingTime: y,
                    mediumRatePerMinute: n * (60 / y),
                    totalTasksRequested: 0,
                    totalMinutesWithTasks: 0,
                    lastTaskCreateTime: 0,
                    lastMiniuteCheckTime: _(),
                    everyMinuteCheckInterval: setInterval((function () {
                        ALogger.log("everyMinuteCheckInterval hostname = ", e);
                        var t = 0;
                        for (var n in m[e].tasks) {
                            if (A(m[e].tasks[n], m[e]) && !T(m[e].tasks[n]) && !m[e].tasks[n].error) {
                                t++
                            }
                        }
                        m[e].lastMiniuteCheckTime = _();
                        ALogger.log("lastMinuteTaskCount = ", t);
                        if (t) {
                            m[e].totalTasksRequested += t;
                            m[e].totalMinutesWithTasks++;
                            m[e].mediumRatePerMinute = m[e].totalTasksRequested / m[e].totalMinutesWithTasks;
                            m[e].precachedSolutionsCountK = Math.round(m[e].mediumRatePerMinute * m[e].mediumSolvingTime / 60);
                            L(e)
                        }
                    }), 60 * 1e3)
                }
            };
            this.create = function (e, n, r, i) {
                i = !!i;
                ALogger.log("Task creation called with arguments", arguments);
                if (typeof m[e] == "undefined") {
                    t.createHost(e, n)
                }
                var a;
                do {
                    a = Math.round(Math.random() * 1e6)
                } while (typeof v[a] != "undefined");
                var s = {
                    fakeTaskId: a,
                    realTaskId: null,
                    createTime: _(),
                    requestTime: null,
                    startTime: null,
                    endTime: null,
                    expired: false,
                    solution: "",
                    tabId: null,
                    tabIdLastCheckTime: null,
                    taskProcessingToContentScriptTime: 0,
                    error: null,
                    taskData: {hostname: e, siteKey: n}
                };
                v[a] = s;
                m[e].tasks.push(s);
                m[e].lastTaskCreateTime = _();
                if (!i) {
                    l.fire(e, false)
                }
                if (r) {
                    o.fire(s, r)
                }
                ALogger.log("precachedSolutionsByFakeTaskId = ", v);
                return a
            }
        }(e)
    };
    var Pe = De();
    var Ie = Ee(Pe);
    chrome.runtime.onMessage.addListener((function (e, t, n) {
        if (e.type == "createTaskPrecachedRecaptcha") {
            Ie.getCacheForHostname(e.postData, t.tab.id, (function (e) {
                n(e)
            }))
        } else if (e.type == "getTaskResultPrecachedRecaptcha") {
            Ie.getSolution(e.postData, t.tab.id, (function (e) {
                n(e)
            }))
        }
        return true
    }));
    (function () {
        var e = [];
        chrome.runtime.onMessage.addListener((function (t, n, r) {
            if (t.type == "getTaintedImageBase64") {
                delete t.type;
                e[n.tab.id] = {callback: r};
                return true
            } else if (t.type == "setTaintedImageBase64") {
                delete t.type;
                if (typeof e[n.tab.id] != "undefined") {
                    e[n.tab.id].callback(t.data)
                }
            } else if (t.type == "getTaintedImageBase64UsingBackgroundFrame") {
                delete t.type;
                var i = document.createElement("iframe");
                i.src = t.img_src;
                i.width = "1px";
                i.height = "1px";
                i.name = t.img_src;
                document.body.appendChild(i);
                e[t.img_src] = {callback: r, src: t.img_src};
                return true
            } else if (t.type == "setTaintedImageBase64UsingBackgroundFrame") {
                delete t.type;
                if (typeof e[t.original_url] != "undefined") {
                    e[t.original_url].callback(t.data);
                    var a = document.getElementsByTagName("iframe");
                    for (var o in a) {
                        if (a[o].src == e[t.original_url].src) {
                            a[o].parentNode.removeChild(a[o])
                        }
                    }
                }
            } else if (t.type == "captureScreen") {
                delete t.type;
                var s = setInterval((function () {
                    chrome.tabs.query({active: true}, (function (e) {
                        if (e.length) {
                            for (var t in e) {
                                if (e[t].id == n.tab.id) {
                                    clearInterval(s);
                                    setTimeout((function () {
                                        chrome.tabs.captureVisibleTab(n.tab.windowId, {format: "png"}, (function (e) {
                                            r({dataUrl: e})
                                        }))
                                    }), 200)
                                }
                            }
                        }
                    }))
                }), 200);
                return true
            }
        }))
    })();
    var Re = function (e, t) {
        return new function (e, t) {
            t = !!t;
            this.params = {
                host: "api.anti-captcha.com",
                port: 80,
                clientKey: e,
                websiteUrl: null,
                websiteKey: null,
                websiteSToken: null,
                recaptchaDataSValue: null,
                proxyType: "http",
                proxyAddress: null,
                proxyPort: null,
                proxyLogin: null,
                proxyPassword: null,
                userAgent: "",
                cookies: "",
                minScore: "",
                pageAction: "",
                websitePublicKey: null,
                funcaptchaApiJSSubdomain: null,
                websiteChallenge: null,
                geetestApiServerSubdomain: null,
                geetestGetLib: null,
                phrase: null,
                case: null,
                numeric: null,
                math: null,
                minLength: null,
                maxLength: null,
                imageUrl: null,
                assignment: null,
                forms: null,
                softId: null,
                languagePool: null
            };
            var n = {};
            var r = 20, i = 5, a = 2;
            this.getBalance = function (e) {
                var t = {clientKey: this.params.clientKey};
                this.jsonPostRequest("getBalance", t, (function (t, n) {
                    if (t) {
                        return e(t, null, n)
                    }
                    e(null, n.balance, n)
                }))
            };
            this.setCustomData = function (e, t) {
                if (typeof this.params[e] !== "undefined") {
                    return
                }
                n[e] = t
            };
            this.clearCustomData = function () {
                n = {}
            };
            this.createTask = function (e, t, r) {
                t = typeof t == "undefined" ? "NoCaptchaTask" : t;
                var i = this.getPostData(t);
                i.type = t;
                for (var a in n) {
                    if (typeof i[a] === "undefined") {
                        i[a] = n[a]
                    }
                }
                if (typeof r == "object") {
                    for (var a in r) {
                        i[a] = r[a]
                    }
                }
                var o = {
                    clientKey: this.params.clientKey,
                    task: i,
                    softId: this.params.softId !== null ? this.params.softId : 0
                };
                if (this.params.languagePool !== null) {
                    o.languagePool = this.params.languagePool
                }
                this.jsonPostRequest("createTask", o, (function (t, n) {
                    if (t) {
                        return e(t, null, n)
                    }
                    var r = n.taskId;
                    e(null, r, n)
                }))
            };
            this.createTaskProxyless = function (e) {
                this.createTask(e, "NoCaptchaTaskProxyless")
            };
            this.createRecaptchaV2EnterpriseTask = function (e) {
                this.createTask(e, "RecaptchaV2EnterpriseTask")
            };
            this.createRecaptchaV2EnterpriseTaskProxyless = function (e) {
                this.createTask(e, "RecaptchaV2EnterpriseTaskProxyless")
            };
            this.createHCaptchaTaskProxyless = function (e) {
                this.createTask(e, "HCaptchaTaskProxyless")
            };
            this.createHCaptchaTask = function (e) {
                this.createTask(e, "HCaptchaTask")
            };
            this.createRecaptchaV3TaskProxyless = function (e) {
                this.createTask(e, "RecaptchaV3TaskProxyless")
            };
            this.createFunCaptchaTask = function (e) {
                this.createTask(e, "FunCaptchaTask")
            };
            this.createFunCaptchaTaskProxyless = function (e) {
                this.createTask(e, "FunCaptchaTaskProxyless")
            };
            this.createGeeTestTask = function (e) {
                this.createTask(e, "GeeTestTask")
            };
            this.createGeeTestTaskProxyless = function (e) {
                this.createTask(e, "GeeTestTaskProxyless")
            };
            this.createImageToTextTask = function (e, t) {
                this.createTask(t, "ImageToTextTask", e)
            };
            this.createCustomCaptchaTask = function (e) {
                this.createTask(e, "CustomCaptchaTask")
            };
            this.getTaskRawResult = function (e) {
                if (typeof e.solution.gRecaptchaResponse != "undefined") {
                    return e.solution.gRecaptchaResponse
                } else if (typeof e.solution.token != "undefined") {
                    return e.solution.token
                } else if (typeof e.solution.answers != "undefined") {
                    return e.solution.answers
                } else if (typeof e.solution.text !== "undefined") {
                    return e.solution.text
                } else {
                    return e.solution
                }
            };
            this.getTaskSolution = function (e, n, r, o, s) {
                r = r || 0;
                var u = {clientKey: this.params.clientKey, taskId: e};
                if (typeof s !== "undefined" && typeof s.cacheRecord !== "undefined") {
                    u.cacheRecord = s.cacheRecord
                }
                var l;
                if (r == 0) {
                    l = i
                } else {
                    l = a
                }
                if (t) {
                    l = 1
                }
                console.log("Waiting %s seconds", l);
                var c = this;
                setTimeout((function () {
                    c.jsonPostRequest("getTaskResult", u, (function (t, i) {
                        if (t) {
                            return n(t, null, i)
                        }
                        if (i.status == "processing") {
                            if (typeof i.newTaskId !== "undefined") {
                                e = i.newTaskId
                            }
                            if (o) {
                                o()
                            }
                            return c.getTaskSolution(e, n, r + 1, o, s)
                        } else if (i.status == "ready") {
                            return n(null, c.getTaskRawResult(i), i)
                        }
                    }))
                }), l * 1e3)
            };
            this.getPostData = function (e) {
                switch (e) {
                    case"CustomCaptchaTask":
                        return {
                            imageUrl: this.params.imageUrl,
                            assignment: this.params.assignment,
                            forms: this.params.forms
                        };
                    case"ImageToTextTask":
                        return {
                            phrase: this.params.phrase,
                            case: this.params.case,
                            numeric: this.params.numeric,
                            math: this.params.math,
                            minLength: this.params.minLength,
                            maxLength: this.params.maxLength
                        };
                        break;
                    case"NoCaptchaTaskProxyless":
                    case"RecaptchaV2EnterpriseTaskProxyless":
                        return {
                            websiteURL: this.params.websiteUrl,
                            websiteKey: this.params.websiteKey,
                            websiteSToken: this.params.websiteSToken,
                            recaptchaDataSValue: this.params.recaptchaDataSValue
                        };
                        break;
                    case"HCaptchaTaskProxyless":
                        return {websiteURL: this.params.websiteUrl, websiteKey: this.params.websiteKey};
                        break;
                    case"HCaptchaTask":
                        return {
                            websiteURL: this.params.websiteUrl,
                            websiteKey: this.params.websiteKey,
                            proxyType: this.params.proxyType,
                            proxyAddress: this.params.proxyAddress,
                            proxyPort: this.params.proxyPort,
                            proxyLogin: this.params.proxyLogin,
                            proxyPassword: this.params.proxyPassword,
                            userAgent: this.params.userAgent,
                            cookies: this.params.cookies
                        };
                        break;
                    case"RecaptchaV3TaskProxyless":
                        return {
                            websiteURL: this.params.websiteUrl,
                            websiteKey: this.params.websiteKey,
                            minScore: this.params.minScore,
                            pageAction: this.params.pageAction,
                            isEnterprise: this.params.isEnterprise
                        };
                        break;
                    case"FunCaptchaTask":
                        return {
                            websiteURL: this.params.websiteUrl,
                            websitePublicKey: this.params.websitePublicKey,
                            funcaptchaApiJSSubdomain: this.params.funcaptchaApiJSSubdomain,
                            proxyType: this.params.proxyType,
                            proxyAddress: this.params.proxyAddress,
                            proxyPort: this.params.proxyPort,
                            proxyLogin: this.params.proxyLogin,
                            proxyPassword: this.params.proxyPassword,
                            userAgent: this.params.userAgent,
                            cookies: this.params.cookies
                        };
                        break;
                    case"FunCaptchaTaskProxyless":
                        return {
                            websiteURL: this.params.websiteUrl,
                            websitePublicKey: this.params.websitePublicKey,
                            funcaptchaApiJSSubdomain: this.params.funcaptchaApiJSSubdomain
                        };
                    case"GeeTestTask":
                        return {
                            websiteURL: this.params.websiteUrl,
                            gt: this.params.websiteKey,
                            challenge: this.params.websiteChallenge,
                            geetestApiServerSubdomain: this.params.geetestApiServerSubdomain,
                            geetestGetLib: this.params.geetestGetLib,
                            proxyType: this.params.proxyType,
                            proxyAddress: this.params.proxyAddress,
                            proxyPort: this.params.proxyPort,
                            proxyLogin: this.params.proxyLogin,
                            proxyPassword: this.params.proxyPassword,
                            userAgent: this.params.userAgent,
                            cookies: this.params.cookies
                        };
                        break;
                    case"GeeTestTaskProxyless":
                        return {
                            websiteURL: this.params.websiteUrl,
                            gt: this.params.websiteKey,
                            challenge: this.params.websiteChallenge,
                            geetestApiServerSubdomain: this.params.geetestApiServerSubdomain,
                            geetestGetLib: this.params.geetestGetLib
                        };
                    default:
                        return {
                            websiteURL: this.params.websiteUrl,
                            websiteKey: this.params.websiteKey,
                            websiteSToken: this.params.websiteSToken,
                            recaptchaDataSValue: this.params.recaptchaDataSValue,
                            proxyType: this.params.proxyType,
                            proxyAddress: this.params.proxyAddress,
                            proxyPort: this.params.proxyPort,
                            proxyLogin: this.params.proxyLogin,
                            proxyPassword: this.params.proxyPassword,
                            userAgent: this.params.userAgent,
                            cookies: this.params.cookies
                        }
                }
            };
            this.jsonPostRequest = function (e, n, i) {
                if (!t) {
                    if (typeof process === "object" && typeof require === "function") {
                        var a = require("http");
                        var o = {
                            hostname: this.params.host,
                            port: this.params.port,
                            path: "/" + e,
                            method: "POST",
                            headers: {
                                "accept-encoding": "gzip,deflate",
                                "content-type": "application/json; charset=utf-8",
                                accept: "application/json",
                                "content-length": Buffer.byteLength(JSON.stringify(n))
                            }
                        };
                        var s = a.request(o, (function (e) {
                            var t = "";
                            e.on("data", (function (e) {
                                t += e
                            }));
                            e.on("end", (function () {
                                try {
                                    var e = JSON.parse(t)
                                } catch (e) {
                                    return i(e)
                                }
                                if (e.errorId) {
                                    return i(new Error(e.errorDescription, {cause: e}), e)
                                }
                                return i(null, e)
                            }))
                        }));
                        s.write(JSON.stringify(n));
                        s.end();
                        s.setTimeout(r * 1e3);
                        s.on("timeout", (function () {
                            console.log("timeout");
                            s.abort()
                        }));
                        s.on("error", (function (e) {
                            console.log("error");
                            return i(e)
                        }));
                        return s
                    } else if (typeof window !== "undefined" || typeof chrome === "object") {
                        var u;
                        u = window.location.protocol != "http:" ? "https:" : window.location.protocol;
                        var l = u + "//" + this.params.host + (u != "https:" ? ":" + this.params.port : "") + "/" + e;
                        if (typeof jQuery == "function") {
                            jQuery.ajax(l, {
                                method: "POST",
                                data: JSON.stringify(n),
                                dataType: "json",
                                success: function (e) {
                                    if (e && e.errorId) {
                                        return i(new Error(e.errorDescription, {cause: e}), e)
                                    }
                                    i(false, e)
                                },
                                error: function (e, t, n) {
                                    i(new Error(t !== "error" ? t : "Unknown error, watch console", {cause: {errorCode: "HTTP_REQUEST_ERROR"}}))
                                }
                            })
                        } else if (typeof XMLHttpRequest !== "undefined") {
                            var c = new XMLHttpRequest;
                            c.open("POST", l, true);
                            c.responseType = "json";
                            c.setRequestHeader("Content-Type", "application/json; charset=UTF-8");
                            c.send(JSON.stringify(n));
                            c.onloadend = function () {
                                if (c.status == 200) {
                                    var e = c.response;
                                    if (e && e.errorId) {
                                        return i(new Error(e.errorDescription, {cause: e}), e)
                                    }
                                    i(false, e)
                                } else {
                                    i(new Error("Unknown error, watch console", {cause: {errorCode: "HTTP_REQUEST_ERROR"}}))
                                }
                            }
                        }
                    } else {
                        console.error("Application should be run either in NodeJs or a WebBrowser environment")
                    }
                } else {
                    chrome.runtime.sendMessage({type: e + "PrecachedRecaptcha", postData: n}, (function (e) {
                        if (e.errorId) {
                            return i(new Error(e.errorDescription, {cause: e}), e)
                        }
                        return i(null, e)
                    }))
                }
            };
            this.setClientKey = function (e) {
                this.params.clientKey = e
            };
            this.setWebsiteURL = function (e) {
                this.params.websiteUrl = e
            };
            this.setWebsiteKey = function (e) {
                this.params.websiteKey = e
            };
            this.setMinScore = function (e) {
                this.params.minScore = e
            };
            this.setPageAction = function (e) {
                this.params.pageAction = e
            };
            this.setIsEnterprise = function (e) {
                this.params.isEnterprise = e
            };
            this.setWebsiteSToken = function (e) {
                this.params.websiteSToken = e
            };
            this.setRecaptchaDataSValue = function (e) {
                this.params.recaptchaDataSValue = e
            };
            this.setWebsitePublicKey = function (e) {
                this.params.websitePublicKey = e
            };
            this.setFuncaptchaApiJSSubdomain = function (e) {
                this.params.funcaptchaApiJSSubdomain = e
            };
            this.setWebsiteChallenge = function (e) {
                this.params.websiteChallenge = e
            };
            this.setGeetestApiServerSubdomain = function (e) {
                this.params.geetestApiServerSubdomain = e
            };
            this.setGeetestGetLib = function (e) {
                this.params.geetestGetLib = e
            };
            this.setProxyType = function (e) {
                this.params.proxyType = e
            };
            this.setProxyAddress = function (e) {
                this.params.proxyAddress = e
            };
            this.setProxyPort = function (e) {
                this.params.proxyPort = e
            };
            this.setProxyLogin = function (e) {
                this.params.proxyLogin = e
            };
            this.setProxyPassword = function (e) {
                this.params.proxyPassword = e
            };
            this.setUserAgent = function (e) {
                this.params.userAgent = e
            };
            this.setCookies = function (e) {
                this.params.cookies = e
            };
            this.setPhrase = function (e) {
                this.params.phrase = e
            };
            this.setCase = function (e) {
                this.params.case = e
            };
            this.setNumeric = function (e) {
                this.params.numeric = e
            };
            this.setMath = function (e) {
                this.params.math = e
            };
            this.setMinLength = function (e) {
                this.params.minLength = e
            };
            this.setMaxLength = function (e) {
                this.params.maxLength = e
            };
            this.setImageUrl = function (e) {
                this.params.imageUrl = e
            };
            this.setAssignment = function (e) {
                this.params.assignment = e
            };
            this.setForms = function (e) {
                this.params.forms = e
            };
            this.setSoftId = function (e) {
                this.params.softId = e
            };
            this.setLanguagePool = function (e) {
                this.params.languagePool = e
            };
            this.setHost = function (e) {
                this.params.host = e
            };
            this.setPort = function (e) {
                this.params.port = e
            }
        }(e, t)
    };
    if (typeof process === "object" && typeof require === "function") {
        module.exports = Re
    }
    var je = new function () {
        var e = 32;
        var t = [];
        var n = 0;
        var r, i;
        this.set = function (o, s) {
            if (typeof r === "undefined") {
                r = o
            }
            if (typeof t[o] === "undefined") {
                t[o] = {nextKey: null, value: s}
            } else {
                t[o].value = s;
                return
            }
            if (typeof i !== "undefined") {
                t[i].nextKey = o
            }
            i = o;
            n++;
            if (n > e) {
                a()
            }
        };
        this.get = function (e) {
            if (typeof t[e] !== "undefined") {
                return t[e].value
            }
            return null
        };
        var a = function () {
            var e = t[r].nextKey;
            delete t[r];
            r = e
        }
    }
})();