<?php


namespace AwardWallet\Common\Geo;


class GeoCodingFailedException extends \RuntimeException
{

}