<?php

interface AccountInterface {
	
	public function setAccountId($accountId);
	
	public function getAccountId();
	
	public function setAccountInfo($accountInfo);
	
	public function getAccountInfo();
	
}

?>