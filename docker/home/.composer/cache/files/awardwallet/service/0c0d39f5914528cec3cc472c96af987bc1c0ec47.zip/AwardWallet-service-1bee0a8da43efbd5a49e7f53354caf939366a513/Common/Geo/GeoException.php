<?php

namespace AwardWallet\Common\Geo;

class GeoException extends \Exception {}