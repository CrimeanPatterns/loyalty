<?php


namespace AwardWallet\Common\Parsing\Solver;


class MissingDataException extends \Exception {}