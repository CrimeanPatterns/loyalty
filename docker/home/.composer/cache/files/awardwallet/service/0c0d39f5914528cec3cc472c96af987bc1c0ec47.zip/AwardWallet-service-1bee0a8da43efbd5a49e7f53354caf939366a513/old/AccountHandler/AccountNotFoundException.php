<?php

class AccountNotFoundException extends InvalidArgumentException {

} 