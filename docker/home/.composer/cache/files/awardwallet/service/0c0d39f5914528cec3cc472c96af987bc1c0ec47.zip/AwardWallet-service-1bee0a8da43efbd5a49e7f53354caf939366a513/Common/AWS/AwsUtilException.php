<?php

namespace AwardWallet\Common\AWS;

class AwsUtilException extends \Exception
{

}