<?php


class HttpNullLogger implements HttpLoggerInterface{

	public function Log($message, $level = null, $htmlEncode = true){

	}
}