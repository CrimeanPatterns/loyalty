<?php

namespace AwardWallet\Common\Itineraries;


class Transportation extends Flight
{

}