deprecated, should not be used

use AwardWallet\Schema\Itineraries or AwardWallet\Schema\Parser