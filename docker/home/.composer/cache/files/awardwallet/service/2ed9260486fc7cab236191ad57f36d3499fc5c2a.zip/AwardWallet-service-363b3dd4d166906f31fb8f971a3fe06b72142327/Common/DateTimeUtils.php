<?php

namespace AwardWallet\Common;

class DateTimeUtils
{
    const SECONDS_PER_DAY = 24 * 60 * 60;
    const SECONDS_PER_HOUR = 60 * 60;
}