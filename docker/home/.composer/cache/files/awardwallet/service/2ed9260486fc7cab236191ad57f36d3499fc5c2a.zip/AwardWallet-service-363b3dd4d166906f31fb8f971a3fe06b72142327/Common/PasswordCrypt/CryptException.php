<?php

namespace AwardWallet\Common\PasswordCrypt;

class CryptException extends \Exception
{

}
