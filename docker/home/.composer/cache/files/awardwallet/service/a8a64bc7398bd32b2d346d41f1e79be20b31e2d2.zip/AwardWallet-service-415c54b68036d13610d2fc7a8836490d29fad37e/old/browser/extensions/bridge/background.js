function onMessage(request, sender, sendResponse) {
    console.log('eval: ' + request.code);
    console.log('arguments: ', request.arguments);
    console.log('sendResponse: ' + typeof (sendResponse));
    var arguments = request.arguments;
    try {
        eval(request.code);
        console.log('eval fired');
    } catch (e) {
        console.log('exception: ', e);
        sendResponse(e.message);
    }
    console.log('eval finished');
    // return true from the event listener. This keeps the sendResponse function valid after the listener returns, so you can call it later.
    return true;
}

chrome.runtime.onMessage.addListener(onMessage);
chrome.runtime.onMessageExternal.addListener(function(request, sender, sendResponse) {
    onMessage(request, sender, (response) => {
        sendResponse({"status":"ok", "result":response})
    });
    
});

console.log('started');