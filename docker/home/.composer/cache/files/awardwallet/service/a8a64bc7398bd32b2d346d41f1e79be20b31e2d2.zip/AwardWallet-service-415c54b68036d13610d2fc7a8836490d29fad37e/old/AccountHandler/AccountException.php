<?php

class AccountException extends Exception {
	const NO_LOCAL_PASSWORD	= 1001;
	const CALLBACK			= 1002;
	
}

?>