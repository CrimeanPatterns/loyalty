<?php


namespace AwardWallet\Common\Geo;


class Constants
{

    const GEOTAG_TYPE_DEFAULT = 0;
    const GEOTAG_TYPE_AIRPORT = 1;
    const GEOTAG_TYPE_AIRPORT_WITH_ADDRESS = 2;

}