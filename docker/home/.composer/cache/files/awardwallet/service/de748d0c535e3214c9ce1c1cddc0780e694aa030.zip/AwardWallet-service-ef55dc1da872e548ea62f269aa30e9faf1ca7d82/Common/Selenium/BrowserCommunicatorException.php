<?php

namespace AwardWallet\Common\Selenium;

class BrowserCommunicatorException extends \Exception
{

}