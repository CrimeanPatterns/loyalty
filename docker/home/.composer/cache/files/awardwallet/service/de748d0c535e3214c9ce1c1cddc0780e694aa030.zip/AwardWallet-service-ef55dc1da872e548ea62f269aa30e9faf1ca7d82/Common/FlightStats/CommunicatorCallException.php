<?php


namespace AwardWallet\Common\FlightStats;


class CommunicatorCallException extends \Exception
{
}