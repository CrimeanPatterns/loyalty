<?php


namespace AwardWallet\Common\Parsing\Solver\Extra;


class Context
{

    public $partnerLogin;

}