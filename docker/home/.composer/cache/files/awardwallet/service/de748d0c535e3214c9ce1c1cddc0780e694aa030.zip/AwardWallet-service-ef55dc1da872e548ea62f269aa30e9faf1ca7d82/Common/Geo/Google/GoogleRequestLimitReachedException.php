<?php


namespace AwardWallet\Common\Geo\Google;


/**
 * Google API request limit reached
 */
class GoogleRequestLimitReachedException extends GoogleRequestFailedException
{

}