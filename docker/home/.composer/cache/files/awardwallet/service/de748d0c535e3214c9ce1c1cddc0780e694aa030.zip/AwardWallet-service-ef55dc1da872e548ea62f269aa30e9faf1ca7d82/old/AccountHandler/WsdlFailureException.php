<?php

class WsdlFailureException extends \RuntimeException
{

}