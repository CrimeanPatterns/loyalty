<?php


namespace AwardWallet\Common\AirLabs;


class CommunicatorCallException extends \Exception
{
}