<?php

interface AccountHandlerInterface {
	
	public function setAccount(AccountInterface $account);
	
	public function getAccount();
	
}

?>