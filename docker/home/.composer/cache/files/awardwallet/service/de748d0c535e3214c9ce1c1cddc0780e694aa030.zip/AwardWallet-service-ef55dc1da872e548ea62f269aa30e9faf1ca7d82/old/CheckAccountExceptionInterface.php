<?
interface CheckAccountExceptionInterface{

	/**
	 * @return bool
	 */
	public function throwToParent();

}