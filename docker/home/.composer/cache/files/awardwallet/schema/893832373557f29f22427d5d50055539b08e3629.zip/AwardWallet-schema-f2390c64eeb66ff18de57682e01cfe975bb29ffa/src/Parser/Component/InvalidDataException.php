<?php

namespace AwardWallet\Schema\Parser\Component;


class InvalidDataException extends \Exception {

}