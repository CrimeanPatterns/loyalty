<?php

namespace Facebook\WebDriver\Exception;

/**
 * @deprecated Removed in W3C WebDriver
 */
class ElementNotVisibleException extends WebDriverException
{
}
