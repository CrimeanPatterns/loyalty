<?php

namespace Facebook\WebDriver\Firefox;

/**
 * @codeCoverageIgnore
 */
class FirefoxDriver
{
    const PROFILE = 'firefox_profile';

    private function __construct()
    {
    }
}
