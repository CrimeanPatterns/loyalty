Document Constraints for PHPUnit
================================

The constraints in this directory have been copied from the MongoDB Library at
https://github.com/mongodb/mongo-php-library. This code is licensed under the
Apache License Version 2.0.
