<?php

namespace TestDocuments;

class QueryResultDocument
{
    public $name;

    public $count;
}
